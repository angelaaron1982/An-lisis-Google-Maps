import { THEMES } from "@/lib/analysis/themes";
import { Card } from "./ui";

export function MethodologyPanel() {
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card title="Flujo de trabajo sugerido para la investigación de mercado">
        <ol className="list-decimal space-y-2 pl-5 text-sm text-slate-700">
          <li>
            <strong>Definir el problema y los objetivos:</strong> ¿qué quieres saber de la percepción de los clientes? (calidad, precio, servicio…).
          </li>
          <li>
            <strong>Seleccionar los establecimientos:</strong> el negocio de interés y sus competidores directos.
          </li>
          <li>
            <strong>Recolectar datos secundarios:</strong> extrae reseñas con Google Places API, SerpAPI o importa un archivo.
          </li>
          <li>
            <strong>Analizar:</strong> revisa la estadística descriptiva, los temas, el sentimiento y los temas emergentes.
          </li>
          <li>
            <strong>Comparar:</strong> identifica ventajas competitivas y áreas de oportunidad frente a la competencia.
          </li>
          <li>
            <strong>Reportar:</strong> descarga el reporte en Word (redacción) y Excel (datos y tablas dinámicas) e interpreta los resultados.
          </li>
        </ol>
      </Card>

      <Card title="Fuentes de datos">
        <ul className="space-y-2 text-sm text-slate-700">
          <li>
            <strong>Google Places API (New):</strong> fuente oficial. Proporciona la calificación global, el número total de opiniones y hasta 5 reseñas por
            consulta. Puedes «Actualizar» periódicamente para acumular reseñas nuevas.
          </li>
          <li>
            <strong>SerpAPI (Google Maps Reviews):</strong> permite obtener cientos de reseñas mediante paginación, ordenadas por relevancia, fecha o calificación.
          </li>
          <li>
            <strong>Importación:</strong> CSV/Excel con las columnas <code>calificacion</code>, <code>texto</code>, <code>autor</code>, <code>fecha</code> (los nombres en inglés también se reconocen).
          </li>
          <li>
            <strong>Demostración:</strong> datos simulados para practicar; no deben usarse como evidencia real.
          </li>
        </ul>
      </Card>

      <Card title="Estadística descriptiva y pruebas">
        <ul className="space-y-2 text-sm text-slate-700">
          <li>Media, mediana, moda, desviación estándar muestral, varianza, rango, cuartiles (CUARTIL.INC), rango intercuartílico.</li>
          <li>Coeficiente de variación, asimetría y curtosis (equivalentes a COEFICIENTE.ASIMETRIA y CURTOSIS de Excel).</li>
          <li>Intervalo de confianza al 95% para la media con la distribución t de Student.</li>
          <li>
            <strong>Índice de satisfacción neta</strong> = % de reseñas 4–5★ − % de reseñas 1–2★ (de −100 a +100).
          </li>
          <li>
            <strong>Comparación:</strong> ANOVA de un factor (η²), Kruskal-Wallis (ε²) — recomendada porque las estrellas son una escala ordinal —, t de Welch
            para dos grupos (d de Cohen) y chi-cuadrada de independencia para el sentimiento (V de Cramér).
          </li>
        </ul>
      </Card>

      <Card title="Análisis de texto: sentimiento y temas">
        <ul className="space-y-2 text-sm text-slate-700">
          <li>
            <strong>Sentimiento por reseña:</strong> 60% calificación + 40% análisis léxico del texto (diccionario español/inglés con negaciones, intensificadores y
            expresiones idiomáticas). Positivo &gt; 0.2; negativo &lt; −0.2.
          </li>
          <li>
            <strong>Sentimiento por aspecto:</strong> cada oración se divide en cláusulas (por comas y conectores como «pero» o «aunque») y su sentimiento se asigna a los
            temas que menciona. Ej.: «la comida deliciosa, pero el servicio lento» → Producto (+), Servicio (−).
          </li>
          <li>
            <strong>Temas emergentes:</strong> agrupamiento no supervisado (TF-IDF + k-means con similitud coseno) que descubre grupos de opiniones con vocabulario
            similar, sin categorías predefinidas.
          </li>
          <li>
            <strong>Limitaciones:</strong> las reseñas en línea no son una muestra probabilística (sesgo de autoselección) y el análisis automático puede fallar con
            ironía; valida siempre con lectura cualitativa.
          </li>
        </ul>
      </Card>

      <Card title="Diccionario de temas (12 dimensiones de la experiencia del cliente)" className="lg:col-span-2">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {THEMES.map((t) => (
            <div key={t.id} className="rounded-xl border border-slate-200 p-3">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full" style={{ backgroundColor: t.color }} />
                <span className="text-sm font-semibold text-slate-900">{t.name}</span>
              </div>
              <p className="mt-1 text-xs text-slate-600">{t.description}</p>
              <p className="mt-2 text-[11px] text-slate-500">
                Ej.: {t.keywords
                  .slice(0, 8)
                  .map((k) => k.replace("*", "…"))
                  .join(", ")}
              </p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
