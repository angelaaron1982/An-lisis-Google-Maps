"use client";

import { useCallback, useEffect, useState } from "react";
import type { PlaceSummary } from "@/lib/analysis/types";
import { api, type Notify } from "@/lib/client";
import { AnalysisPanel } from "./AnalysisPanel";
import { ComparePanel } from "./ComparePanel";
import { MethodologyPanel } from "./MethodologyPanel";
import { PlacesPanel } from "./PlacesPanel";
import { SearchPanel } from "./SearchPanel";

type Tab = "buscar" | "lugares" | "analisis" | "comparar" | "metodologia";
type Toast = { id: number; message: string; kind: "success" | "error" | "info" };

const STEPS = [
  { n: 1, t: "Buscar", d: "Nombre o enlace de Google Maps" },
  { n: 2, t: "Extraer", d: "Reseñas y calificaciones" },
  { n: 3, t: "Analizar", d: "Temas, sentimiento y estadística" },
  { n: 4, t: "Comparar", d: "Varios establecimientos" },
  { n: 5, t: "Descargar", d: "Reportes en Word y Excel" },
];

export function AppShell() {
  const [tab, setTab] = useState<Tab>("buscar");
  const [config, setConfig] = useState<{ google: boolean; serpapi: boolean } | null>(null);
  const [places, setPlaces] = useState<PlaceSummary[]>([]);
  const [loadingPlaces, setLoadingPlaces] = useState(true);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [compareIds, setCompareIds] = useState<number[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const notify: Notify = useCallback((message, kind = "info") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-4), { id, message, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === "error" ? 10000 : 6500);
  }, []);

  const refreshPlaces = useCallback(async () => {
    try {
      const r = await api<{ places: PlaceSummary[] }>("/api/places");
      setPlaces(r.places);
      return r.places;
    } catch (e) {
      notify(e instanceof Error ? e.message : "No se pudieron cargar los establecimientos.", "error");
      return [];
    } finally {
      setLoadingPlaces(false);
    }
  }, [notify]);

  useEffect(() => {
    api<{ google: boolean; serpapi: boolean }>("/api/config")
      .then(setConfig)
      .catch(() => setConfig({ google: false, serpapi: false }));
    void refreshPlaces();
  }, [refreshPlaces]);

  const go = (t: Tab) => {
    setTab(t);
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const openAnalysis = (id: number) => {
    setSelectedId(id);
    go("analisis");
  };

  const toggleCompare = (id: number) =>
    setCompareIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : ids.length >= 8 ? ids : [...ids, id]));

  const tabs: { id: Tab; label: string; count?: number }[] = [
    { id: "buscar", label: "1. Buscar y extraer" },
    { id: "lugares", label: "2. Mis establecimientos", count: places.length },
    { id: "analisis", label: "3. Análisis" },
    { id: "comparar", label: "4. Comparar", count: compareIds.length || undefined },
    { id: "metodologia", label: "Metodología" },
  ];

  return (
    <div>
      <nav className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 sm:px-6 lg:px-8">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => go(t.id)}
              className={`flex shrink-0 items-center gap-2 border-b-2 px-4 py-3.5 text-sm font-medium transition ${
                tab === t.id ? "border-emerald-700 text-emerald-800" : "border-transparent text-slate-600 hover:text-slate-900"
              }`}
            >
              {t.label}
              {t.count !== undefined && t.count > 0 && (
                <span className={`rounded-full px-2 py-0.5 text-xs ${tab === t.id ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-600"}`}>{t.count}</span>
              )}
            </button>
          ))}
        </div>
      </nav>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        {tab === "buscar" && (
          <ol className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-5">
            {STEPS.map((s) => (
              <li key={s.n} className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2.5 shadow-sm">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-700 text-sm font-bold text-white">{s.n}</span>
                <span>
                  <span className="block text-sm font-semibold text-slate-900">{s.t}</span>
                  <span className="block text-[11px] leading-tight text-slate-500">{s.d}</span>
                </span>
              </li>
            ))}
          </ol>
        )}

        {tab === "buscar" && (
          <SearchPanel
            config={config}
            notify={notify}
            onSaved={async (id) => {
              await refreshPlaces();
              setRefreshKey((k) => k + 1);
              openAnalysis(id);
            }}
            onDemo={async (ids) => {
              await refreshPlaces();
              setCompareIds(ids.slice(0, 4));
              go("lugares");
            }}
          />
        )}
        {tab === "lugares" && (
          <PlacesPanel
            places={places}
            loading={loadingPlaces}
            compareIds={compareIds}
            onToggleCompare={toggleCompare}
            onOpen={openAnalysis}
            onCompare={() => go("comparar")}
            onGoSearch={() => go("buscar")}
            notify={notify}
            onChanged={async (deletedId) => {
              if (deletedId) {
                setCompareIds((ids) => ids.filter((x) => x !== deletedId));
                if (selectedId === deletedId) setSelectedId(null);
              }
              await refreshPlaces();
              setRefreshKey((k) => k + 1);
            }}
          />
        )}
        {tab === "analisis" && (
          <AnalysisPanel
            placeId={selectedId ?? places[0]?.id ?? null}
            places={places}
            refreshKey={refreshKey}
            onSelect={(id) => setSelectedId(id)}
            onGoSearch={() => go("buscar")}
            notify={notify}
          />
        )}
        {tab === "comparar" && (
          <ComparePanel places={places} selected={compareIds} onToggle={toggleCompare} onGoPlaces={() => go("lugares")} notify={notify} />
        )}
        {tab === "metodologia" && <MethodologyPanel />}
      </main>

      <div className="pointer-events-none fixed bottom-4 right-4 z-50 flex w-[min(420px,calc(100vw-2rem))] flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto rounded-xl border px-4 py-3 text-sm shadow-lg ${
              t.kind === "success"
                ? "border-green-200 bg-green-50 text-green-900"
                : t.kind === "error"
                  ? "border-red-200 bg-red-50 text-red-900"
                  : "border-sky-200 bg-sky-50 text-sky-900"
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <span>{t.message}</span>
              <button onClick={() => setToasts((x) => x.filter((y) => y.id !== t.id))} className="text-xs opacity-60 hover:opacity-100" aria-label="Cerrar">
                ✕
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
