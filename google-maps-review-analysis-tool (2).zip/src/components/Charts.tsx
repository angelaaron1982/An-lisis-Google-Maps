"use client";

import type { ReactNode } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  LabelList,
  Legend,
  Line,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { THEME_BY_ID } from "@/lib/analysis/themes";
import type {
  ClusterResult,
  CompareSummaryRow,
  PlaceAnalysis,
  RatingBucket,
  SentimentSummary,
  TermFreq,
  ThemeMatrixRow,
  ThemeResult,
  TrendPoint,
} from "@/lib/analysis/types";
import { fmt, SENTIMENT_COLORS, STAR_COLORS } from "@/lib/format";

const AXIS = { fontSize: 12, fill: "#475569" };

function short(s: string, n = 26) {
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

export function ChartCard({
  title,
  subtitle,
  exportKey,
  height = 300,
  children,
  className = "",
}: {
  title: string;
  subtitle?: string;
  exportKey: string;
  height?: number;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={`rounded-2xl border border-slate-200 bg-white p-4 shadow-sm ${className}`}>
      <div className="mb-2">
        <h4 className="text-sm font-semibold text-slate-800">{title}</h4>
        {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
      </div>
      <div data-export-key={exportKey} data-export-title={title} className="bg-white" style={{ height }}>
        {children}
      </div>
    </div>
  );
}

export function RatingDistributionChart({ data }: { data: RatingBucket[] }) {
  const rows = data.map((d) => ({ name: `${d.stars}★`, count: d.count, percent: d.percent, color: STAR_COLORS[d.stars - 1] }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={rows} margin={{ top: 24, right: 12, left: 0, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="name" tick={AXIS} />
        <YAxis allowDecimals={false} tick={AXIS} />
        <Tooltip formatter={(v) => [`${v} reseñas`, "Frecuencia"]} />
        <Bar dataKey="count" name="Reseñas" radius={[6, 6, 0, 0]}>
          {rows.map((r) => (
            <Cell key={r.name} fill={r.color} />
          ))}
          <LabelList dataKey="percent" position="top" formatter={(v: unknown) => `${fmt(Number(v), 1)}%`} style={{ fontSize: 12, fill: "#334155" }} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

const renderPieLabel = (props: unknown) => {
  const p = props as { name?: string; percent?: number };
  return `${p.name ?? ""} ${fmt((p.percent ?? 0) * 100, 0)}%`;
};

export function SentimentPieChart({ s }: { s: SentimentSummary }) {
  const data = [
    { name: "Positivo", value: s.positive, color: SENTIMENT_COLORS.positivo },
    { name: "Neutral", value: s.neutral, color: SENTIMENT_COLORS.neutral },
    { name: "Negativo", value: s.negative, color: SENTIMENT_COLORS.negativo },
  ].filter((d) => d.value > 0);
  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius="45%" outerRadius="72%" paddingAngle={2} label={renderPieLabel}>
          {data.map((d) => (
            <Cell key={d.name} fill={d.color} />
          ))}
        </Pie>
        <Tooltip formatter={(v) => [`${v} reseñas`, "Reseñas"]} />
        <Legend verticalAlign="bottom" height={28} />
      </PieChart>
    </ResponsiveContainer>
  );
}

export function ThemeMentionsChart({ themes }: { themes: ThemeResult[] }) {
  const data = themes
    .filter((t) => t.mentions > 0)
    .map((t) => ({ name: THEME_BY_ID[t.id]?.short ?? t.name, full: t.name, percent: t.percentOfReviews, mentions: t.mentions, color: t.color }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 44, left: 8, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
        <XAxis type="number" unit="%" tick={AXIS} />
        <YAxis type="category" dataKey="name" width={104} tick={AXIS} interval={0} />
        <Tooltip formatter={(v) => [`${fmt(Number(v), 1)}%`, "% de reseñas con texto"]} />
        <Bar dataKey="percent" name="% de reseñas" radius={[0, 6, 6, 0]}>
          {data.map((d) => (
            <Cell key={d.name} fill={d.color} />
          ))}
          <LabelList dataKey="mentions" position="right" style={{ fontSize: 11, fill: "#334155" }} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ThemeSentimentChart({ themes }: { themes: ThemeResult[] }) {
  const data = themes
    .filter((t) => t.mentions > 0)
    .map((t) => ({ name: THEME_BY_ID[t.id]?.short ?? t.name, Positivas: t.positive, Neutrales: t.neutral, Negativas: t.negative }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
        <XAxis type="number" allowDecimals={false} tick={AXIS} />
        <YAxis type="category" dataKey="name" width={104} tick={AXIS} interval={0} />
        <Tooltip />
        <Legend />
        <Bar dataKey="Positivas" stackId="s" fill={SENTIMENT_COLORS.positivo} />
        <Bar dataKey="Neutrales" stackId="s" fill={SENTIMENT_COLORS.neutral} />
        <Bar dataKey="Negativas" stackId="s" fill={SENTIMENT_COLORS.negativo} radius={[0, 6, 6, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ThemeRatingChart({ themes, overall }: { themes: ThemeResult[]; overall: number | null }) {
  const data = themes
    .filter((t) => t.mentions > 0 && t.avgRating !== null)
    .map((t) => ({ name: THEME_BY_ID[t.id]?.short ?? t.name, avg: t.avgRating, color: t.color }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 24, right: 12, left: 0, bottom: 40 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="name" tick={{ ...AXIS, fontSize: 11 }} angle={-30} textAnchor="end" interval={0} height={50} />
        <YAxis domain={[0, 5]} ticks={[0, 1, 2, 3, 4, 5]} tick={AXIS} />
        <Tooltip formatter={(v) => [`${fmt(Number(v))}★`, "Calificación promedio"]} />
        {overall !== null && <ReferenceLine y={overall} stroke="#0f172a" strokeDasharray="5 4" label={{ value: `Promedio general ${fmt(overall)}`, position: "insideTopRight", fontSize: 11 }} />}
        <Bar dataKey="avg" name="Calificación promedio" radius={[6, 6, 0, 0]}>
          {data.map((d) => (
            <Cell key={d.name} fill={d.color} />
          ))}
          <LabelList dataKey="avg" position="top" formatter={(v: unknown) => fmt(Number(v))} style={{ fontSize: 11, fill: "#334155" }} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function TrendChart({ trend }: { trend: TrendPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <ComposedChart data={trend} margin={{ top: 12, right: 8, left: 0, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="period" tick={{ ...AXIS, fontSize: 11 }} />
        <YAxis yAxisId="left" allowDecimals={false} tick={AXIS} />
        <YAxis yAxisId="right" orientation="right" domain={[1, 5]} ticks={[1, 2, 3, 4, 5]} tick={AXIS} />
        <Tooltip />
        <Legend />
        <Bar yAxisId="left" dataKey="count" name="Reseñas" fill="#a7f3d0" radius={[4, 4, 0, 0]} />
        <Line yAxisId="right" type="monotone" dataKey="avgRating" name="Calificación promedio" stroke="#0b6e4f" strokeWidth={2.5} dot={{ r: 3 }} />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

export function TopWordsChart({ words }: { words: TermFreq[] }) {
  const data = words.slice(0, 15);
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 32, left: 8, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
        <XAxis type="number" allowDecimals={false} tick={AXIS} />
        <YAxis type="category" dataKey="term" width={96} tick={AXIS} interval={0} />
        <Tooltip formatter={(v) => [`${v} reseñas`, "Menciones"]} />
        <Bar dataKey="count" name="Reseñas" fill="#0ea5e9" radius={[0, 6, 6, 0]}>
          <LabelList dataKey="count" position="right" style={{ fontSize: 11, fill: "#334155" }} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

const CLUSTER_COLORS = ["#0b6e4f", "#f59e0b", "#3b82f6", "#ec4899", "#8b5cf6", "#14b8a6"];

export function ClusterChart({ clusters }: { clusters: ClusterResult[] }) {
  const data = clusters.map((c, i) => ({ name: `G${c.id}: ${short(c.terms.slice(0, 2).join(" · "), 22)}`, size: c.size, avg: c.avgRating, color: CLUSTER_COLORS[i % CLUSTER_COLORS.length] }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 40, left: 8, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
        <XAxis type="number" allowDecimals={false} tick={AXIS} />
        <YAxis type="category" dataKey="name" width={170} tick={{ ...AXIS, fontSize: 11 }} interval={0} />
        <Tooltip formatter={(v) => [`${v} reseñas`, "Tamaño del grupo"]} />
        <Bar dataKey="size" name="Reseñas" radius={[0, 6, 6, 0]}>
          {data.map((d) => (
            <Cell key={d.name} fill={d.color} />
          ))}
          <LabelList dataKey="avg" position="right" formatter={(v: unknown) => `${fmt(Number(v), 1)}★`} style={{ fontSize: 11, fill: "#334155" }} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

// ------------------------- Comparación -------------------------

export function CompareMeansChart({ summary }: { summary: CompareSummaryRow[] }) {
  const data = summary.map((s) => ({ name: short(s.name, 22), Muestra: s.mean, Google: s.googleRating }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 24, right: 12, left: 0, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="name" tick={{ ...AXIS, fontSize: 11 }} interval={0} />
        <YAxis domain={[0, 5]} ticks={[0, 1, 2, 3, 4, 5]} tick={AXIS} />
        <Tooltip formatter={(v) => `${fmt(Number(v))}★`} />
        <Legend />
        <Bar dataKey="Muestra" name="Promedio de la muestra" fill="#0b6e4f" radius={[6, 6, 0, 0]}>
          <LabelList dataKey="Muestra" position="top" formatter={(v: unknown) => fmt(Number(v))} style={{ fontSize: 11 }} />
        </Bar>
        <Bar dataKey="Google" name="Calificación global en Google" fill="#f59e0b" radius={[6, 6, 0, 0]}>
          <LabelList dataKey="Google" position="top" formatter={(v: unknown) => (v === null || v === undefined ? "" : fmt(Number(v), 1))} style={{ fontSize: 11 }} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function CompareDistributionChart({ places }: { places: PlaceAnalysis[] }) {
  const data = places.map((p) => {
    const o: Record<string, string | number> = { name: short(p.place.name, 24) };
    p.distribution.forEach((d) => (o[`${d.stars}★`] = d.percent));
    return o;
  });
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
        <XAxis type="number" domain={[0, 100]} unit="%" tick={AXIS} />
        <YAxis type="category" dataKey="name" width={150} tick={{ ...AXIS, fontSize: 11 }} interval={0} />
        <Tooltip formatter={(v) => `${fmt(Number(v), 1)}%`} />
        <Legend />
        {[1, 2, 3, 4, 5].map((s) => (
          <Bar key={s} dataKey={`${s}★`} stackId="d" fill={STAR_COLORS[s - 1]} />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}

export function CompareSentimentChart({ places }: { places: PlaceAnalysis[] }) {
  const data = places.map((p) => ({
    name: short(p.place.name, 24),
    Positivo: p.sentiment.positivePct,
    Neutral: p.sentiment.neutralPct,
    Negativo: p.sentiment.negativePct,
  }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
        <XAxis type="number" domain={[0, 100]} unit="%" tick={AXIS} />
        <YAxis type="category" dataKey="name" width={150} tick={{ ...AXIS, fontSize: 11 }} interval={0} />
        <Tooltip formatter={(v) => `${fmt(Number(v), 1)}%`} />
        <Legend />
        <Bar dataKey="Positivo" stackId="s" fill={SENTIMENT_COLORS.positivo} />
        <Bar dataKey="Neutral" stackId="s" fill={SENTIMENT_COLORS.neutral} />
        <Bar dataKey="Negativo" stackId="s" fill={SENTIMENT_COLORS.negativo} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function CompareRadarChart({ matrix, summary }: { matrix: ThemeMatrixRow[]; summary: CompareSummaryRow[] }) {
  const data = matrix.map((r) => {
    const o: Record<string, string | number> = { theme: THEME_BY_ID[r.themeId]?.short ?? r.themeName };
    r.values.forEach((v, i) => (o[`p${i}`] = v.percent));
    return o;
  });
  return (
    <ResponsiveContainer width="100%" height="100%">
      <RadarChart data={data} outerRadius="72%">
        <PolarGrid />
        <PolarAngleAxis dataKey="theme" tick={{ fontSize: 11, fill: "#334155" }} />
        <PolarRadiusAxis tick={{ fontSize: 10 }} angle={90} />
        {summary.map((s, i) => (
          <Radar key={s.placeId} name={short(s.name, 30)} dataKey={`p${i}`} stroke={s.color} fill={s.color} fillOpacity={0.15} strokeWidth={2} />
        ))}
        <Tooltip formatter={(v) => `${fmt(Number(v), 1)}%`} />
        <Legend />
      </RadarChart>
    </ResponsiveContainer>
  );
}

export function CompareNetChart({ matrix, summary }: { matrix: ThemeMatrixRow[]; summary: CompareSummaryRow[] }) {
  const data = matrix.map((r) => {
    const o: Record<string, string | number | null> = { theme: THEME_BY_ID[r.themeId]?.short ?? r.themeName };
    r.values.forEach((v, i) => (o[`p${i}`] = v.netSentiment));
    return o;
  });
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 12, right: 12, left: 0, bottom: 40 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="theme" tick={{ ...AXIS, fontSize: 11 }} angle={-30} textAnchor="end" interval={0} height={50} />
        <YAxis domain={[-100, 100]} tick={AXIS} />
        <ReferenceLine y={0} stroke="#0f172a" />
        <Tooltip formatter={(v) => (v === null || v === undefined ? "—" : fmt(Number(v), 1))} />
        <Legend verticalAlign="top" />
        {summary.map((s, i) => (
          <Bar key={s.placeId} dataKey={`p${i}`} name={short(s.name, 30)} fill={s.color} radius={[3, 3, 0, 0]} />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}
