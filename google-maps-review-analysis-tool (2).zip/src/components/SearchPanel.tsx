"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  api,
  cleanKey,
  estimateSerpCredits,
  extractReviews,
  GOOGLE_KEY_RE,
  loadKeys,
  saveKeys,
  SERPAPI_KEY_RE,
  type ApiKeys,
  type Notify,
} from "@/lib/client";
import { fmt, fmtInt } from "@/lib/format";
import { Alert, Badge, Button, Card, Spinner, Stars } from "./ui";

interface Candidate {
  provider: "google" | "serpapi";
  externalId: string;
  name: string;
  address: string | null;
  rating: number | null;
  ratingCount: number | null;
  category: string | null;
  mapsUrl: string | null;
  lat: number | null;
  lng: number | null;
  thumbnail: string | null;
}

type Provider = "google" | "serpapi";

interface Verification {
  status: "checking" | "ok" | "error";
  message?: string;
  source?: "browser" | "server" | null;
  plan?: string | null;
  searchesLeft?: number | null;
  searchesPerMonth?: number | null;
}

const MAX_OPTIONS = [20, 50, 100, 200, 300, 500];
const LABEL: Record<Provider, string> = { google: "Google Places API", serpapi: "SerpAPI" };

const TEMPLATE =
  "\uFEFFautor,calificacion,fecha,texto\n" +
  'Ana López,5,2025-01-15,"Excelente servicio, la comida deliciosa y el lugar muy limpio"\n' +
  'Carlos Pech,2,2025-02-03,"Tardaron más de una hora en atendernos y los precios son caros"\n' +
  'María Chan,4,2025-02-20,"Buen ambiente y vista a la laguna, aunque no hay estacionamiento"\n';

function errMsg(e: unknown) {
  return e instanceof Error ? e.message : "Ocurrió un error.";
}

export function SearchPanel({
  config,
  onSaved,
  onDemo,
  notify,
}: {
  config: { google: boolean; serpapi: boolean } | null;
  onSaved: (id: number) => void;
  onDemo: (ids: number[]) => void;
  notify: Notify;
}) {
  const [keys, setKeys] = useState<ApiKeys>({ google: "", serpapi: "" });
  const [keysLoaded, setKeysLoaded] = useState(false);
  const [reveal, setReveal] = useState(false);
  const [verif, setVerif] = useState<Partial<Record<Provider, Verification>>>({});
  const [provider, setProvider] = useState<Provider>("serpapi");
  const [userPicked, setUserPicked] = useState(false);
  const [promptOpen, setPromptOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Candidate[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [extracting, setExtracting] = useState<string | null>(null);
  const [progress, setProgress] = useState<{ name: string; collected: number; target: number; pages: number } | null>(null);
  const [maxReviews, setMaxReviews] = useState(100);
  const [sort, setSort] = useState("relevant");
  const [demoLoading, setDemoLoading] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importText, setImportText] = useState("");
  const [importName, setImportName] = useState("");
  const [importAddress, setImportAddress] = useState("");
  const [importCategory, setImportCategory] = useState("");
  const [importRating, setImportRating] = useState("");
  const [importing, setImporting] = useState(false);
  const [fileKey, setFileKey] = useState(0);
  const timers = useRef<Partial<Record<Provider, ReturnType<typeof setTimeout>>>>({});
  const initialCheckDone = useRef(false);

  const serverHas = (p: Provider) => Boolean(p === "google" ? config?.google : config?.serpapi);
  const localKey = (p: Provider) => (p === "google" ? keys.google : keys.serpapi);
  const hasKey = (p: Provider) => Boolean(localKey(p) || serverHas(p));
  const googleOk = hasKey("google");
  const serpOk = hasKey("serpapi");

  const verify = useCallback(async (p: Provider): Promise<boolean> => {
    setVerif((v) => ({ ...v, [p]: { status: "checking" } }));
    try {
      const r = await api<Omit<Verification, "status">>("/api/keys/verify", { json: { provider: p } });
      setVerif((v) => ({ ...v, [p]: { ...r, status: "ok" } }));
      return true;
    } catch (e) {
      setVerif((v) => ({ ...v, [p]: { status: "error", message: errMsg(e) } }));
      return false;
    }
  }, []);

  useEffect(() => {
    setKeys(loadKeys());
    setKeysLoaded(true);
  }, []);

  // Verificación inicial (gratuita) de las claves disponibles.
  useEffect(() => {
    if (initialCheckDone.current || !keysLoaded || config === null) return;
    initialCheckDone.current = true;
    const stored = loadKeys();
    if (stored.serpapi || config.serpapi) void verify("serpapi");
    if (stored.google || config.google) void verify("google");
  }, [keysLoaded, config, verify]);

  // Selección automática del proveedor (SerpAPI si está disponible) mientras el usuario no elija.
  useEffect(() => {
    if (userPicked) return;
    if (serpOk) setProvider("serpapi");
    else if (googleOk) setProvider("google");
  }, [googleOk, serpOk, userPicked]);

  useEffect(() => {
    const t = timers.current;
    return () => {
      Object.values(t).forEach((x) => x && clearTimeout(x));
    };
  }, []);

  function updateKey(p: Provider, raw: string, fromInline = false) {
    if (fromInline) setPromptOpen(true);
    const value = cleanKey(raw);
    let target: Provider = p;
    if (p === "google" && SERPAPI_KEY_RE.test(value)) {
      target = "serpapi";
      notify("Esa clave tiene el formato de SerpAPI, así que la coloqué en el campo de SerpAPI.", "info");
    } else if (p === "serpapi" && GOOGLE_KEY_RE.test(value)) {
      target = "google";
      notify("Esa clave tiene el formato de Google (empieza con «AIza»), así que la coloqué en el campo de Google.", "info");
    }
    const next: ApiKeys = { ...keys, [target]: value };
    if (target !== p) next[p] = "";
    setKeys(next);
    saveKeys(next); // se guarda de inmediato: ya no depende de un botón
    setError(null);
    setVerif((v) => ({ ...v, [target]: undefined, ...(target !== p ? { [p]: undefined } : {}) }));
    if (value) setProvider(target);
    const old = timers.current[target];
    if (old) clearTimeout(old);
    const plausible = target === "serpapi" ? value.length >= 32 : value.length >= 30;
    if (plausible || (!value && serverHas(target))) {
      timers.current[target] = setTimeout(() => void verify(target), 500);
    }
  }

  function clearKeys() {
    const empty = { google: "", serpapi: "" };
    setKeys(empty);
    saveKeys(empty);
    setVerif({});
    notify("Claves eliminadas de este navegador.", "info");
    if (config?.serpapi) void verify("serpapi");
    if (config?.google) void verify("google");
  }

  async function search(e: FormEvent) {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    if (!hasKey(provider)) {
      setError(`Primero pega tu clave de ${LABEL[provider]} en el campo de arriba.`);
      return;
    }
    setSearching(true);
    setResults(null);
    setError(null);
    try {
      const r = await api<{ results: Candidate[] }>("/api/search", { json: { query: q, provider } });
      setResults(r.results);
      if (!r.results.length) {
        setError("No se encontraron lugares con esa búsqueda. Prueba con otro nombre o agrega la ciudad (ej. «Museo de la Cultura Maya Chetumal»).");
      }
      if (provider === "serpapi") void verify("serpapi");
    } catch (err) {
      setError(errMsg(err));
      if (/clave|key/i.test(errMsg(err))) void verify(provider);
    } finally {
      setSearching(false);
    }
  }

  async function extract(c: Candidate) {
    const target = c.provider === "serpapi" ? maxReviews : 5;
    setExtracting(c.externalId);
    setError(null);
    setProgress({ name: c.name, collected: 0, target, pages: 0 });
    try {
      const r = await extractReviews(
        {
          provider: c.provider,
          externalId: c.externalId,
          maxReviews,
          sort,
          fallback: {
            name: c.name,
            address: c.address,
            category: c.category,
            rating: c.rating,
            ratingCount: c.ratingCount,
            mapsUrl: c.mapsUrl,
            lat: c.lat,
            lng: c.lng,
          },
        },
        (p) => setProgress({ name: c.name, collected: p.collected, target, pages: p.pages }),
      );
      notify(
        `Se extrajeron ${r.collected} reseñas de «${r.name}» (${r.inserted} nuevas; total guardado: ${r.total})${
          c.provider === "serpapi" ? ` usando ${r.pages} consulta(s) de SerpAPI` : ""
        }.`,
        "success",
      );
      r.notes.forEach((n) => notify(n, "info"));
      if (r.error) notify(`La extracción se detuvo antes de terminar: ${r.error} Se conservaron las reseñas obtenidas.`, "error");
      if (c.provider === "serpapi") void verify("serpapi");
      onSaved(r.id);
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setExtracting(null);
      setProgress(null);
    }
  }

  async function loadDemo() {
    setDemoLoading(true);
    try {
      const r = await api<{ ids: number[] }>("/api/demo", { method: "POST" });
      notify("Se cargaron 4 establecimientos ficticios de demostración.", "success");
      onDemo(r.ids);
    } catch (err) {
      notify(errMsg(err), "error");
    } finally {
      setDemoLoading(false);
    }
  }

  async function doImport(e: FormEvent) {
    e.preventDefault();
    if (!importFile && !importText.trim()) {
      notify("Selecciona un archivo o pega reseñas.", "error");
      return;
    }
    setImporting(true);
    try {
      const fd = new FormData();
      if (importFile) fd.append("file", importFile);
      if (importText.trim()) fd.append("text", importText);
      fd.append("name", importName);
      fd.append("address", importAddress);
      fd.append("category", importCategory);
      fd.append("googleRating", importRating);
      const r = await api<{ id: number; inserted: number; skipped: number }>("/api/import", { form: fd });
      notify(`Se importaron ${r.inserted} reseñas${r.skipped ? ` (${r.skipped} filas omitidas por no tener calificación válida)` : ""}.`, "success");
      setImportFile(null);
      setImportText("");
      setImportName("");
      setImportAddress("");
      setImportCategory("");
      setImportRating("");
      setFileKey((k) => k + 1);
      onSaved(r.id);
    } catch (err) {
      notify(errMsg(err), "error");
    } finally {
      setImporting(false);
    }
  }

  function keyBadge(p: Provider): ReactNode {
    const v = verif[p];
    if (!hasKey(p)) return <Badge className="bg-slate-100 text-slate-600">Sin clave</Badge>;
    if (v?.status === "checking")
      return (
        <Badge className="bg-slate-100 text-slate-600">
          <Spinner className="h-3 w-3" /> Verificando…
        </Badge>
      );
    if (v?.status === "error") return <Badge className="bg-red-100 text-red-800">✗ Clave no válida</Badge>;
    const origin = localKey(p) ? "Clave guardada" : "Clave del servidor";
    if (v?.status === "ok")
      return (
        <Badge className="bg-green-100 text-green-800">
          ✓ {origin}
          {p === "serpapi" && v.searchesLeft !== null && v.searchesLeft !== undefined ? ` · ${fmtInt(v.searchesLeft)} búsquedas` : ""}
        </Badge>
      );
    return <Badge className="bg-sky-100 text-sky-800">{origin}</Badge>;
  }

  /** Campo de clave (función de render, no componente, para no perder el foco al escribir). */
  function renderKeyField(p: Provider, idSuffix: string): ReactNode {
    const value = localKey(p);
    const v = verif[p];
    return (
      <div className="space-y-1.5">
        <label htmlFor={`key-${p}-${idSuffix}`} className="block text-sm font-medium text-slate-700">
          {p === "google" ? "Clave de Google Maps · Places API (New)" : "Clave de SerpAPI"}
        </label>
        <div className="flex gap-2">
          <input
            id={`key-${p}-${idSuffix}`}
            type={reveal ? "text" : "password"}
            value={value}
            onChange={(e) => updateKey(p, e.target.value, idSuffix === "inline")}
            placeholder={
              serverHas(p) ? "Opcional: ya hay una clave configurada en el servidor" : p === "google" ? "AIza…" : "Pega aquí tu API key de SerpAPI (64 caracteres)"
            }
            autoComplete="off"
            spellCheck={false}
            className="min-w-0 flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono text-xs outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
          />
          <Button type="button" size="sm" variant="secondary" onClick={() => void verify(p)} disabled={!hasKey(p)} loading={v?.status === "checking"}>
            Verificar
          </Button>
        </div>
        {v?.status === "ok" && (
          <p className="text-xs text-green-700">
            ✓ Clave válida{v.source === "server" ? " (configurada en el servidor)" : " · guardada en este navegador"}
            {p === "serpapi" && v.plan ? ` · ${v.plan}` : ""}
            {p === "serpapi" && v.searchesLeft !== null && v.searchesLeft !== undefined
              ? ` · ${fmtInt(v.searchesLeft)}${v.searchesPerMonth ? ` de ${fmtInt(v.searchesPerMonth)}` : ""} búsquedas disponibles este mes`
              : ""}
          </p>
        )}
        {v?.status === "error" && <p className="text-xs font-medium text-red-700">✗ {v.message}</p>}
        {!value && serverHas(p) && v?.status !== "ok" && <p className="text-xs text-slate-500">Se usará la clave configurada en el servidor.</p>}
        {value && !v && <p className="text-xs text-slate-500">Guardada automáticamente en este navegador.</p>}
      </div>
    );
  }

  const providerCard = (p: Provider, title: string, desc: string, tag?: string) => (
    <button
      type="button"
      onClick={() => {
        setProvider(p);
        setUserPicked(true);
        setPromptOpen(false);
        setError(null);
      }}
      className={`flex-1 rounded-2xl border-2 p-4 text-left transition ${
        provider === p ? "border-emerald-600 bg-emerald-50" : "border-slate-200 bg-white hover:border-slate-300"
      }`}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="font-semibold text-slate-900">
          {title}
          {tag && <span className="ml-2 rounded-full bg-emerald-700 px-2 py-0.5 text-[10px] font-semibold uppercase text-white">{tag}</span>}
        </span>
        {keyBadge(p)}
      </div>
      <p className="mt-1 text-xs text-slate-600">{desc}</p>
    </button>
  );

  const selectedVerif = verif[provider];
  // El recuadro permanece visible mientras se escribe la clave y hasta que la verificación sea exitosa.
  const needsKey = !hasKey(provider) || selectedVerif?.status === "error" || (promptOpen && selectedVerif?.status !== "ok");
  const credits = estimateSerpCredits(maxReviews);
  const left = verif.serpapi?.searchesLeft;

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="space-y-6 lg:col-span-2">
        <Card title="Buscar un lugar o empresa en Google Maps" subtitle="Escribe el nombre (de preferencia con la ciudad) o pega el enlace del lugar en Google Maps.">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row">
            {providerCard(
              "serpapi",
              "SerpAPI · Google Maps Reviews",
              "Extrae decenas o cientos de reseñas de Google Maps (≈1 crédito por cada 20 reseñas).",
              "Recomendado",
            )}
            {providerCard("google", "Google Places API (oficial)", "Calificación global, total de opiniones y hasta 5 reseñas por lugar.")}
          </div>

          {needsKey && (
            <div className="mb-4 rounded-2xl border border-amber-200 bg-amber-50 p-4">
              <p className="mb-3 text-sm text-amber-900">
                {hasKey(provider) && selectedVerif?.status === "error" ? (
                  <>
                    La clave de <strong>{LABEL[provider]}</strong> no pasó la verificación. Corrígela aquí:
                  </>
                ) : hasKey(provider) ? (
                  <>
                    Clave de <strong>{LABEL[provider]}</strong> guardada en este navegador; verificando que funcione…
                  </>
                ) : (
                  <>
                    Para buscar con <strong>{LABEL[provider]}</strong> pega tu clave aquí. Se guarda automáticamente solo en este navegador.
                  </>
                )}
              </p>
              {renderKeyField(provider, "inline")}
              <p className="mt-2 text-xs text-amber-800">
                {provider === "serpapi" ? (
                  <>
                    ¿No tienes clave? Crea una cuenta gratuita en{" "}
                    <a className="font-medium underline" href="https://serpapi.com/manage-api-key" target="_blank" rel="noreferrer">
                      serpapi.com/manage-api-key
                    </a>{" "}
                    y copia tu «Private API Key».
                  </>
                ) : (
                  <>
                    Habilita «Places API (New)» en{" "}
                    <a className="font-medium underline" href="https://console.cloud.google.com/apis/library/places.googleapis.com" target="_blank" rel="noreferrer">
                      Google Cloud Console
                    </a>{" "}
                    y crea una clave en «Credenciales».
                  </>
                )}
              </p>
            </div>
          )}

          <form onSubmit={search} className="flex flex-col gap-3 sm:flex-row">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ej. Museo de la Cultura Maya Chetumal  ·  https://maps.app.goo.gl/…"
              className="flex-1 rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
            />
            <Button type="submit" loading={searching} disabled={!query.trim() || extracting !== null}>
              Buscar
            </Button>
          </form>

          {provider === "serpapi" && (
            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
              <label className="flex items-center gap-2">
                <span className="text-slate-600">Reseñas a extraer:</span>
                <select value={maxReviews} onChange={(e) => setMaxReviews(Number(e.target.value))} className="rounded-lg border border-slate-300 px-2 py-1">
                  {MAX_OPTIONS.map((n) => (
                    <option key={n} value={n}>
                      {n} (≈{estimateSerpCredits(n)} créditos)
                    </option>
                  ))}
                </select>
              </label>
              <label className="flex items-center gap-2">
                <span className="text-slate-600">Orden:</span>
                <select value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-lg border border-slate-300 px-2 py-1">
                  <option value="relevant">Más relevantes</option>
                  <option value="newest">Más recientes</option>
                  <option value="highest">Mejor calificadas</option>
                  <option value="lowest">Peor calificadas</option>
                </select>
              </label>
              <span className={`text-xs ${left !== null && left !== undefined && credits > left ? "font-semibold text-red-700" : "text-slate-500"}`}>
                Búsqueda: 1 crédito · Extracción: ≈{credits} créditos
                {left !== null && left !== undefined ? ` · Disponibles: ${fmtInt(left)}` : ""}
              </span>
            </div>
          )}

          {error && (
            <div className="mt-4">
              <Alert kind="error">
                <div className="flex items-start justify-between gap-3">
                  <span>{error}</span>
                  <button onClick={() => setError(null)} className="text-xs opacity-60 hover:opacity-100" aria-label="Cerrar">
                    ✕
                  </button>
                </div>
              </Alert>
            </div>
          )}

          {progress && (
            <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 p-4">
              <div className="flex items-center justify-between gap-3 text-sm text-emerald-900">
                <span className="flex items-center gap-2 font-medium">
                  <Spinner className="h-4 w-4" /> Extrayendo reseñas de «{progress.name}»…
                </span>
                <span>
                  {progress.collected} de {progress.target}
                  {progress.pages ? ` · ${progress.pages} consulta(s)` : ""}
                </span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-emerald-100">
                <div
                  className="h-full rounded-full bg-emerald-600 transition-all duration-500"
                  style={{ width: `${Math.max(4, Math.min(100, (progress.collected / Math.max(1, progress.target)) * 100))}%` }}
                />
              </div>
              <p className="mt-2 text-xs text-emerald-800">Al terminar se abrirá automáticamente el análisis.</p>
            </div>
          )}

          {results && results.length > 0 && (
            <ul className="mt-5 divide-y divide-slate-100 rounded-xl border border-slate-200">
              {results.map((c) => (
                <li key={`${c.provider}-${c.externalId}`} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-slate-900">{c.name}</p>
                    <p className="truncate text-sm text-slate-500">{c.address ?? "Dirección no disponible"}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-600">
                      {c.rating !== null && (
                        <span className="flex items-center gap-1">
                          <Stars value={c.rating} size="text-xs" /> {fmt(c.rating, 1)} ({fmtInt(c.ratingCount)} opiniones)
                        </span>
                      )}
                      {c.category && <Badge>{c.category}</Badge>}
                      {c.mapsUrl && (
                        <a href={c.mapsUrl} target="_blank" rel="noreferrer" className="text-emerald-700 underline">
                          Ver en Google Maps
                        </a>
                      )}
                    </div>
                  </div>
                  <Button onClick={() => extract(c)} loading={extracting === c.externalId} disabled={extracting !== null}>
                    {c.provider === "serpapi" ? `Extraer ${maxReviews} reseñas y analizar` : "Extraer y analizar"}
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card
          title="Importar reseñas desde archivo o texto"
          subtitle="CSV, TSV, TXT o Excel (.xlsx) con columnas como calificacion, texto, autor y fecha. También puedes copiar y pegar desde Excel."
          actions={
            <a href={`data:text/csv;charset=utf-8,${encodeURIComponent(TEMPLATE)}`} download="plantilla-resenas.csv" className="text-sm font-medium text-emerald-700 underline">
              Descargar plantilla CSV
            </a>
          }
        >
          <form onSubmit={doImport} className="grid gap-3 sm:grid-cols-2">
            <input value={importName} onChange={(e) => setImportName(e.target.value)} placeholder="Nombre del establecimiento" className="rounded-xl border border-slate-300 px-3 py-2 text-sm" />
            <input value={importCategory} onChange={(e) => setImportCategory(e.target.value)} placeholder="Categoría (opcional)" className="rounded-xl border border-slate-300 px-3 py-2 text-sm" />
            <input value={importAddress} onChange={(e) => setImportAddress(e.target.value)} placeholder="Dirección (opcional)" className="rounded-xl border border-slate-300 px-3 py-2 text-sm" />
            <input value={importRating} onChange={(e) => setImportRating(e.target.value)} placeholder="Calificación global en Google (opcional, ej. 4.5)" className="rounded-xl border border-slate-300 px-3 py-2 text-sm" />
            <input
              key={fileKey}
              type="file"
              accept=".csv,.tsv,.txt,.xlsx,.xlsm"
              onChange={(e) => setImportFile(e.target.files?.[0] ?? null)}
              className="text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-emerald-50 file:px-3 file:py-2 file:font-medium file:text-emerald-800 sm:col-span-2"
            />
            <textarea
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              rows={5}
              placeholder={"…o pega aquí las reseñas (una por línea). Ejemplos:\ncalificacion,texto\n5,Excelente atención y comida deliciosa\n2 | El servicio fue muy lento"}
              className="rounded-xl border border-slate-300 px-3 py-2 font-mono text-xs sm:col-span-2"
            />
            <div className="sm:col-span-2">
              <Button type="submit" loading={importing} variant="secondary">
                Importar y analizar
              </Button>
            </div>
          </form>
        </Card>
      </div>

      <div className="space-y-6">
        <Card
          title="Configurar claves de API"
          subtitle="Pega tu clave y listo: se guarda automáticamente solo en este navegador y se verifica sin gastar créditos."
          actions={
            <Button variant="ghost" size="sm" onClick={() => setReveal((s) => !s)}>
              {reveal ? "Ocultar" : "Mostrar"} caracteres
            </Button>
          }
        >
          <div className="space-y-4 text-sm">
            {renderKeyField("serpapi", "config")}
            {renderKeyField("google", "config")}
            <Button size="sm" variant="secondary" onClick={clearKeys} disabled={!keys.google && !keys.serpapi}>
              Borrar claves de este navegador
            </Button>
            <div className="space-y-2 rounded-xl bg-slate-50 p-3 text-xs text-slate-600">
              <p>
                <strong>SerpAPI:</strong> crea una cuenta en{" "}
                <a className="text-emerald-700 underline" href="https://serpapi.com/manage-api-key" target="_blank" rel="noreferrer">
                  serpapi.com
                </a>{" "}
                (plan gratuito con búsquedas mensuales) y copia tu «Private API Key».
              </p>
              <p>
                <strong>Google:</strong> en{" "}
                <a className="text-emerald-700 underline" href="https://console.cloud.google.com/apis/library/places.googleapis.com" target="_blank" rel="noreferrer">
                  Google Cloud Console
                </a>{" "}
                habilita «Places API (New)» y crea una clave en «Credenciales».
              </p>
              <p>
                <strong>Administrador:</strong> las variables de entorno <code>SERPAPI_API_KEY</code> y <code>GOOGLE_MAPS_API_KEY</code> del servidor permiten usar la herramienta sin
                pegar claves; la clave del navegador, si existe, tiene prioridad.
              </p>
            </div>
          </div>
        </Card>

        <Card title="¿Primera vez? Prueba con datos de demostración" subtitle="Cuatro establecimientos ficticios de Chetumal y Bacalar con cientos de reseñas para practicar el análisis y la comparación.">
          <Button onClick={loadDemo} loading={demoLoading} className="w-full" variant="secondary">
            Cargar establecimientos de demostración
          </Button>
          <p className="mt-3 text-xs text-slate-500">Los datos de demostración son simulados y están marcados como «(demo)». No representan negocios reales.</p>
        </Card>
      </div>
    </div>
  );
}
