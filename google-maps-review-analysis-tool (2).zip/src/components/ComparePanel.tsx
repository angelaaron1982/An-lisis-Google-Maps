"use client";

import { useEffect, useRef, useState } from "react";
import type { ComparisonResult, PlaceSummary } from "@/lib/analysis/types";
import { api, captureCharts, downloadReport, type Notify } from "@/lib/client";
import { fmt, fmtInt, fmtP, pct, signed } from "@/lib/format";
import { ExportButtons } from "./AnalysisPanel";
import { ChartCard, CompareDistributionChart, CompareMeansChart, CompareNetChart, CompareRadarChart, CompareSentimentChart } from "./Charts";
import { Alert, Badge, Button, Card, EmptyState, Spinner } from "./ui";

function heat(net: number | null): string {
  if (net === null) return "transparent";
  const a = 0.08 + (Math.min(100, Math.abs(net)) / 100) * 0.55;
  return net >= 0 ? `rgba(22,163,74,${a})` : `rgba(220,38,38,${a})`;
}

export function ComparePanel({
  places,
  selected,
  onToggle,
  onGoPlaces,
  notify,
}: {
  places: PlaceSummary[];
  selected: number[];
  onToggle: (id: number) => void;
  onGoPlaces: () => void;
  notify: Notify;
}) {
  const [result, setResult] = useState<ComparisonResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [exporting, setExporting] = useState<"docx" | "xlsx" | null>(null);
  const chartsRef = useRef<HTMLDivElement>(null);
  const key = selected.join(",");

  useEffect(() => {
    const ids = key ? key.split(",").map(Number) : [];
    if (ids.length < 2) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    api<{ comparison: ComparisonResult }>("/api/compare", { json: { ids } })
      .then((r) => {
        if (!cancelled) setResult(r.comparison);
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : "Error al comparar.");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [key]);

  async function exportReport(format: "docx" | "xlsx") {
    if (!result) return;
    setExporting(format);
    try {
      const charts = await captureCharts(chartsRef.current);
      await downloadReport({ format, scope: "compare", ids: result.summary.map((s) => s.placeId), charts });
      notify(`Reporte comparativo de ${format === "docx" ? "Word" : "Excel"} generado.`, "success");
    } catch (e) {
      notify(e instanceof Error ? e.message : "No se pudo generar el reporte.", "error");
    } finally {
      setExporting(null);
    }
  }

  if (places.length < 2) {
    return (
      <EmptyState title="Necesitas al menos dos establecimientos" action={<Button onClick={onGoPlaces}>Ver establecimientos</Button>}>
        Extrae o importa reseñas de varios lugares (o carga los datos de demostración) para compararlos.
      </EmptyState>
    );
  }

  const ready = selected.length >= 2 && result !== null;

  return (
    <div className="space-y-6">
      <Card
        title="Selecciona los establecimientos a comparar"
        subtitle="Elige de 2 a 8 lugares (por ejemplo, tu negocio y sus competidores)."
        actions={ready ? <ExportButtons onExport={exportReport} exporting={exporting} /> : undefined}
      >
        <div className="flex flex-wrap gap-2">
          {places.map((p) => {
            const on = selected.includes(p.id);
            return (
              <button
                key={p.id}
                onClick={() => onToggle(p.id)}
                className={`rounded-full border px-3 py-1.5 text-sm transition ${
                  on ? "border-emerald-700 bg-emerald-700 text-white" : "border-slate-300 bg-white text-slate-700 hover:border-slate-400"
                }`}
              >
                {on ? "✓ " : ""}
                {p.name} <span className={on ? "text-emerald-100" : "text-slate-400"}>({p.reviewCount})</span>
              </button>
            );
          })}
        </div>
        {selected.length < 2 && <p className="mt-3 text-sm text-amber-700">Selecciona al menos dos establecimientos.</p>}
        {loading && (
          <p className="mt-3 flex items-center gap-2 text-sm text-slate-500">
            <Spinner className="h-4 w-4" /> Calculando comparación…
          </p>
        )}
      </Card>

      {error && <Alert kind="error">{error}</Alert>}

      {ready && result && (
        <>
          <Card title="Indicadores comparativos">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[980px] text-sm">
                <thead>
                  <tr className="border-b text-left text-xs uppercase text-slate-500">
                    <th className="py-2">Establecimiento</th>
                    <th className="py-2 text-right">Google</th>
                    <th className="py-2 text-right">n</th>
                    <th className="py-2 text-right">Media</th>
                    <th className="py-2 text-right">Mediana</th>
                    <th className="py-2 text-right">DE</th>
                    <th className="py-2 text-right">% pos.</th>
                    <th className="py-2 text-right">% neg.</th>
                    <th className="py-2 text-right">Satisf. neta</th>
                    <th className="py-2 pl-3">Fortaleza</th>
                    <th className="py-2">Área de oportunidad</th>
                  </tr>
                </thead>
                <tbody>
                  {result.summary.map((s) => (
                    <tr key={s.placeId} className="border-b border-slate-100">
                      <td className="py-2">
                        <span className="flex items-center gap-2 font-medium text-slate-800">
                          <span className="h-3 w-3 shrink-0 rounded-full" style={{ backgroundColor: s.color }} />
                          {s.name}
                        </span>
                      </td>
                      <td className="py-2 text-right">
                        {s.googleRating !== null ? `${fmt(s.googleRating, 1)}★` : "—"}
                        <span className="block text-[11px] text-slate-400">{fmtInt(s.googleRatingCount)}</span>
                      </td>
                      <td className="py-2 text-right">{s.n}</td>
                      <td className="py-2 text-right font-semibold">{fmt(s.mean)}</td>
                      <td className="py-2 text-right">{fmt(s.median, 1)}</td>
                      <td className="py-2 text-right">{fmt(s.stdDev)}</td>
                      <td className="py-2 text-right text-green-700">{pct(s.positivePct)}</td>
                      <td className="py-2 text-right text-red-700">{pct(s.negativePct)}</td>
                      <td className={`py-2 text-right font-semibold ${s.satisfactionIndex >= 0 ? "text-green-700" : "text-red-700"}`}>{signed(s.satisfactionIndex)}</td>
                      <td className="py-2 pl-3 text-xs">{s.strength ?? "—"}</td>
                      <td className="py-2 text-xs">{s.weakness ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card title="Hallazgos de la comparación">
              <ul className="space-y-2 text-sm text-slate-700">
                {result.insights.map((t, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-emerald-600" />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </Card>
            <Card title="Pruebas estadísticas" subtitle="Nivel de significancia α = 0.05">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-xs uppercase text-slate-500">
                    <th className="py-2">Prueba</th>
                    <th className="py-2 text-right">Estadístico</th>
                    <th className="py-2 text-right">p</th>
                    <th className="py-2 text-right">Efecto</th>
                    <th className="py-2 text-right">Resultado</th>
                  </tr>
                </thead>
                <tbody>
                  {result.anova && (
                    <TestRow name="ANOVA de un factor" stat={`F(${result.anova.dfBetween}, ${result.anova.dfWithin}) = ${fmt(result.anova.f, 3)}`} p={result.anova.p} effect={`η² = ${fmt(result.anova.etaSquared, 3)}`} />
                  )}
                  {result.kruskal && (
                    <TestRow name="Kruskal-Wallis" stat={`H(${result.kruskal.df}) = ${fmt(result.kruskal.h, 3)}`} p={result.kruskal.p} effect={`ε² = ${fmt(result.kruskal.epsilonSquared, 3)}`} />
                  )}
                  {result.welch && (
                    <TestRow name="t de Welch" stat={`t(${fmt(result.welch.df, 1)}) = ${fmt(result.welch.t, 3)}`} p={result.welch.p} effect={`d = ${fmt(result.welch.cohenD, 2)}`} />
                  )}
                  {result.chiSquare && (
                    <TestRow name="Chi-cuadrada (sentimiento)" stat={`χ²(${result.chiSquare.df}) = ${fmt(result.chiSquare.chi2, 3)}`} p={result.chiSquare.p} effect={`V = ${fmt(result.chiSquare.cramersV, 3)}`} />
                  )}
                </tbody>
              </table>
              {!result.anova && !result.kruskal && <p className="mt-3 text-sm text-slate-500">Datos insuficientes para las pruebas.</p>}
              <p className="mt-3 text-xs text-slate-500">
                Kruskal-Wallis es preferible para calificaciones (escala ordinal). Un p &lt; 0.05 indica diferencias estadísticamente significativas entre establecimientos.
              </p>
            </Card>
          </div>

          <div ref={chartsRef} className="grid gap-4 lg:grid-cols-2">
            <ChartCard exportKey="cmp-promedios" title="Calificación promedio: muestra vs. Google" height={320}>
              <CompareMeansChart summary={result.summary} />
            </ChartCard>
            <ChartCard exportKey="cmp-distribucion" title="Distribución de calificaciones (%)" height={Math.max(240, 90 + result.places.length * 48)}>
              <CompareDistributionChart places={result.places} />
            </ChartCard>
            <ChartCard exportKey="cmp-sentimiento" title="Sentimiento por establecimiento (%)" height={Math.max(240, 90 + result.places.length * 48)}>
              <CompareSentimentChart places={result.places} />
            </ChartCard>
            <ChartCard exportKey="cmp-radar" title="Perfil de temas: % de reseñas que mencionan cada tema" height={380}>
              <CompareRadarChart matrix={result.themeMatrix} summary={result.summary} />
            </ChartCard>
            <ChartCard exportKey="cmp-neto" title="Sentimiento neto por tema (−100 a +100)" height={380} className="lg:col-span-2">
              <CompareNetChart matrix={result.themeMatrix} summary={result.summary} />
            </ChartCard>
          </div>

          <Card title="Mapa de calor por tema" subtitle="Color = sentimiento neto (verde positivo, rojo negativo). Debajo: % de menciones y calificación promedio.">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-sm">
                <thead>
                  <tr className="border-b text-left text-xs uppercase text-slate-500">
                    <th className="py-2">Tema</th>
                    {result.summary.map((s) => (
                      <th key={s.placeId} className="px-2 py-2 text-center">
                        {s.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {result.themeMatrix.map((r) => (
                    <tr key={r.themeId} className="border-b border-slate-100">
                      <td className="py-2 pr-2 font-medium text-slate-800">
                        <span className="flex items-center gap-2">
                          <span className="h-3 w-3 shrink-0 rounded-full" style={{ backgroundColor: r.color }} />
                          {r.themeName}
                        </span>
                      </td>
                      {r.values.map((v) => (
                        <td key={v.placeId} className="px-2 py-2 text-center" style={{ backgroundColor: heat(v.netSentiment) }}>
                          <span className="block font-semibold">{v.netSentiment === null ? "—" : signed(v.netSentiment)}</span>
                          <span className="block text-[11px] text-slate-600">
                            {pct(v.percent)} · {v.avgRating !== null ? `${fmt(v.avgRating, 1)}★` : "—"}
                          </span>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}

function TestRow({ name, stat, p, effect }: { name: string; stat: string; p: number; effect: string }) {
  const sig = p < 0.05;
  return (
    <tr className="border-b border-slate-100">
      <td className="py-2 font-medium text-slate-800">{name}</td>
      <td className="py-2 text-right font-mono text-xs">{stat}</td>
      <td className="py-2 text-right font-mono text-xs">{fmtP(p)}</td>
      <td className="py-2 text-right font-mono text-xs">{effect}</td>
      <td className="py-2 text-right">
        <Badge className={sig ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-600"}>{sig ? "Significativa" : "No significativa"}</Badge>
      </td>
    </tr>
  );
}
