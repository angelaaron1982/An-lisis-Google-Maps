"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { THEME_BY_ID } from "@/lib/analysis/themes";
import type { AnalyzedReview, ClusterResult, PlaceAnalysis, PlaceSummary, ThemeResult } from "@/lib/analysis/types";
import { api, captureCharts, downloadReport, type Notify } from "@/lib/client";
import { fmt, fmtDate, fmtInt, pct, signed, SOURCE_LABELS } from "@/lib/format";
import {
  ChartCard,
  ClusterChart,
  RatingDistributionChart,
  SentimentPieChart,
  ThemeMentionsChart,
  ThemeRatingChart,
  ThemeSentimentChart,
  TopWordsChart,
  TrendChart,
} from "./Charts";
import { Alert, Badge, Button, Card, EmptyState, SentimentBadge, Spinner, Stars, Stat } from "./ui";

const CLOUD_COLORS = ["#0b6e4f", "#0ea5e9", "#f97316", "#8b5cf6", "#ec4899", "#14b8a6", "#ca8a04", "#dc2626"];

export function ExportButtons({ onExport, exporting }: { onExport: (f: "docx" | "xlsx") => void; exporting: "docx" | "xlsx" | null }) {
  return (
    <div className="flex flex-wrap gap-2">
      <Button variant="word" onClick={() => onExport("docx")} loading={exporting === "docx"} disabled={exporting !== null}>
        ⬇ Descargar Word
      </Button>
      <Button variant="excel" onClick={() => onExport("xlsx")} loading={exporting === "xlsx"} disabled={exporting !== null}>
        ⬇ Descargar Excel
      </Button>
    </div>
  );
}

export function AnalysisPanel({
  placeId,
  places,
  refreshKey,
  onSelect,
  onGoSearch,
  notify,
}: {
  placeId: number | null;
  places: PlaceSummary[];
  refreshKey: number;
  onSelect: (id: number) => void;
  onGoSearch: () => void;
  notify: Notify;
}) {
  const [analysis, setAnalysis] = useState<PlaceAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [exporting, setExporting] = useState<"docx" | "xlsx" | null>(null);
  const chartsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!placeId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    api<{ analysis: PlaceAnalysis }>(`/api/places/${placeId}`)
      .then((r) => {
        if (!cancelled) setAnalysis(r.analysis);
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : "Error al cargar el análisis.");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [placeId, refreshKey]);

  async function exportReport(format: "docx" | "xlsx") {
    if (!analysis) return;
    setExporting(format);
    try {
      const charts = await captureCharts(chartsRef.current);
      await downloadReport({ format, scope: "place", ids: [analysis.place.id], charts });
      notify(`Reporte de ${format === "docx" ? "Word" : "Excel"} generado.`, "success");
    } catch (e) {
      notify(e instanceof Error ? e.message : "No se pudo generar el reporte.", "error");
    } finally {
      setExporting(null);
    }
  }

  if (!places.length) {
    return (
      <EmptyState title="No hay establecimientos para analizar" action={<Button onClick={onGoSearch}>Ir a buscar</Button>}>
        Primero extrae reseñas de Google Maps, importa un archivo o carga los datos de demostración.
      </EmptyState>
    );
  }

  const selector = (
    <select
      value={placeId ?? ""}
      onChange={(e) => onSelect(Number(e.target.value))}
      className="max-w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-medium"
    >
      <option value="" disabled>
        Selecciona un establecimiento…
      </option>
      {places.map((p) => (
        <option key={p.id} value={p.id}>
          {p.name} ({p.reviewCount} reseñas)
        </option>
      ))}
    </select>
  );

  if (!placeId) {
    return (
      <Card title="Selecciona un establecimiento para analizar">
        {selector}
      </Card>
    );
  }

  if (loading && !analysis) {
    return (
      <div className="flex items-center justify-center gap-3 py-20 text-slate-500">
        <Spinner /> Analizando reseñas…
      </div>
    );
  }
  if (error) return <Alert kind="error">{error}</Alert>;
  if (!analysis) return null;

  const a = analysis;
  const p = a.place;
  const s = a.stats;
  const mentioned = a.themes.filter((t) => t.mentions > 0);

  return (
    <div className="space-y-6">
      <Card>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0 space-y-2">
            {selector}
            <h2 className="text-2xl font-bold text-slate-900">{p.name}</h2>
            <p className="text-sm text-slate-600">
              {[p.category, p.address].filter(Boolean).join(" · ") || "Sin dirección"}
            </p>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <Badge className="bg-emerald-100 text-emerald-800">{SOURCE_LABELS[p.source] ?? p.source}</Badge>
              <Badge>
                Reseñas del {fmtDate(a.totals.dateFrom)} al {fmtDate(a.totals.dateTo)}
              </Badge>
              {p.mapsUrl && (
                <a href={p.mapsUrl} target="_blank" rel="noreferrer" className="font-medium text-emerald-700 underline">
                  Abrir en Google Maps
                </a>
              )}
              {loading && <Spinner className="h-4 w-4" />}
            </div>
          </div>
          <div className="flex flex-col items-start gap-2 lg:items-end">
            <ExportButtons onExport={exportReport} exporting={exporting} />
            <p className="text-xs text-slate-500">Incluye tablas, gráficas, hallazgos y el listado de reseñas.</p>
          </div>
        </div>
        {p.source === "google" && a.totals.reviews <= 10 && (
          <div className="mt-4">
            <Alert kind="info">
              La API oficial de Google entrega como máximo 5 reseñas por consulta. Usa «Actualizar» periódicamente para acumular reseñas nuevas, o SerpAPI /
              importación de archivos para muestras más grandes. Con pocas reseñas, interpreta los resultados como exploratorios.
            </Alert>
          </div>
        )}
        {p.source === "demo" && (
          <div className="mt-4">
            <Alert kind="warning">Datos simulados de demostración: úsalos solo para practicar.</Alert>
          </div>
        )}
      </Card>

      {!s ? (
        <EmptyState title="Este establecimiento no tiene reseñas guardadas" />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Stat
              label="Calificación en Google"
              value={p.googleRating !== null ? `${fmt(p.googleRating, 1)} ★` : "—"}
              hint={p.googleRatingCount ? `${fmtInt(p.googleRatingCount)} opiniones en total` : "Global del lugar"}
              accent="text-amber-600"
            />
            <Stat label="Promedio de la muestra" value={`${fmt(s.mean)} ★`} hint={`n = ${fmtInt(s.n)} · IC95% ${fmt(s.ci95[0])}–${fmt(s.ci95[1])}`} accent="text-emerald-700" />
            <Stat label="Mediana / Moda" value={`${fmt(s.median, 1)} / ${s.mode.join(", ")}`} hint={`Q1 = ${fmt(s.q1, 1)} · Q3 = ${fmt(s.q3, 1)}`} />
            <Stat label="Desviación estándar" value={fmt(s.stdDev)} hint={`CV = ${pct(s.cv)} · varianza ${fmt(s.variance)}`} />
            <Stat label="Opiniones positivas" value={pct(a.sentiment.positivePct)} hint={`Negativas: ${pct(a.sentiment.negativePct)}`} accent="text-green-700" />
            <Stat
              label="Satisfacción neta"
              value={signed(a.satisfactionIndex)}
              hint="% 4–5★ menos % 1–2★"
              accent={a.satisfactionIndex >= 0 ? "text-green-700" : "text-red-700"}
            />
            <Stat label="Reseñas con texto" value={fmtInt(a.totals.withText)} hint={`${fmt(a.totals.avgWords, 1)} palabras en promedio`} />
            <Stat
              label="Respuestas del propietario"
              value={pct(s.n ? (a.totals.withOwnerResponse / s.n) * 100 : 0)}
              hint={`${fmtInt(a.totals.withOwnerResponse)} reseñas respondidas`}
            />
          </div>

          <Card title="Hallazgos principales" subtitle="Interpretación automática; complétala con tu propio análisis.">
            <ul className="space-y-2 text-sm text-slate-700">
              {a.insights.map((t, i) => (
                <li key={i} className="flex gap-2">
                  <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-emerald-600" />
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </Card>

          <div ref={chartsRef} className="grid gap-4 lg:grid-cols-2">
            <ChartCard exportKey="distribucion" title="Distribución de calificaciones" subtitle="Frecuencia por número de estrellas (etiqueta: %)" height={280}>
              <RatingDistributionChart data={a.distribution} />
            </ChartCard>
            <ChartCard exportKey="sentimiento" title="Sentimiento de las opiniones" subtitle="Calificación + análisis léxico del texto" height={280}>
              <SentimentPieChart s={a.sentiment} />
            </ChartCard>
            {mentioned.length > 0 && (
              <>
                <ChartCard
                  exportKey="temas-menciones"
                  title="Temas mencionados"
                  subtitle="% de reseñas con texto que mencionan cada tema (etiqueta: menciones)"
                  height={Math.max(220, 40 + mentioned.length * 30)}
                >
                  <ThemeMentionsChart themes={a.themes} />
                </ChartCard>
                <ChartCard
                  exportKey="temas-sentimiento"
                  title="Sentimiento por tema"
                  subtitle="Menciones positivas, neutrales y negativas por tema"
                  height={Math.max(220, 70 + mentioned.length * 30)}
                >
                  <ThemeSentimentChart themes={a.themes} />
                </ChartCard>
                <ChartCard exportKey="temas-calificacion" title="Calificación promedio por tema" subtitle="Promedio de estrellas de las reseñas que mencionan cada tema" height={320}>
                  <ThemeRatingChart themes={a.themes} overall={s.mean} />
                </ChartCard>
              </>
            )}
            {a.trend.length >= 2 && (
              <ChartCard exportKey="tendencia" title={`Evolución temporal (por ${a.trendGranularity})`} subtitle="Número de reseñas y calificación promedio" height={320}>
                <TrendChart trend={a.trend} />
              </ChartCard>
            )}
            {a.topWords.length > 0 && (
              <ChartCard exportKey="palabras" title="Palabras más frecuentes" subtitle="Número de reseñas que mencionan cada palabra" height={420}>
                <TopWordsChart words={a.topWords} />
              </ChartCard>
            )}
            {a.clusters.length > 0 && (
              <ChartCard exportKey="clusters" title="Temas emergentes (agrupamiento automático)" subtitle="Tamaño de cada grupo (etiqueta: calificación promedio)" height={Math.max(200, 60 + a.clusters.length * 48)}>
                <ClusterChart clusters={a.clusters} />
              </ChartCard>
            )}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card title="Estadística descriptiva de las calificaciones">
              <DescriptiveTable a={a} />
            </Card>
            <Card title="Tabla de frecuencias">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-xs uppercase text-slate-500">
                    <th className="py-2">Estrellas</th>
                    <th className="py-2 text-right">Frecuencia</th>
                    <th className="py-2 text-right">%</th>
                    <th className="py-2 text-right">% acumulado</th>
                  </tr>
                </thead>
                <tbody>
                  {a.distribution.map((d) => (
                    <tr key={d.stars} className="border-b border-slate-100">
                      <td className="py-2">
                        <Stars value={d.stars} />
                      </td>
                      <td className="py-2 text-right">{d.count}</td>
                      <td className="py-2 text-right">{pct(d.percent)}</td>
                      <td className="py-2 text-right">{pct(d.cumulativePercent)}</td>
                    </tr>
                  ))}
                  <tr className="font-semibold">
                    <td className="py-2">Total</td>
                    <td className="py-2 text-right">{s.n}</td>
                    <td className="py-2 text-right">100%</td>
                    <td />
                  </tr>
                </tbody>
              </table>
              <h4 className="mt-6 text-sm font-semibold text-slate-800">Sentimiento</h4>
              <div className="mt-2 grid grid-cols-3 gap-2 text-center text-sm">
                <div className="rounded-xl bg-green-50 p-3">
                  <p className="text-xl font-bold text-green-700">{a.sentiment.positive}</p>
                  <p className="text-xs text-green-800">Positivas ({pct(a.sentiment.positivePct)})</p>
                </div>
                <div className="rounded-xl bg-slate-50 p-3">
                  <p className="text-xl font-bold text-slate-700">{a.sentiment.neutral}</p>
                  <p className="text-xs text-slate-700">Neutrales ({pct(a.sentiment.neutralPct)})</p>
                </div>
                <div className="rounded-xl bg-red-50 p-3">
                  <p className="text-xl font-bold text-red-700">{a.sentiment.negative}</p>
                  <p className="text-xs text-red-800">Negativas ({pct(a.sentiment.negativePct)})</p>
                </div>
              </div>
            </Card>
          </div>

          <ThemesSection themes={mentioned} />

          {a.clusters.length > 0 && <ClustersSection clusters={a.clusters} />}

          <div className="grid gap-6 lg:grid-cols-2">
            <Card title="Nube de palabras" subtitle="Tamaño proporcional al número de reseñas que mencionan la palabra">
              <WordCloud words={a.topWords} />
            </Card>
            <Card title="Expresiones frecuentes (bigramas)" subtitle={p.topics?.length ? "Incluye los temas que Google destaca para este lugar" : undefined}>
              <div className="flex flex-wrap gap-2">
                {a.topBigrams.length ? (
                  a.topBigrams.map((b) => (
                    <Badge key={b.term} className="bg-sky-50 text-sky-800">
                      {b.term} · {b.count}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-slate-500">No hay expresiones repetidas suficientes.</p>
                )}
              </div>
              {p.topics?.length ? (
                <>
                  <h4 className="mt-5 text-sm font-semibold text-slate-800">Temas destacados por Google</h4>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {p.topics.map((t) => (
                      <Badge key={t.keyword} className="bg-amber-50 text-amber-800">
                        {t.keyword} · {t.mentions}
                      </Badge>
                    ))}
                  </div>
                </>
              ) : null}
            </Card>
          </div>

          <ReviewsExplorer reviews={a.reviews} themes={mentioned} clusters={a.clusters} />
        </>
      )}
    </div>
  );
}

function DescriptiveTable({ a }: { a: PlaceAnalysis }) {
  const s = a.stats;
  if (!s) return null;
  const rows: [string, string, string][] = [
    ["n", fmtInt(s.n), "Número de reseñas analizadas"],
    ["Media", fmt(s.mean, 3), "Promedio aritmético de estrellas"],
    ["Mediana", fmt(s.median, 2), "Valor central de la distribución"],
    ["Moda", s.mode.join(", "), "Calificación más frecuente"],
    ["Desviación estándar", fmt(s.stdDev, 3), "Dispersión respecto a la media (muestral)"],
    ["Varianza", fmt(s.variance, 3), "Cuadrado de la desviación estándar"],
    ["Mínimo – Máximo", `${s.min} – ${s.max}`, `Rango = ${s.range}`],
    ["Q1 – Q3", `${fmt(s.q1, 2)} – ${fmt(s.q3, 2)}`, `Rango intercuartílico = ${fmt(s.iqr, 2)}`],
    ["Coef. de variación", pct(s.cv, 2), s.cv < 20 ? "Baja dispersión relativa" : s.cv < 35 ? "Dispersión moderada" : "Alta dispersión (opiniones heterogéneas)"],
    ["Asimetría", fmt(s.skewness, 3), s.skewness < -0.5 ? "Sesgo hacia calificaciones altas" : s.skewness > 0.5 ? "Sesgo hacia calificaciones bajas" : "Aproximadamente simétrica"],
    ["Curtosis", fmt(s.kurtosis, 3), s.kurtosis > 0 ? "Leptocúrtica (concentrada)" : "Platicúrtica (dispersa)"],
    ["Error estándar", fmt(s.standardError, 3), "Precisión de la media muestral"],
    ["IC 95% de la media", `${fmt(s.ci95[0], 2)} – ${fmt(s.ci95[1], 2)}`, "Distribución t de Student"],
  ];
  return (
    <table className="w-full text-sm">
      <tbody>
        {rows.map(([k, v, h]) => (
          <tr key={k} className="border-b border-slate-100">
            <td className="py-2 pr-2 font-medium text-slate-700">{k}</td>
            <td className="py-2 pr-2 text-right font-semibold text-slate-900">{v}</td>
            <td className="py-2 text-xs text-slate-500">{h}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ThemesSection({ themes }: { themes: ThemeResult[] }) {
  const [open, setOpen] = useState<string | null>(themes[0]?.id ?? null);
  if (!themes.length) {
    return (
      <Card title="Temas en común">
        <p className="text-sm text-slate-500">No se detectaron temas (las reseñas no tienen texto suficiente).</p>
      </Card>
    );
  }
  return (
    <Card title="Temas en común identificados" subtitle="Agrupación de opiniones por tema, con sentimiento por aspecto y ejemplos representativos.">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b text-left text-xs uppercase text-slate-500">
              <th className="py-2">Tema</th>
              <th className="py-2 text-right">Menciones</th>
              <th className="py-2 text-right">% reseñas</th>
              <th className="py-2 text-right">Calif. prom.</th>
              <th className="py-2">Sentimiento (pos / neu / neg)</th>
              <th className="py-2 text-right">Neto</th>
            </tr>
          </thead>
          <tbody>
            {themes.map((t) => {
              const total = t.mentions || 1;
              return (
                <tr key={t.id} className="cursor-pointer border-b border-slate-100 hover:bg-slate-50" onClick={() => setOpen(open === t.id ? null : t.id)}>
                  <td className="py-2">
                    <span className="flex items-center gap-2 font-medium text-slate-800">
                      <span className="h-3 w-3 shrink-0 rounded-full" style={{ backgroundColor: t.color }} />
                      {t.name}
                    </span>
                  </td>
                  <td className="py-2 text-right">{t.mentions}</td>
                  <td className="py-2 text-right">{pct(t.percentOfReviews)}</td>
                  <td className="py-2 text-right">{fmt(t.avgRating)}</td>
                  <td className="py-2">
                    <div className="flex h-3 w-48 overflow-hidden rounded-full bg-slate-100">
                      <div className="bg-green-600" style={{ width: `${(t.positive / total) * 100}%` }} />
                      <div className="bg-slate-400" style={{ width: `${(t.neutral / total) * 100}%` }} />
                      <div className="bg-red-600" style={{ width: `${(t.negative / total) * 100}%` }} />
                    </div>
                    <span className="text-[11px] text-slate-500">
                      {t.positive} / {t.neutral} / {t.negative}
                    </span>
                  </td>
                  <td className={`py-2 text-right font-semibold ${t.netSentiment >= 0 ? "text-green-700" : "text-red-700"}`}>{signed(t.netSentiment)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="mt-5 space-y-3">
        {themes.map((t) => (
          <div key={t.id} className="rounded-xl border border-slate-200">
            <button className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left" onClick={() => setOpen(open === t.id ? null : t.id)}>
              <span className="flex items-center gap-2 text-sm font-semibold text-slate-800">
                <span className="h-3 w-3 rounded-full" style={{ backgroundColor: t.color }} />
                {t.name}
                <span className="font-normal text-slate-500">· {t.mentions} menciones</span>
              </span>
              <span className="text-slate-400">{open === t.id ? "▲" : "▼"}</span>
            </button>
            {open === t.id && (
              <div className="border-t border-slate-100 px-4 py-3">
                <p className="text-xs text-slate-600">{t.description}</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {t.topKeywords.map((k) => (
                    <Badge key={k.term} className="bg-slate-100 text-slate-700">
                      {k.term} · {k.count}
                    </Badge>
                  ))}
                </div>
                <ul className="mt-3 space-y-2">
                  {t.examples.map((ex) => (
                    <li key={`${t.id}-${ex.reviewId}`} className="rounded-lg bg-slate-50 p-3 text-sm">
                      <div className="mb-1 flex items-center gap-2">
                        <Stars value={ex.rating} size="text-xs" />
                        <SentimentBadge s={ex.sentiment} />
                      </div>
                      <p className="italic text-slate-700">“{ex.text}”</p>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
}

function ClustersSection({ clusters }: { clusters: ClusterResult[] }) {
  return (
    <Card
      title="Temas emergentes"
      subtitle="Grupos de opiniones descubiertos automáticamente según su vocabulario (TF-IDF + k-means). Útiles para detectar temas no previstos."
    >
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {clusters.map((c) => (
          <div key={c.id} className="rounded-xl border border-slate-200 p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase text-slate-500">Grupo {c.id}</span>
              <Badge className="bg-emerald-50 text-emerald-800">
                {c.size} reseñas · {pct(c.percent)}
              </Badge>
            </div>
            <p className="mt-2 font-semibold text-slate-900">{c.terms.slice(0, 4).join(" · ")}</p>
            <p className="mt-1 text-xs text-slate-600">
              Promedio {fmt(c.avgRating)}★ · {pct(c.positivePct)} positivas · {pct(c.negativePct)} negativas
              {c.dominantTheme ? ` · Tema predominante: ${THEME_BY_ID[c.dominantTheme]?.name ?? c.dominantTheme}` : ""}
            </p>
            <ul className="mt-3 space-y-2">
              {c.examples.slice(0, 2).map((ex) => (
                <li key={ex.reviewId} className="rounded-lg bg-slate-50 p-2 text-xs italic text-slate-700">
                  <Stars value={ex.rating} size="text-[10px]" /> “{ex.text}”
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Card>
  );
}

function WordCloud({ words }: { words: { term: string; count: number }[] }) {
  if (!words.length) return <p className="text-sm text-slate-500">Sin palabras suficientes.</p>;
  const max = Math.max(...words.map((w) => w.count));
  const shuffled = [...words].sort((x, y) => (x.term.charCodeAt(0) % 7) - (y.term.charCodeAt(0) % 7));
  return (
    <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 py-2">
      {shuffled.map((w, i) => (
        <span
          key={w.term}
          title={`${w.count} reseñas`}
          style={{ fontSize: `${12 + (w.count / max) * 24}px`, color: CLOUD_COLORS[i % CLOUD_COLORS.length] }}
          className="font-semibold leading-tight"
        >
          {w.term}
        </span>
      ))}
    </div>
  );
}

const PAGE = 12;

function ReviewsExplorer({ reviews, themes, clusters }: { reviews: AnalyzedReview[]; themes: ThemeResult[]; clusters: ClusterResult[] }) {
  const [theme, setTheme] = useState("");
  const [sent, setSent] = useState("");
  const [stars, setStars] = useState("");
  const [cluster, setCluster] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(0);

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return reviews.filter(
      (r) =>
        (!theme || r.themes.includes(theme)) &&
        (!sent || r.sentiment === sent) &&
        (!stars || r.rating === Number(stars)) &&
        (!cluster || r.clusterId === Number(cluster)) &&
        (!qq || r.text.toLowerCase().includes(qq) || (r.author ?? "").toLowerCase().includes(qq)),
    );
  }, [reviews, theme, sent, stars, cluster, q]);

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const safePage = Math.min(page, pages - 1);
  const current = filtered.slice(safePage * PAGE, safePage * PAGE + PAGE);
  const sel = "rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm";

  return (
    <Card title={`Explorador de reseñas (${filtered.length} de ${reviews.length})`} subtitle="Filtra por tema, sentimiento, calificación o grupo emergente para la lectura cualitativa.">
      <div className="mb-4 flex flex-wrap gap-2">
        <input
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(0);
          }}
          placeholder="Buscar texto o autor…"
          className="min-w-[180px] flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm"
        />
        <select value={theme} onChange={(e) => { setTheme(e.target.value); setPage(0); }} className={sel}>
          <option value="">Todos los temas</option>
          {themes.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
        <select value={sent} onChange={(e) => { setSent(e.target.value); setPage(0); }} className={sel}>
          <option value="">Todo sentimiento</option>
          <option value="positivo">Positivo</option>
          <option value="neutral">Neutral</option>
          <option value="negativo">Negativo</option>
        </select>
        <select value={stars} onChange={(e) => { setStars(e.target.value); setPage(0); }} className={sel}>
          <option value="">Todas las estrellas</option>
          {[5, 4, 3, 2, 1].map((n) => (
            <option key={n} value={n}>
              {n} ★
            </option>
          ))}
        </select>
        {clusters.length > 0 && (
          <select value={cluster} onChange={(e) => { setCluster(e.target.value); setPage(0); }} className={sel}>
            <option value="">Todos los grupos</option>
            {clusters.map((c) => (
              <option key={c.id} value={c.id}>
                Grupo {c.id}: {c.terms.slice(0, 2).join(" · ")}
              </option>
            ))}
          </select>
        )}
      </div>
      <ul className="space-y-3">
        {current.map((r) => (
          <li key={r.id} className="rounded-xl border border-slate-200 p-4">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <Stars value={r.rating} />
              <SentimentBadge s={r.sentiment} />
              <span className="font-medium text-slate-700">{r.author ?? "Anónimo"}</span>
              <span>· {r.publishedAt ? fmtDate(r.publishedAt) : (r.relativeTime ?? "")}</span>
              {r.clusterId && <Badge className="bg-emerald-50 text-emerald-800">Grupo {r.clusterId}</Badge>}
            </div>
            <p className="mt-2 text-sm text-slate-800">{r.text || <span className="italic text-slate-400">(Reseña sin texto, solo calificación)</span>}</p>
            {r.themes.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {r.themes.map((t) => {
                  const ts = r.themeSentiments[t];
                  const cls = ts === "positivo" ? "border-green-300 bg-green-50 text-green-800" : ts === "negativo" ? "border-red-300 bg-red-50 text-red-800" : "border-slate-300 bg-slate-50 text-slate-700";
                  return (
                    <span key={t} className={`rounded-full border px-2 py-0.5 text-[11px] font-medium ${cls}`}>
                      {THEME_BY_ID[t]?.short ?? t}
                    </span>
                  );
                })}
              </div>
            )}
            {r.ownerResponse && (
              <p className="mt-2 rounded-lg bg-slate-50 p-2 text-xs text-slate-600">
                <strong>Respuesta del propietario:</strong> {r.ownerResponse}
              </p>
            )}
          </li>
        ))}
        {!current.length && <li className="py-6 text-center text-sm text-slate-500">No hay reseñas con esos filtros.</li>}
      </ul>
      {pages > 1 && (
        <div className="mt-4 flex items-center justify-center gap-3 text-sm">
          <Button size="sm" variant="secondary" disabled={safePage === 0} onClick={() => setPage(safePage - 1)}>
            ← Anterior
          </Button>
          <span className="text-slate-600">
            Página {safePage + 1} de {pages}
          </span>
          <Button size="sm" variant="secondary" disabled={safePage >= pages - 1} onClick={() => setPage(safePage + 1)}>
            Siguiente →
          </Button>
        </div>
      )}
    </Card>
  );
}
