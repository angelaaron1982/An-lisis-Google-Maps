/* eslint-disable @next/next/no-img-element */

export function Header() {
  return (
    <header className="relative overflow-hidden bg-gradient-to-br from-emerald-950 via-emerald-800 to-teal-700 text-white">
      <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full bg-teal-400/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 left-10 h-72 w-72 rounded-full bg-amber-300/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 md:flex-row md:items-center">
          <div className="flex shrink-0 items-center gap-3">
            <div className="rounded-2xl bg-white p-2 shadow-lg ring-1 ring-black/5">
              <img
                src="/logos/uqroo-verde.png"
                alt="Logotipo de la Universidad Autónoma del Estado de Quintana Roo (UQROO)"
                className="h-16 w-auto sm:h-20"
              />
            </div>
            <div className="flex items-center rounded-2xl bg-white px-3 py-2 shadow-lg ring-1 ring-black/5">
              <img
                src="/logos/coco-cientifico.svg"
                alt="Logotipo de Coco Científico: Turismo, Sostenibilidad y Ciencia"
                className="h-16 w-auto sm:h-20"
              />
            </div>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-200">
              Universidad Autónoma del Estado de Quintana Roo · Coco Científico
            </p>
            <h1 className="mt-1 text-3xl font-bold leading-tight sm:text-4xl">Analizador de Opiniones de Google Maps</h1>
            <p className="mt-2 max-w-3xl text-sm text-emerald-50 sm:text-base">
              Extrae las reseñas y calificaciones de un lugar o empresa en Google Maps, agrupa las opiniones en temas en común,
              obtén estadística descriptiva y gráficas, compara varios establecimientos y descarga la información en Word y Excel
              para elaborar tu reporte.
            </p>
          </div>
        </div>
        <div className="mt-6 flex items-start gap-3 rounded-2xl border border-white/20 bg-white/10 p-4 backdrop-blur">
          <span className="text-2xl" aria-hidden>
            🎓
          </span>
          <p className="text-sm sm:text-base">
            La herramienta forma parte de la asignatura <strong>Investigación de mercado</strong> impartida por el{" "}
            <strong>Dr. Ángel Aarón Rosado Varela</strong>.
          </p>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-12 border-t border-slate-200 bg-white">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-4 px-4 py-8 text-center sm:px-6 md:flex-row md:text-left lg:px-8">
        <div className="flex items-center gap-3">
          <img src="/logos/uqroo-verde.png" alt="UQROO" className="h-12 w-auto" />
          <img src="/logos/coco-cientifico.svg" alt="Coco Científico: Turismo, Sostenibilidad y Ciencia" className="h-11 w-auto" />
        </div>
        <div className="text-sm text-slate-600">
          <p>
            La herramienta forma parte de la asignatura <strong>Investigación de mercado</strong> impartida por el{" "}
            <strong>Dr. Ángel Aarón Rosado Varela</strong> · Universidad Autónoma del Estado de Quintana Roo.
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Uso académico. Los datos provienen de reseñas públicas de Google Maps obtenidas mediante la API oficial de Google Places
            o SerpAPI; respeta los términos de servicio de cada proveedor y cita la fuente en tus reportes.
          </p>
        </div>
      </div>
    </footer>
  );
}
