"use client";

import { useState } from "react";
import type { PlaceSummary } from "@/lib/analysis/types";
import { api, extractReviews, type Notify } from "@/lib/client";
import { fmt, fmtDate, fmtInt, SOURCE_LABELS } from "@/lib/format";
import { Badge, Button, Card, EmptyState, Spinner, Stars } from "./ui";

const SOURCE_STYLE: Record<string, string> = {
  google: "bg-blue-100 text-blue-800",
  serpapi: "bg-violet-100 text-violet-800",
  demo: "bg-amber-100 text-amber-800",
  import: "bg-slate-200 text-slate-700",
};

export function PlacesPanel({
  places,
  loading,
  compareIds,
  onToggleCompare,
  onOpen,
  onCompare,
  onChanged,
  onGoSearch,
  notify,
}: {
  places: PlaceSummary[];
  loading: boolean;
  compareIds: number[];
  onToggleCompare: (id: number) => void;
  onOpen: (id: number) => void;
  onCompare: () => void;
  onChanged: (deletedId?: number) => void;
  onGoSearch: () => void;
  notify: Notify;
}) {
  const [busy, setBusy] = useState<number | null>(null);

  async function refresh(p: PlaceSummary) {
    setBusy(p.id);
    try {
      const r = await extractReviews({ placeId: p.id, maxReviews: 50, sort: "newest" });
      notify(`«${p.name}»: ${r.inserted} reseñas nuevas (total: ${r.total}).`, "success");
      if (r.error) notify(`La actualización se detuvo antes de terminar: ${r.error}`, "error");
      onChanged();
    } catch (e) {
      notify(e instanceof Error ? e.message : "No se pudo actualizar.", "error");
    } finally {
      setBusy(null);
    }
  }

  async function remove(p: PlaceSummary) {
    if (!window.confirm(`¿Eliminar «${p.name}» y sus ${p.reviewCount} reseñas?`)) return;
    setBusy(p.id);
    try {
      await api(`/api/places/${p.id}`, { method: "DELETE" });
      notify(`Se eliminó «${p.name}».`, "info");
      onChanged(p.id);
    } catch (e) {
      notify(e instanceof Error ? e.message : "No se pudo eliminar.", "error");
    } finally {
      setBusy(null);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-3 py-20 text-slate-500">
        <Spinner /> Cargando establecimientos…
      </div>
    );
  }

  if (!places.length) {
    return (
      <EmptyState
        title="Aún no hay establecimientos guardados"
        action={
          <Button onClick={onGoSearch}>Buscar o cargar datos de demostración</Button>
        }
      >
        Busca un lugar en Google Maps, importa un archivo con reseñas o carga los datos de demostración para comenzar.
      </EmptyState>
    );
  }

  return (
    <Card
      title={`Establecimientos guardados (${places.length})`}
      subtitle="Abre el análisis de cada lugar o selecciona dos o más para compararlos."
      actions={
        <Button onClick={onCompare} disabled={compareIds.length < 2}>
          Comparar seleccionados ({compareIds.length})
        </Button>
      }
    >
      <div className="overflow-x-auto">
        <table className="w-full min-w-[820px] text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-500">
              <th className="py-2 pr-2">Comparar</th>
              <th className="py-2 pr-2">Establecimiento</th>
              <th className="py-2 pr-2">Fuente</th>
              <th className="py-2 pr-2">Google</th>
              <th className="py-2 pr-2">Reseñas guardadas</th>
              <th className="py-2 pr-2">Promedio muestra</th>
              <th className="py-2 pr-2">Actualizado</th>
              <th className="py-2 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {places.map((p) => (
              <tr key={p.id} className="border-b border-slate-100 align-middle hover:bg-slate-50">
                <td className="py-3 pr-2">
                  <input
                    type="checkbox"
                    checked={compareIds.includes(p.id)}
                    onChange={() => onToggleCompare(p.id)}
                    className="h-4 w-4 accent-emerald-700"
                    aria-label={`Seleccionar ${p.name} para comparar`}
                  />
                </td>
                <td className="max-w-xs py-3 pr-2">
                  <button onClick={() => onOpen(p.id)} className="text-left font-semibold text-slate-900 hover:text-emerald-700">
                    {p.name}
                  </button>
                  <p className="truncate text-xs text-slate-500">{p.address ?? p.category ?? ""}</p>
                </td>
                <td className="py-3 pr-2">
                  <Badge className={SOURCE_STYLE[p.source] ?? "bg-slate-100 text-slate-700"}>{SOURCE_LABELS[p.source] ?? p.source}</Badge>
                </td>
                <td className="py-3 pr-2">
                  {p.googleRating !== null ? (
                    <div>
                      <Stars value={p.googleRating} size="text-xs" /> <span className="font-medium">{fmt(p.googleRating, 1)}</span>
                      <p className="text-xs text-slate-500">{fmtInt(p.googleRatingCount)} opiniones</p>
                    </div>
                  ) : (
                    "—"
                  )}
                </td>
                <td className="py-3 pr-2 font-medium">{fmtInt(p.reviewCount)}</td>
                <td className="py-3 pr-2">{p.avgRating !== null ? `${fmt(p.avgRating)} ★` : "—"}</td>
                <td className="py-3 pr-2 text-xs text-slate-500">{fmtDate(p.updatedAt)}</td>
                <td className="py-3">
                  <div className="flex justify-end gap-1.5">
                    <Button size="sm" onClick={() => onOpen(p.id)}>
                      Analizar
                    </Button>
                    {(p.source === "google" || p.source === "serpapi") && (
                      <Button size="sm" variant="secondary" loading={busy === p.id} onClick={() => refresh(p)} title="Obtener reseñas nuevas">
                        Actualizar
                      </Button>
                    )}
                    <Button size="sm" variant="danger" disabled={busy === p.id} onClick={() => remove(p)}>
                      Eliminar
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
