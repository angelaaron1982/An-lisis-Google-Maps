import { DATABASE_URL, DB_MISSING_MESSAGE, pool } from "./index";

/**
 * Crea las tablas si aún no existen (equivalente al esquema de Drizzle en schema.ts).
 * Es idempotente y se ejecuta una sola vez por proceso.
 */
const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS places (
  id serial PRIMARY KEY,
  source varchar(20) NOT NULL,
  external_id text NOT NULL,
  name text NOT NULL,
  address text,
  category text,
  google_rating real,
  google_rating_count integer,
  maps_url text,
  website text,
  phone text,
  lat double precision,
  lng double precision,
  topics jsonb,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS places_source_external_idx ON places USING btree (source, external_id);
CREATE TABLE IF NOT EXISTS reviews (
  id serial PRIMARY KEY,
  place_id integer NOT NULL,
  external_id text NOT NULL,
  author text,
  author_url text,
  rating integer NOT NULL,
  text text DEFAULT '' NOT NULL,
  language varchar(16),
  published_at timestamp with time zone,
  relative_time text,
  likes integer,
  owner_response text,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT reviews_place_id_places_id_fk FOREIGN KEY (place_id) REFERENCES places(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS reviews_place_external_idx ON reviews USING btree (place_id, external_id);
CREATE INDEX IF NOT EXISTS reviews_place_idx ON reviews USING btree (place_id);
`;

let ready: Promise<void> | null = null;

export function ensureSchema(): Promise<void> {
  if (!DATABASE_URL) return Promise.reject(new Error(DB_MISSING_MESSAGE));
  if (!ready) {
    ready = pool
      .query(SCHEMA_SQL)
      .then(() => undefined)
      .catch((e: unknown) => {
        ready = null;
        throw e;
      });
  }
  return ready;
}
