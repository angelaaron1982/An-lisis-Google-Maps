import { drizzle } from "drizzle-orm/node-postgres";
import { Pool, type PoolConfig } from "pg";

/**
 * Cadena de conexión a PostgreSQL. Se acepta, en este orden:
 * - DATABASE_URL          (estándar; archivo .env en local o variable del hosting)
 * - NETLIFY_DATABASE_URL  (la crea automáticamente «Netlify DB», basada en Neon)
 * - POSTGRES_URL          (integraciones de Vercel / Neon / Supabase)
 */
export const DATABASE_URL = process.env.DATABASE_URL || process.env.NETLIFY_DATABASE_URL || process.env.POSTGRES_URL || "";

export const DB_MISSING_MESSAGE =
  "No hay base de datos configurada. Define la variable de entorno DATABASE_URL (cadena de conexión de PostgreSQL) en el archivo .env o en el panel de tu hosting (por ejemplo, Netlify → Site configuration → Environment variables) y vuelve a desplegar.";

const LOCAL_HOSTS = new Set(["localhost", "127.0.0.1", "::1", "[::1]", "postgres", "db"]);

/**
 * Servidores remotos (Neon, Supabase, Render, Railway…) exigen conexión cifrada.
 * Si la URL ya trae `sslmode`, se respeta la interpretación de `pg`; si no, se cifra aceptando
 * certificados autofirmados. En local no se usa SSL.
 */
function sslConfig(url: string): PoolConfig["ssl"] {
  if (!url) return undefined;
  try {
    const u = new URL(url);
    const host = u.hostname;
    if (LOCAL_HOSTS.has(host) || host.endsWith(".local") || host.endsWith(".internal")) return undefined;
    if (u.searchParams.has("sslmode") || u.searchParams.has("ssl")) return undefined;
    return { rejectUnauthorized: false };
  } catch {
    return undefined;
  }
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: DATABASE_URL || undefined,
    ssl: sslConfig(DATABASE_URL),
    max: 5,
    connectionTimeoutMillis: 15000,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
