import {
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export type GoogleTopic = { keyword: string; mentions: number };

/**
 * Establecimientos / lugares analizados.
 * source: google | serpapi | demo | import
 */
export const places = pgTable(
  "places",
  {
    id: serial("id").primaryKey(),
    source: varchar("source", { length: 20 }).notNull(),
    externalId: text("external_id").notNull(),
    name: text("name").notNull(),
    address: text("address"),
    category: text("category"),
    googleRating: real("google_rating"),
    googleRatingCount: integer("google_rating_count"),
    mapsUrl: text("maps_url"),
    website: text("website"),
    phone: text("phone"),
    lat: doublePrecision("lat"),
    lng: doublePrecision("lng"),
    topics: jsonb("topics").$type<GoogleTopic[]>(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("places_source_external_idx").on(t.source, t.externalId)],
);

/** Reseñas individuales asociadas a un establecimiento. */
export const reviews = pgTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    placeId: integer("place_id")
      .notNull()
      .references(() => places.id, { onDelete: "cascade" }),
    externalId: text("external_id").notNull(),
    author: text("author"),
    authorUrl: text("author_url"),
    rating: integer("rating").notNull(),
    text: text("text").notNull().default(""),
    language: varchar("language", { length: 16 }),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    relativeTime: text("relative_time"),
    likes: integer("likes"),
    ownerResponse: text("owner_response"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("reviews_place_external_idx").on(t.placeId, t.externalId),
    index("reviews_place_idx").on(t.placeId),
  ],
);

export type PlaceRow = typeof places.$inferSelect;
export type NewPlaceRow = typeof places.$inferInsert;
export type ReviewRow = typeof reviews.$inferSelect;
export type NewReviewRow = typeof reviews.$inferInsert;
