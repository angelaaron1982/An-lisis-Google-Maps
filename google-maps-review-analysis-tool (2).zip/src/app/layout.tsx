import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Analizador de Opiniones de Google Maps · Investigación de mercado (UQROO)",
  description:
    "Extrae reseñas y calificaciones de Google Maps, agrupa opiniones por temas, obtén estadística descriptiva y gráficas, compara establecimientos y descarga reportes en Word y Excel. La herramienta forma parte de la asignatura Investigación de mercado impartida por el Dr. Ángel Aarón Rosado Varela.",
  icons: { icon: "/logos/coco-cientifico-emblema.png", apple: "/logos/coco-cientifico-emblema.png" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body className="min-h-screen bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
