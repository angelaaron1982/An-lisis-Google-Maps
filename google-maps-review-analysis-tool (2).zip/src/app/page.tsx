import { AppShell } from "@/components/AppShell";
import { Footer, Header } from "@/components/Header";

export default function HomePage() {
  return (
    <>
      <Header />
      <AppShell />
      <Footer />
    </>
  );
}
