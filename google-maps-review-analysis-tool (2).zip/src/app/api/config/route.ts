import { serverKeysStatus } from "@/lib/providers";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json(serverKeysStatus());
}
