import { errorResponse } from "@/lib/http";
import { parseDelimited, parseWorkbook, rowsToReviews } from "@/lib/importer";
import { savePlace } from "@/lib/repo";

export const dynamic = "force-dynamic";

/** Importa reseñas desde un archivo CSV/TSV/TXT/XLSX o desde texto pegado. */
export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    const pasted = String(form.get("text") ?? "").trim();
    const name = String(form.get("name") ?? "").trim();
    const address = String(form.get("address") ?? "").trim();
    const category = String(form.get("category") ?? "").trim();
    const googleRating = Number(form.get("googleRating") ?? "");
    let rows: string[][] = [];
    let fileName = "";
    if (file && typeof file !== "string" && file.size > 0) {
      fileName = file.name;
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
      if (ext === "xls") {
        return Response.json({ error: "El formato .xls antiguo no es compatible. Guarda el archivo como .xlsx o .csv." }, { status: 400 });
      }
      if (file.size > 15 * 1024 * 1024) {
        return Response.json({ error: "El archivo excede 15 MB." }, { status: 400 });
      }
      rows = ext === "xlsx" || ext === "xlsm" ? await parseWorkbook(await file.arrayBuffer()) : parseDelimited(await file.text());
    } else if (pasted) {
      rows = parseDelimited(pasted);
    } else {
      return Response.json({ error: "Selecciona un archivo o pega reseñas en el cuadro de texto." }, { status: 400 });
    }
    const stamp = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const parsed = rowsToReviews(rows, `imp-${stamp}`);
    if (!parsed.reviews.length) {
      return Response.json({ error: "No se encontraron reseñas válidas (se requiere una calificación de 1 a 5 por fila)." }, { status: 400 });
    }
    const saved = await savePlace({
      source: "import",
      externalId: `import-${stamp}`,
      name: name || (fileName ? fileName.replace(/\.[^.]+$/, "") : "Reseñas importadas"),
      address: address || null,
      category: category || null,
      googleRating: Number.isFinite(googleRating) && googleRating > 0 && googleRating <= 5 ? googleRating : null,
      googleRatingCount: null,
      mapsUrl: null,
      website: null,
      phone: null,
      lat: null,
      lng: null,
      topics: null,
      reviews: parsed.reviews,
      notes: [],
    });
    return Response.json({ ...saved, skipped: parsed.skipped, mapping: parsed.mapping, headerDetected: parsed.headerDetected });
  } catch (e) {
    return errorResponse(e);
  }
}
