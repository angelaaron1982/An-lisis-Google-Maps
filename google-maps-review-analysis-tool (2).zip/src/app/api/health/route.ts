import { DATABASE_URL, DB_MISSING_MESSAGE, db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!DATABASE_URL) {
    return Response.json({ ok: false, error: DB_MISSING_MESSAGE }, { status: 500 });
  }
  try {
    await db.execute(sql`select 1`);
    return Response.json({ ok: true });
  } catch (e) {
    const detail = e instanceof Error ? e.message : "error desconocido";
    return Response.json(
      { ok: false, error: `No se pudo conectar a la base de datos (${detail}). Revisa la variable DATABASE_URL.` },
      { status: 500 },
    );
  }
}
