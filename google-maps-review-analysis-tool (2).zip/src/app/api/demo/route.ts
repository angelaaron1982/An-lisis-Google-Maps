import { buildDemoPlaces } from "@/lib/demo";
import { errorResponse } from "@/lib/http";
import { savePlace } from "@/lib/repo";

export const dynamic = "force-dynamic";

/** Carga (de forma idempotente) establecimientos ficticios para practicar. */
export async function POST() {
  try {
    const ids: number[] = [];
    for (const p of buildDemoPlaces()) {
      const saved = await savePlace(p);
      ids.push(saved.id);
    }
    return Response.json({ ids });
  } catch (e) {
    return errorResponse(e);
  }
}
