import { errorResponse, parseId } from "@/lib/http";
import { googleFetchPlace, resolveKeys, serpFetchChunk } from "@/lib/providers";
import { appendReviews, getPlaceRow, listPlaces, savePlace } from "@/lib/repo";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET() {
  try {
    return Response.json({ places: await listPlaces() });
  } catch (e) {
    return errorResponse(e);
  }
}

interface Fallback {
  name?: unknown;
  address?: unknown;
  category?: unknown;
  rating?: unknown;
  ratingCount?: unknown;
  mapsUrl?: unknown;
  lat?: unknown;
  lng?: unknown;
}

function str(x: unknown, max = 300): string | null {
  return typeof x === "string" && x.trim() ? x.trim().slice(0, max) : null;
}

function num(x: unknown): number | null {
  const n = Number(x);
  return x === null || x === undefined || x === "" || !Number.isFinite(n) ? null : n;
}

function safeUrl(x: unknown): string | null {
  const s = str(x, 1000);
  return s && /^https?:\/\//i.test(s) ? s : null;
}

/**
 * Extrae (o actualiza) reseñas de un lugar y las guarda.
 * - Google Places: una sola llamada (máx. 5 reseñas).
 * - SerpAPI: por bloques. La primera llamada crea/actualiza el lugar; las siguientes envían
 *   `placeId` + `pageToken` + `collected` y solo agregan reseñas. El cliente repite mientras
 *   la respuesta incluya `nextPageToken`.
 */
export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as {
      provider?: string;
      externalId?: string;
      placeId?: number;
      maxReviews?: number;
      sort?: string;
      pageToken?: string | null;
      collected?: number;
      pagesPerRequest?: number;
      fallback?: Fallback;
    };
    let provider = body.provider;
    let externalId = body.externalId?.trim();
    const existingId = body.placeId ? parseId(String(body.placeId)) : null;
    const existing = existingId ? await getPlaceRow(existingId) : null;
    if (body.placeId) {
      if (!existing) return Response.json({ error: "Establecimiento no encontrado." }, { status: 404 });
      if (existing.source !== "google" && existing.source !== "serpapi") {
        return Response.json({ error: "Solo los lugares obtenidos de Google o SerpAPI pueden actualizarse." }, { status: 400 });
      }
      provider = existing.source;
      externalId = existing.externalId;
    }
    if (!externalId || (provider !== "google" && provider !== "serpapi")) {
      return Response.json({ error: "Faltan datos del lugar a extraer." }, { status: 400 });
    }
    const keys = resolveKeys(req);

    if (provider === "google") {
      if (!keys.google) {
        return Response.json({ error: "Falta la clave de Google Maps (Places API). Pégala en «Configurar claves de API»." }, { status: 400 });
      }
      const fetched = await googleFetchPlace(externalId, keys.google);
      const saved = await savePlace(fetched);
      return Response.json({
        ...saved,
        name: fetched.name,
        notes: fetched.notes,
        fetched: fetched.reviews.length,
        collected: fetched.reviews.length,
        pages: 1,
        nextPageToken: null,
      });
    }

    if (!keys.serpapi) {
      return Response.json({ error: "Falta la clave de SerpAPI. Pégala en el campo «Clave de SerpAPI»." }, { status: 400 });
    }
    const max = Math.max(5, Math.min(Number(body.maxReviews) || 100, 1000));
    const collected = Math.max(0, Math.floor(Number(body.collected) || 0));
    const pageToken = typeof body.pageToken === "string" && body.pageToken ? body.pageToken : null;
    if (pageToken && !existing) {
      return Response.json({ error: "Falta el identificador del lugar para continuar la extracción." }, { status: 400 });
    }
    const chunk = await serpFetchChunk(externalId, keys.serpapi, {
      sort: body.sort ?? "relevant",
      maxReviews: Math.max(1, max - collected),
      pageToken,
      // Bloques cortos para caber en el límite de las funciones serverless (Netlify: 10 s en el plan gratuito).
      maxPages: Math.max(1, Math.min(Number(body.pagesPerRequest) || 2, 5)),
      timeBudgetMs: 5000,
    });

    let saved: { id: number; inserted: number; total: number };
    let name: string;
    if (pageToken && existing) {
      saved = await appendReviews(existing.id, chunk.reviews);
      name = existing.name;
    } else {
      const fb = existing
        ? {
            name: existing.name,
            address: existing.address,
            category: existing.category,
            rating: existing.googleRating,
            ratingCount: existing.googleRatingCount,
            mapsUrl: existing.mapsUrl,
            lat: existing.lat,
            lng: existing.lng,
          }
        : {
            name: str(body.fallback?.name, 200),
            address: str(body.fallback?.address),
            category: str(body.fallback?.category, 120),
            rating: num(body.fallback?.rating),
            ratingCount: num(body.fallback?.ratingCount),
            mapsUrl: safeUrl(body.fallback?.mapsUrl),
            lat: num(body.fallback?.lat),
            lng: num(body.fallback?.lng),
          };
      const m = chunk.meta;
      name = chunk.hasPlaceInfo ? m.name : fb.name || m.name;
      saved = await savePlace({
        ...m,
        name,
        address: m.address ?? fb.address ?? null,
        category: m.category ?? fb.category ?? null,
        googleRating: m.googleRating ?? fb.rating ?? null,
        googleRatingCount: m.googleRatingCount ?? fb.ratingCount ?? null,
        mapsUrl: m.mapsUrl ?? fb.mapsUrl ?? null,
        lat: m.lat ?? fb.lat ?? null,
        lng: m.lng ?? fb.lng ?? null,
        reviews: chunk.reviews,
        notes: [],
      });
    }
    const totalCollected = collected + chunk.reviews.length;
    return Response.json({
      ...saved,
      name,
      notes: [],
      fetched: chunk.reviews.length,
      collected: totalCollected,
      pages: chunk.pages,
      nextPageToken: totalCollected < max ? chunk.nextPageToken : null,
    });
  } catch (e) {
    return errorResponse(e);
  }
}
