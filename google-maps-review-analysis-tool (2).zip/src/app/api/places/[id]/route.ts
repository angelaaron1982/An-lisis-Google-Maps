import { errorResponse, parseId } from "@/lib/http";
import { analyzeById, deletePlace, renamePlace } from "@/lib/repo";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  try {
    const id = parseId((await ctx.params).id);
    if (!id) return Response.json({ error: "Identificador inválido." }, { status: 400 });
    const analysis = await analyzeById(id);
    if (!analysis) return Response.json({ error: "Establecimiento no encontrado." }, { status: 404 });
    return Response.json({ analysis });
  } catch (e) {
    return errorResponse(e);
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const id = parseId((await ctx.params).id);
    const body = (await req.json().catch(() => ({}))) as { name?: string };
    const name = body.name?.trim();
    if (!id || !name) return Response.json({ error: "Datos inválidos." }, { status: 400 });
    await renamePlace(id, name.slice(0, 200));
    return Response.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    const id = parseId((await ctx.params).id);
    if (!id) return Response.json({ error: "Identificador inválido." }, { status: 400 });
    const ok = await deletePlace(id);
    return Response.json({ ok }, { status: ok ? 200 : 404 });
  } catch (e) {
    return errorResponse(e);
  }
}
