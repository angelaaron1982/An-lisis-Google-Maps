import { comparePlaces } from "@/lib/analysis/analyze";
import { buildCompareXlsx, buildPlaceXlsx } from "@/lib/export/excel";
import { buildCompareDocx, buildPlaceDocx, type ChartImage } from "@/lib/export/word";
import { errorResponse, fileResponse, toArrayBuffer } from "@/lib/http";
import { analyzeMany } from "@/lib/repo";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
const XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

/** Origen público del sitio (detrás de proxies/CDN) para que el Word pueda descargar los logotipos. */
function originOf(req: Request): string {
  const proto = req.headers.get("x-forwarded-proto")?.split(",")[0].trim();
  const host = req.headers.get("x-forwarded-host")?.split(",")[0].trim() || req.headers.get("host");
  if (host) {
    const local = /^(localhost|127\.|\[::1\])/.test(host);
    return `${proto || (local ? "http" : "https")}://${host}`;
  }
  return new URL(req.url).origin;
}

function slug(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\w]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 50)
    .toLowerCase();
}

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as {
      format?: string;
      scope?: string;
      ids?: unknown[];
      charts?: { key?: string; title?: string; image?: string }[];
    };
    const format = body.format === "xlsx" ? "xlsx" : "docx";
    const ids = [...new Set((body.ids ?? []).map(Number).filter((n) => Number.isInteger(n) && n > 0))].slice(0, 8);
    const charts: ChartImage[] = (body.charts ?? [])
      .filter((c) => typeof c.image === "string" && c.image.startsWith("data:image/png;base64,"))
      .slice(0, 20)
      .map((c) => ({ key: String(c.key ?? ""), title: String(c.title ?? "Gráfica"), image: c.image as string }));
    const date = new Date().toISOString().slice(0, 10);
    const origin = originOf(req);

    if (body.scope === "compare") {
      if (ids.length < 2) return Response.json({ error: "Selecciona al menos dos establecimientos." }, { status: 400 });
      const analyses = await analyzeMany(ids);
      const comparison = comparePlaces(analyses);
      const name = `comparativo-opiniones-${date}`;
      if (format === "xlsx") return fileResponse(await buildCompareXlsx(comparison, charts), `${name}.xlsx`, XLSX);
      const buf = await buildCompareDocx(comparison, charts, origin);
      return fileResponse(toArrayBuffer(buf), `${name}.docx`, DOCX);
    }

    if (!ids.length) return Response.json({ error: "Selecciona un establecimiento." }, { status: 400 });
    const [analysis] = await analyzeMany([ids[0]]);
    if (!analysis) return Response.json({ error: "Establecimiento no encontrado." }, { status: 404 });
    const name = `opiniones-${slug(analysis.place.name) || "lugar"}-${date}`;
    if (format === "xlsx") return fileResponse(await buildPlaceXlsx(analysis, charts), `${name}.xlsx`, XLSX);
    const buf = await buildPlaceDocx(analysis, charts, origin);
    return fileResponse(toArrayBuffer(buf), `${name}.docx`, DOCX);
  } catch (e) {
    return errorResponse(e, "No se pudo generar el reporte.");
  }
}
