import { errorResponse } from "@/lib/http";
import { googleSearch, parseMapsInput, resolveKeys, serpSearch } from "@/lib/providers";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { query?: string; provider?: string };
    const query = (body.query ?? "").trim();
    if (!query) {
      return Response.json({ error: "Escribe el nombre de un lugar o pega un enlace de Google Maps." }, { status: 400 });
    }
    const provider = body.provider === "serpapi" ? "serpapi" : "google";
    const keys = resolveKeys(req);
    const key = provider === "google" ? keys.google : keys.serpapi;
    if (!key) {
      return Response.json(
        {
          error:
            provider === "google"
              ? "No hay una clave de Google Maps (Places API) configurada. Agrégala en «Configurar claves de API» o usa el modo demostración."
              : "No hay una clave de SerpAPI configurada. Agrégala en «Configurar claves de API» o usa el modo demostración.",
        },
        { status: 400 },
      );
    }
    const parsed = await parseMapsInput(query);
    const results = provider === "google" ? await googleSearch(parsed, key) : await serpSearch(parsed, key);
    return Response.json({ results, parsed: { isUrl: parsed.isUrl, query: parsed.query } });
  } catch (e) {
    return errorResponse(e);
  }
}
