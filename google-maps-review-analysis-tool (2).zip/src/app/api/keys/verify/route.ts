import { errorResponse } from "@/lib/http";
import { googleVerify, resolveKeys, serpAccount } from "@/lib/providers";

export const dynamic = "force-dynamic";

/**
 * Verifica la clave de API (la del navegador si viene en la cabecera; si no, la del servidor).
 * Ninguna de las dos verificaciones consume créditos:
 * - SerpAPI: endpoint de cuenta (además devuelve las búsquedas disponibles).
 * - Google: Place Details solo con el campo «id» (SKU sin costo).
 */
export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { provider?: string };
    const keys = resolveKeys(req);
    if (body.provider === "serpapi") {
      if (!keys.serpapi) return Response.json({ error: "No hay una clave de SerpAPI para verificar." }, { status: 400 });
      const account = await serpAccount(keys.serpapi);
      return Response.json({ ok: true, provider: "serpapi", source: keys.serpapiSource, ...account });
    }
    if (!keys.google) return Response.json({ error: "No hay una clave de Google para verificar." }, { status: 400 });
    await googleVerify(keys.google);
    return Response.json({ ok: true, provider: "google", source: keys.googleSource });
  } catch (e) {
    return errorResponse(e);
  }
}
