import { comparePlaces } from "@/lib/analysis/analyze";
import { errorResponse } from "@/lib/http";
import { analyzeMany } from "@/lib/repo";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { ids?: unknown[] };
    const ids = [...new Set((body.ids ?? []).map(Number).filter((n) => Number.isInteger(n) && n > 0))].slice(0, 8);
    if (ids.length < 2) return Response.json({ error: "Selecciona al menos dos establecimientos." }, { status: 400 });
    const analyses = await analyzeMany(ids);
    if (analyses.length < 2) return Response.json({ error: "No se encontraron los establecimientos." }, { status: 404 });
    const result = comparePlaces(analyses);
    return Response.json({ comparison: { ...result, places: result.places.map((p) => ({ ...p, reviews: [] })) } });
  } catch (e) {
    return errorResponse(e);
  }
}
