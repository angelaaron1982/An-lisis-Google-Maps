import { fmt, fmtP, pct, PLACE_COLORS, signed } from "../format";
import { clusterDocuments } from "./cluster";
import { emojiScore, normalizeScore, scoreTokens } from "./lexicon";
import { anova, chiSquareIndependence, descriptive, kruskalWallis, mean, round, welchT } from "./stats";
import { contentTokens, splitClauses, tokenize, truncate } from "./text";
import { THEME_BY_ID, THEMES, detectThemes } from "./themes";
import type {
  AnalyzedReview,
  ClusterResult,
  ComparisonResult,
  CompareSummaryRow,
  DescriptiveStats,
  PlaceAnalysis,
  PlaceInfo,
  RatingBucket,
  ReviewInput,
  Sentiment,
  SentimentSummary,
  ThemeExample,
  ThemeMatrixRow,
  ThemeResult,
  TrendPoint,
} from "./types";

/**
 * Sentimiento neto "encogido" hacia 0 según el número de menciones (suavizado aditivo),
 * para que temas con muy pocas menciones no dominen los rankings de fortalezas/debilidades.
 */
export function adjustedNet(t: ThemeResult): number {
  return ((t.positive - t.negative) / (t.mentions + 5)) * 100;
}

function labelOf(score: number, threshold: number): Sentiment {
  if (score > threshold) return "positivo";
  if (score < -threshold) return "negativo";
  return "neutral";
}

interface ThemeAcc {
  mentions: number;
  ratingSum: number;
  pos: number;
  neu: number;
  neg: number;
  scoreSum: number;
  keywords: Map<string, number>;
  examples: (ThemeExample & { strength: number })[];
}

export function analyzePlace(place: PlaceInfo, input: ReviewInput[]): PlaceAnalysis {
  const reviews = [...input].sort((a, b) => (b.publishedAt ?? "").localeCompare(a.publishedAt ?? ""));
  const acc = new Map<string, ThemeAcc>(
    THEMES.map((t) => [
      t.id,
      { mentions: 0, ratingSum: 0, pos: 0, neu: 0, neg: 0, scoreSum: 0, keywords: new Map(), examples: [] },
    ]),
  );
  const analyzed: AnalyzedReview[] = [];
  const clusterDocs: string[][] = [];
  const clusterReviewIdx: number[] = [];
  const wordDf = new Map<string, number>();
  const bigramDf = new Map<string, number>();

  for (const r of reviews) {
    const text = (r.text ?? "").trim();
    const ratingScore = (r.rating - 3) / 2;
    let textSentiment: number | null = null;
    const themeScores = new Map<string, number[]>();
    let wordCount = 0;

    if (text) {
      wordCount = text.split(/\s+/).filter(Boolean).length;
      const tokens = tokenize(text);
      const whole = scoreTokens(tokens);
      const emo = emojiScore(text);
      if (whole.hits + emo.hits > 0) textSentiment = normalizeScore(whole.sum + emo.sum);

      // Sentimiento por aspecto: cada cláusula aporta a los temas que menciona.
      const clauses = splitClauses(text);
      let lastSentence = -1;
      let lastThemes: string[] = [];
      for (const cl of clauses) {
        if (cl.sentence !== lastSentence) {
          lastSentence = cl.sentence;
          lastThemes = [];
        }
        const found = detectThemes(cl.tokens);
        const s = scoreTokens(cl.tokens);
        const clauseScore = s.hits > 0 ? normalizeScore(s.sum) : null;
        const ids = [...found.keys()];
        if (ids.length) {
          for (const id of ids) {
            if (!themeScores.has(id)) themeScores.set(id, []);
            if (clauseScore !== null) themeScores.get(id)?.push(clauseScore);
            const a = acc.get(id);
            if (a) for (const kw of found.get(id) ?? []) a.keywords.set(kw, (a.keywords.get(kw) ?? 0) + 1);
          }
          lastThemes = ids;
        } else if (clauseScore !== null && lastThemes.length) {
          for (const id of lastThemes) themeScores.get(id)?.push(clauseScore);
        }
      }

      const ct = contentTokens(tokens);
      for (const w of new Set(ct)) wordDf.set(w, (wordDf.get(w) ?? 0) + 1);
      const bigrams = new Set<string>();
      for (const cl of clauses) {
        const c = contentTokens(cl.tokens);
        for (let i = 0; i + 1 < c.length; i++) if (c[i] !== c[i + 1]) bigrams.add(`${c[i]} ${c[i + 1]}`);
      }
      for (const b of bigrams) bigramDf.set(b, (bigramDf.get(b) ?? 0) + 1);
      if (ct.length) {
        clusterDocs.push(ct);
        clusterReviewIdx.push(analyzed.length);
      }
    }

    const combined = textSentiment !== null ? 0.6 * ratingScore + 0.4 * textSentiment : ratingScore;
    const themeSentiments: Record<string, Sentiment> = {};
    const themes: string[] = [];
    for (const t of THEMES) {
      const scores = themeScores.get(t.id);
      if (!scores) continue;
      themes.push(t.id);
      const sc = scores.length ? mean(scores) : ratingScore * 0.6;
      const lab = labelOf(sc, 0.1);
      themeSentiments[t.id] = lab;
      const a = acc.get(t.id);
      if (!a) continue;
      a.mentions++;
      a.ratingSum += r.rating;
      a.scoreSum += sc;
      if (lab === "positivo") a.pos++;
      else if (lab === "negativo") a.neg++;
      else a.neu++;
      a.examples.push({ reviewId: r.id, rating: r.rating, sentiment: lab, text: truncate(text, 260), strength: Math.abs(sc) });
    }

    analyzed.push({
      ...r,
      text,
      sentimentScore: round(combined, 3),
      textSentiment: textSentiment === null ? null : round(textSentiment, 3),
      sentiment: labelOf(combined, 0.2),
      themes,
      themeSentiments,
      wordCount,
      clusterId: null,
    });
  }

  const n = analyzed.length;
  const withText = analyzed.filter((r) => r.text).length;
  const ratings = analyzed.map((r) => r.rating);
  const stats = descriptive(ratings);

  let cumulative = 0;
  const distribution: RatingBucket[] = [1, 2, 3, 4, 5].map((stars) => {
    const count = ratings.filter((x) => x === stars).length;
    const percent = n ? (count / n) * 100 : 0;
    cumulative += percent;
    return { stars, count, percent: round(percent, 1), cumulativePercent: round(cumulative, 1) };
  });

  const positive = analyzed.filter((r) => r.sentiment === "positivo").length;
  const negative = analyzed.filter((r) => r.sentiment === "negativo").length;
  const neutral = n - positive - negative;
  const sentiment: SentimentSummary = {
    positive,
    neutral,
    negative,
    positivePct: n ? round((positive / n) * 100, 1) : 0,
    neutralPct: n ? round((neutral / n) * 100, 1) : 0,
    negativePct: n ? round((negative / n) * 100, 1) : 0,
    avgScore: round(mean(analyzed.map((r) => r.sentimentScore)), 3),
    netSentiment: n ? round(((positive - negative) / n) * 100, 1) : 0,
  };
  const high = distribution[3].count + distribution[4].count;
  const low = distribution[0].count + distribution[1].count;
  const satisfactionIndex = n ? round(((high - low) / n) * 100, 1) : 0;

  const themes: ThemeResult[] = THEMES.map((t) => {
    const a = acc.get(t.id) as ThemeAcc;
    const sorted = [...a.examples].sort((x, y) => y.strength - x.strength || x.text.length - y.text.length);
    const pick = (s: Sentiment, k: number) =>
      sorted.filter((e) => e.sentiment === s && e.text).slice(0, k).map(({ strength: _s, ...rest }) => rest);
    let examples = [...pick("positivo", 2), ...pick("negativo", 2)];
    if (examples.length < 3) examples = [...examples, ...pick("neutral", 3 - examples.length)];
    return {
      id: t.id,
      name: t.name,
      color: t.color,
      description: t.description,
      mentions: a.mentions,
      percentOfReviews: withText ? round((a.mentions / withText) * 100, 1) : 0,
      avgRating: a.mentions ? round(a.ratingSum / a.mentions, 2) : null,
      positive: a.pos,
      neutral: a.neu,
      negative: a.neg,
      netSentiment: a.mentions ? round(((a.pos - a.neg) / a.mentions) * 100, 1) : 0,
      avgSentimentScore: a.mentions ? round(a.scoreSum / a.mentions, 3) : 0,
      topKeywords: [...a.keywords.entries()]
        .sort((x, y) => y[1] - x[1])
        .slice(0, 6)
        .map(([term, count]) => ({ term, count })),
      examples,
    };
  }).sort((a, b) => b.mentions - a.mentions);

  // Temas emergentes (agrupamiento no supervisado)
  let clusters: ClusterResult[] = [];
  const out = clusterDocuments(clusterDocs, { seed: place.id * 7919 + 17 });
  if (out) {
    const temp = out.clusters.map((c, ci) => {
      const members = c.members.map((di) => analyzed[clusterReviewIdx[di]]);
      const size = members.length;
      const themeCount = new Map<string, number>();
      for (const m of members) for (const th of m.themes) themeCount.set(th, (themeCount.get(th) ?? 0) + 1);
      const dominant = [...themeCount.entries()].sort((x, y) => y[1] - x[1])[0]?.[0] ?? null;
      const best = c.members
        .map((di, i) => ({ di, sim: c.sims[i] }))
        .sort((x, y) => y.sim - x.sim)
        .slice(0, 3);
      return {
        tempId: ci,
        result: {
          id: 0,
          label: c.terms.slice(0, 3).map((t) => t.term).join(" · "),
          terms: c.terms.map((t) => t.term),
          size,
          percent: round((size / clusterDocs.length) * 100, 1),
          avgRating: round(mean(members.map((m) => m.rating)), 2),
          positivePct: round((members.filter((m) => m.sentiment === "positivo").length / size) * 100, 1),
          negativePct: round((members.filter((m) => m.sentiment === "negativo").length / size) * 100, 1),
          dominantTheme: dominant,
          examples: best.map((b) => {
            const rv = analyzed[clusterReviewIdx[b.di]];
            return { reviewId: rv.id, rating: rv.rating, text: truncate(rv.text, 220) };
          }),
        } as ClusterResult,
      };
    });
    temp.sort((a, b) => b.result.size - a.result.size);
    const idMap = new Map<number, number>();
    temp.forEach((t, i) => {
      t.result.id = i + 1;
      idMap.set(t.tempId, i + 1);
    });
    clusters = temp.map((t) => t.result);
    out.assignments.forEach((a, di) => {
      if (a >= 0) analyzed[clusterReviewIdx[di]].clusterId = idMap.get(a) ?? null;
    });
  }

  const topWords = [...wordDf.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 30)
    .map(([term, count]) => ({ term, count }));
  const topBigrams = [...bigramDf.entries()]
    .filter(([, c]) => c >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 20)
    .map(([term, count]) => ({ term, count }));

  // Tendencia temporal
  const dated = analyzed.filter((r) => r.publishedAt);
  let granularity: PlaceAnalysis["trendGranularity"] = "mes";
  let keyFn = (iso: string) => iso.slice(0, 7);
  if (new Set(dated.map((r) => keyFn(r.publishedAt as string))).size > 30) {
    granularity = "trimestre";
    keyFn = (iso: string) => `${iso.slice(0, 4)}-T${Math.floor((Number(iso.slice(5, 7)) - 1) / 3) + 1}`;
    if (new Set(dated.map((r) => keyFn(r.publishedAt as string))).size > 30) {
      granularity = "año";
      keyFn = (iso: string) => iso.slice(0, 4);
    }
  }
  const groups = new Map<string, AnalyzedReview[]>();
  for (const r of dated) {
    const k = keyFn(r.publishedAt as string);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k)?.push(r);
  }
  const trend: TrendPoint[] = [...groups.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([period, rs]) => ({
      period,
      count: rs.length,
      avgRating: round(mean(rs.map((r) => r.rating)), 2),
      positivePct: round((rs.filter((r) => r.sentiment === "positivo").length / rs.length) * 100, 1),
    }));

  const dates = dated.map((r) => r.publishedAt as string).sort();
  const totals = {
    reviews: n,
    withText,
    withOwnerResponse: analyzed.filter((r) => r.ownerResponse).length,
    avgWords: round(mean(analyzed.filter((r) => r.text).map((r) => r.wordCount)), 1),
    dateFrom: dates[0] ?? null,
    dateTo: dates[dates.length - 1] ?? null,
  };

  const insights = buildInsights(place, stats, distribution, sentiment, satisfactionIndex, themes, clusters, analyzed, totals);

  return {
    place,
    generatedAt: new Date().toISOString(),
    totals,
    stats,
    distribution,
    sentiment,
    satisfactionIndex,
    themes,
    clusters,
    topWords,
    topBigrams,
    trend,
    trendGranularity: granularity,
    insights,
    reviews: analyzed,
  };
}

function buildInsights(
  place: PlaceInfo,
  stats: DescriptiveStats | null,
  dist: RatingBucket[],
  sentiment: SentimentSummary,
  satisfactionIndex: number,
  themes: ThemeResult[],
  clusters: ClusterResult[],
  reviews: AnalyzedReview[],
  totals: PlaceAnalysis["totals"],
): string[] {
  if (!stats) return ["Aún no hay reseñas suficientes para generar hallazgos."];
  const out: string[] = [];
  out.push(
    `Se analizaron ${stats.n} reseñas (${totals.withText} con comentario escrito). La calificación promedio de la muestra es ${fmt(stats.mean)} de 5 (DE = ${fmt(stats.stdDev)}; mediana = ${fmt(stats.median, 1)}; IC 95%: ${fmt(stats.ci95[0])}–${fmt(stats.ci95[1])}).`,
  );
  if (place.googleRating !== null) {
    const diff = stats.mean - place.googleRating;
    const rel =
      Math.abs(diff) < 0.1
        ? "es consistente con ese valor"
        : diff > 0
          ? `se ubica ${fmt(Math.abs(diff))} puntos por encima`
          : `se ubica ${fmt(Math.abs(diff))} puntos por debajo`;
    out.push(
      `La calificación global publicada en Google es ${fmt(place.googleRating, 1)}${place.googleRatingCount ? ` (${place.googleRatingCount.toLocaleString("es-MX")} opiniones)` : ""}; el promedio de la muestra ${rel}.`,
    );
  }
  out.push(
    `El ${pct(sentiment.positivePct)} de las opiniones es positivo, el ${pct(sentiment.neutralPct)} neutral y el ${pct(sentiment.negativePct)} negativo. Índice de satisfacción neta (% 4–5★ menos % 1–2★): ${signed(satisfactionIndex)} puntos.`,
  );
  const mentioned = themes.filter((t) => t.mentions > 0);
  if (mentioned.length) {
    out.push(
      `Los temas más mencionados son ${mentioned
        .slice(0, 3)
        .map((t) => `«${t.name}» (${pct(t.percentOfReviews)} de las reseñas con texto)`)
        .join(", ")}.`,
    );
  }
  const minMentions = Math.max(2, Math.ceil(totals.withText * 0.05));
  const relevant = mentioned.filter((t) => t.mentions >= minMentions);
  const strengths = [...relevant].sort((a, b) => adjustedNet(b) - adjustedNet(a)).filter((t) => t.netSentiment >= 30).slice(0, 2);
  const weaknesses = [...relevant]
    .filter((t) => !strengths.includes(t))
    .sort((a, b) => adjustedNet(a) - adjustedNet(b))
    .slice(0, 2);
  if (strengths.length) {
    out.push(
      `Fortalezas percibidas: ${strengths.map((t) => `«${t.name}» (sentimiento neto ${signed(t.netSentiment)}; ${t.mentions} menciones)`).join(" y ")}.`,
    );
  }
  if (weaknesses.length) {
    const detail = weaknesses
      .map((t) => `«${t.name}» (sentimiento neto ${signed(t.netSentiment)}; ${t.negative} menciones negativas)`)
      .join(" y ");
    out.push(
      weaknesses[0].netSentiment < 30
        ? `Áreas de oportunidad: ${detail}.`
        : `Todos los temas relevantes son mayormente positivos; los de menor sentimiento neto relativo son ${detail}, posibles áreas de mejora.`,
    );
  }
  if (stats.n >= 10) {
    if (stats.skewness < -0.5)
      out.push("La distribución presenta asimetría negativa: predominan las calificaciones altas con una cola de opiniones bajas.");
    else if (stats.skewness > 0.5) out.push("La distribución presenta asimetría positiva: predominan las calificaciones bajas.");
    else out.push("La distribución de calificaciones es aproximadamente simétrica.");
  }
  if (dist[0].percent >= 12 && dist[4].percent >= 40) {
    out.push(`Se observa polarización: ${pct(dist[4].percent)} otorga 5 estrellas, pero ${pct(dist[0].percent)} otorga solo 1 estrella.`);
  }
  const dated = reviews.filter((r) => r.publishedAt);
  if (dated.length >= 15) {
    const latest = Math.max(...dated.map((r) => new Date(r.publishedAt as string).getTime()));
    const cutoff = latest - 182 * 24 * 3600 * 1000;
    const recent = dated.filter((r) => new Date(r.publishedAt as string).getTime() >= cutoff).map((r) => r.rating);
    const older = dated.filter((r) => new Date(r.publishedAt as string).getTime() < cutoff).map((r) => r.rating);
    if (recent.length >= 5 && older.length >= 5) {
      const d = mean(recent) - mean(older);
      if (Math.abs(d) >= 0.2) {
        out.push(
          `Tendencia: el promedio de los últimos 6 meses (${fmt(mean(recent))}) es ${d > 0 ? "mayor" : "menor"} que el de periodos anteriores (${fmt(mean(older))}).`,
        );
      } else {
        out.push(`Tendencia: el promedio de los últimos 6 meses (${fmt(mean(recent))}) se mantiene estable respecto a periodos anteriores (${fmt(mean(older))}).`);
      }
    }
  }
  if (clusters.length) {
    const c = clusters[0];
    out.push(
      `El agrupamiento automático identificó ${clusters.length} temas emergentes; el más numeroso gira en torno a «${c.label}» (${pct(c.percent)} de las reseñas con texto, promedio ${fmt(c.avgRating)}★).`,
    );
  }
  if (totals.withOwnerResponse > 0) {
    out.push(`El propietario respondió el ${pct((totals.withOwnerResponse / stats.n) * 100)} de las reseñas analizadas.`);
  }
  if (stats.n < 30) {
    out.push("Advertencia: la muestra tiene menos de 30 reseñas; los resultados deben interpretarse como exploratorios.");
  }
  return out;
}

export function comparePlaces(analyses: PlaceAnalysis[]): ComparisonResult {
  const summary: CompareSummaryRow[] = analyses.map((a, i) => {
    const minMentions = Math.max(2, Math.ceil(a.totals.withText * 0.05));
    const relevant = a.themes.filter((t) => t.mentions >= minMentions);
    const strength = [...relevant].sort((x, y) => adjustedNet(y) - adjustedNet(x))[0];
    const weakness = [...relevant].filter((t) => t !== strength).sort((x, y) => adjustedNet(x) - adjustedNet(y))[0];
    return {
      placeId: a.place.id,
      name: a.place.name,
      source: a.place.source,
      color: PLACE_COLORS[i % PLACE_COLORS.length],
      googleRating: a.place.googleRating,
      googleRatingCount: a.place.googleRatingCount,
      n: a.totals.reviews,
      withText: a.totals.withText,
      mean: a.stats?.mean ?? null,
      median: a.stats?.median ?? null,
      stdDev: a.stats?.stdDev ?? null,
      positivePct: a.sentiment.positivePct,
      neutralPct: a.sentiment.neutralPct,
      negativePct: a.sentiment.negativePct,
      satisfactionIndex: a.satisfactionIndex,
      topTheme: a.themes.find((t) => t.mentions > 0)?.name ?? null,
      strength: strength && strength.netSentiment > 0 ? strength.name : null,
      weakness: weakness ? weakness.name : null,
    };
  });

  const themeMatrix: ThemeMatrixRow[] = THEMES.map((t) => ({
    themeId: t.id,
    themeName: t.name,
    color: t.color,
    values: analyses.map((a) => {
      const th = a.themes.find((x) => x.id === t.id);
      return {
        placeId: a.place.id,
        mentions: th?.mentions ?? 0,
        percent: th?.percentOfReviews ?? 0,
        avgRating: th?.avgRating ?? null,
        netSentiment: th && th.mentions ? th.netSentiment : null,
      };
    }),
  }))
    .filter((row) => row.values.some((v) => v.mentions > 0))
    .sort((a, b) => b.values.reduce((s, v) => s + v.mentions, 0) - a.values.reduce((s, v) => s + v.mentions, 0));

  const groups = analyses.map((a) => a.reviews.map((r) => r.rating));
  const an = anova(groups);
  const kw = kruskalWallis(groups);
  const we = analyses.length === 2 ? welchT(groups[0], groups[1]) : null;
  const chi = chiSquareIndependence(analyses.map((a) => [a.sentiment.positive, a.sentiment.neutral, a.sentiment.negative]));

  const insights: string[] = [];
  const ranked = summary.filter((s) => s.mean !== null).sort((a, b) => (b.mean ?? 0) - (a.mean ?? 0));
  if (ranked.length >= 2) {
    const best = ranked[0];
    const worst = ranked[ranked.length - 1];
    insights.push(
      `«${best.name}» obtiene el promedio más alto en la muestra (${fmt(best.mean)}★, n = ${best.n}) y «${worst.name}» el más bajo (${fmt(worst.mean)}★, n = ${worst.n}).`,
    );
  }
  if (an) {
    const sig = an.p < 0.05;
    insights.push(
      `ANOVA de un factor: F(${an.dfBetween}, ${an.dfWithin}) = ${fmt(an.f, 3)}; p ${an.p < 0.001 ? "< 0.001" : `= ${fmtP(an.p)}`}; η² = ${fmt(an.etaSquared, 3)}. ${sig ? "Existen diferencias estadísticamente significativas entre los promedios (α = 0.05)." : "No hay evidencia suficiente de diferencias significativas entre los promedios (α = 0.05)."}`,
    );
  }
  if (kw) {
    insights.push(
      `Kruskal-Wallis (adecuada para datos ordinales): H(${kw.df}) = ${fmt(kw.h, 3)}; p ${kw.p < 0.001 ? "< 0.001" : `= ${fmtP(kw.p)}`}. ${kw.p < 0.05 ? "Las distribuciones de calificaciones difieren significativamente." : "Las distribuciones de calificaciones no difieren significativamente."}`,
    );
  }
  if (we) {
    insights.push(
      `Prueba t de Welch: diferencia de medias = ${signed(we.meanDiff, 2)}; t(${fmt(we.df, 1)}) = ${fmt(we.t, 3)}; p ${we.p < 0.001 ? "< 0.001" : `= ${fmtP(we.p)}`}; d de Cohen = ${fmt(we.cohenD, 2)}.`,
    );
  }
  if (chi) {
    insights.push(
      `Chi-cuadrada de independencia (sentimiento × establecimiento): χ²(${chi.df}) = ${fmt(chi.chi2, 3)}; p ${chi.p < 0.001 ? "< 0.001" : `= ${fmtP(chi.p)}`}; V de Cramér = ${fmt(chi.cramersV, 3)}.${chi.lowExpectedPct > 20 ? " Precaución: más del 20% de las celdas tienen frecuencias esperadas menores a 5." : ""}`,
    );
  }
  const bySat = [...summary].sort((a, b) => b.satisfactionIndex - a.satisfactionIndex);
  if (bySat.length >= 2) {
    insights.push(`Mayor índice de satisfacción neta: «${bySat[0].name}» (${signed(bySat[0].satisfactionIndex)}).`);
  }
  for (const row of themeMatrix.slice(0, 5)) {
    const vals = row.values
      .map((v, i) => ({ ...v, name: summary[i].name }))
      .filter((v) => v.mentions >= 3 && v.netSentiment !== null);
    if (vals.length < 2) continue;
    vals.sort((a, b) => (b.netSentiment ?? 0) - (a.netSentiment ?? 0));
    const top = vals[0];
    const bottom = vals[vals.length - 1];
    if ((top.netSentiment ?? 0) - (bottom.netSentiment ?? 0) >= 15) {
      insights.push(
        `En «${row.themeName}», «${top.name}» tiene el mejor sentimiento neto (${signed(top.netSentiment)}) frente a «${bottom.name}» (${signed(bottom.netSentiment)}).`,
      );
    }
  }
  if (summary.some((s) => s.n < 30)) {
    insights.push("Advertencia: al menos un establecimiento tiene menos de 30 reseñas; interpreta las pruebas estadísticas con cautela.");
  }

  return {
    generatedAt: new Date().toISOString(),
    places: analyses,
    summary,
    themeMatrix,
    anova: an,
    kruskal: kw,
    welch: we,
    chiSquare: chi,
    insights,
  };
}

export function themeName(id: string | null): string {
  if (!id) return "—";
  return THEME_BY_ID[id]?.name ?? id;
}
