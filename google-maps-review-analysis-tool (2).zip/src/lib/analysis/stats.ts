import type { AnovaResult, ChiSquareResult, DescriptiveStats, KruskalResult, WelchResult } from "./types";

export function sum(xs: number[]): number {
  let s = 0;
  for (const x of xs) s += x;
  return s;
}

export function mean(xs: number[]): number {
  return xs.length ? sum(xs) / xs.length : 0;
}

export function sampleVariance(xs: number[]): number {
  const n = xs.length;
  if (n < 2) return 0;
  const m = mean(xs);
  let s = 0;
  for (const x of xs) s += (x - m) ** 2;
  return s / (n - 1);
}

/** Cuantil con interpolación lineal (equivalente a CUARTIL.INC de Excel). */
export function quantile(sorted: number[], p: number): number {
  if (!sorted.length) return 0;
  const h = (sorted.length - 1) * p;
  const lo = Math.floor(h);
  const hi = Math.ceil(h);
  return sorted[lo] + (h - lo) * (sorted[hi] - sorted[lo]);
}

export function round(x: number, d = 2): number {
  if (!Number.isFinite(x)) return 0;
  const f = 10 ** d;
  return Math.round(x * f) / f;
}

// ---------- Funciones especiales ----------
const LANCZOS = [
  676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905,
  -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7,
];

export function lgamma(x: number): number {
  if (x < 0.5) return Math.log(Math.PI / Math.abs(Math.sin(Math.PI * x))) - lgamma(1 - x);
  const z = x - 1;
  let a = 0.99999999999980993;
  const t = z + 7.5;
  for (let i = 0; i < 8; i++) a += LANCZOS[i] / (z + i + 1);
  return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(a);
}

function betacf(a: number, b: number, x: number): number {
  const MAXIT = 300;
  const EPS = 3e-14;
  const FPMIN = 1e-300;
  const qab = a + b;
  const qap = a + 1;
  const qam = a - 1;
  let c = 1;
  let d = 1 - (qab * x) / qap;
  if (Math.abs(d) < FPMIN) d = FPMIN;
  d = 1 / d;
  let h = d;
  for (let m = 1; m <= MAXIT; m++) {
    const m2 = 2 * m;
    let aa = (m * (b - m) * x) / ((qam + m2) * (a + m2));
    d = 1 + aa * d;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    c = 1 + aa / c;
    if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    h *= d * c;
    aa = (-(a + m) * (qab + m) * x) / ((a + m2) * (qap + m2));
    d = 1 + aa * d;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    c = 1 + aa / c;
    if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < EPS) break;
  }
  return h;
}

/** Función beta incompleta regularizada I_x(a, b). */
export function ibeta(x: number, a: number, b: number): number {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const bt = Math.exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * Math.log(x) + b * Math.log(1 - x));
  if (x < (a + 1) / (a + b + 2)) return (bt * betacf(a, b, x)) / a;
  return 1 - (bt * betacf(b, a, 1 - x)) / b;
}

export function tCdf(t: number, df: number): number {
  const x = df / (df + t * t);
  const tail = 0.5 * ibeta(x, df / 2, 0.5);
  return t >= 0 ? 1 - tail : tail;
}

export function tInv(p: number, df: number): number {
  let lo = -1000;
  let hi = 1000;
  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2;
    if (tCdf(mid, df) < p) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

export function fSurvival(f: number, d1: number, d2: number): number {
  if (f <= 0) return 1;
  return ibeta(d2 / (d2 + d1 * f), d2 / 2, d1 / 2);
}

function gser(a: number, x: number): number {
  let ap = a;
  let del = 1 / a;
  let s = del;
  for (let n = 0; n < 1000; n++) {
    ap += 1;
    del *= x / ap;
    s += del;
    if (Math.abs(del) < Math.abs(s) * 3e-14) break;
  }
  return s * Math.exp(-x + a * Math.log(x) - lgamma(a));
}

function gcf(a: number, x: number): number {
  const FPMIN = 1e-300;
  let b = x + 1 - a;
  let c = 1 / FPMIN;
  let d = 1 / b;
  let h = d;
  for (let i = 1; i < 1000; i++) {
    const an = -i * (i - a);
    b += 2;
    d = an * d + b;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    c = b + an / c;
    if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 3e-14) break;
  }
  return Math.exp(-x + a * Math.log(x) - lgamma(a)) * h;
}

export function gammaQ(a: number, x: number): number {
  if (x <= 0) return 1;
  if (x < a + 1) return 1 - gser(a, x);
  return gcf(a, x);
}

export function chiSquareSurvival(x: number, df: number): number {
  return gammaQ(df / 2, x / 2);
}

// ---------- Estadística descriptiva ----------
export function descriptive(xs: number[]): DescriptiveStats | null {
  const n = xs.length;
  if (!n) return null;
  const sorted = [...xs].sort((a, b) => a - b);
  const m = mean(xs);
  const counts = new Map<number, number>();
  for (const x of xs) counts.set(x, (counts.get(x) ?? 0) + 1);
  const maxFreq = Math.max(...counts.values());
  const mode = [...counts.entries()].filter(([, c]) => c === maxFreq).map(([v]) => v).sort((a, b) => a - b);
  const variance = sampleVariance(xs);
  const sd = Math.sqrt(variance);
  let m3 = 0;
  let m4 = 0;
  if (sd > 0) {
    for (const x of xs) {
      const z = (x - m) / sd;
      m3 += z ** 3;
      m4 += z ** 4;
    }
  }
  const skewness = n > 2 && sd > 0 ? (n / ((n - 1) * (n - 2))) * m3 : 0;
  const kurtosis =
    n > 3 && sd > 0
      ? ((n * (n + 1)) / ((n - 1) * (n - 2) * (n - 3))) * m4 - (3 * (n - 1) ** 2) / ((n - 2) * (n - 3))
      : 0;
  const se = sd / Math.sqrt(n);
  const tcrit = n > 1 ? tInv(0.975, n - 1) : 0;
  const q1 = quantile(sorted, 0.25);
  const q3 = quantile(sorted, 0.75);
  return {
    n,
    mean: round(m, 3),
    median: round(quantile(sorted, 0.5), 3),
    mode,
    stdDev: round(sd, 3),
    variance: round(variance, 3),
    min: sorted[0],
    max: sorted[n - 1],
    range: sorted[n - 1] - sorted[0],
    q1: round(q1, 3),
    q3: round(q3, 3),
    iqr: round(q3 - q1, 3),
    cv: round(m !== 0 ? (sd / m) * 100 : 0, 2),
    skewness: round(skewness, 3),
    kurtosis: round(kurtosis, 3),
    standardError: round(se, 3),
    ci95: [round(m - tcrit * se, 3), round(m + tcrit * se, 3)],
  };
}

// ---------- Pruebas de hipótesis ----------
export function anova(groups: number[][]): AnovaResult | null {
  const valid = groups.filter((g) => g.length > 0);
  const k = valid.length;
  const all = valid.flat();
  const N = all.length;
  if (k < 2 || N - k < 1) return null;
  const grand = mean(all);
  let ssb = 0;
  let ssw = 0;
  for (const g of valid) {
    const m = mean(g);
    ssb += g.length * (m - grand) ** 2;
    for (const x of g) ssw += (x - m) ** 2;
  }
  if (ssw === 0) return null;
  const dfb = k - 1;
  const dfw = N - k;
  const f = ssb / dfb / (ssw / dfw);
  return {
    f: round(f, 4),
    dfBetween: dfb,
    dfWithin: dfw,
    p: fSurvival(f, dfb, dfw),
    etaSquared: round(ssb / (ssb + ssw), 4),
  };
}

export function kruskalWallis(groups: number[][]): KruskalResult | null {
  const valid = groups.filter((g) => g.length > 0);
  const k = valid.length;
  if (k < 2) return null;
  const all: { v: number; g: number }[] = [];
  valid.forEach((g, gi) => g.forEach((v) => all.push({ v, g: gi })));
  const N = all.length;
  if (N < 3) return null;
  all.sort((a, b) => a.v - b.v);
  const ranks = new Array<number>(N);
  let tieSum = 0;
  let i = 0;
  while (i < N) {
    let j = i;
    while (j + 1 < N && all[j + 1].v === all[i].v) j++;
    const avg = (i + j + 2) / 2;
    for (let x = i; x <= j; x++) ranks[x] = avg;
    const t = j - i + 1;
    if (t > 1) tieSum += t ** 3 - t;
    i = j + 1;
  }
  const rankSums = new Array<number>(k).fill(0);
  all.forEach((item, idx) => {
    rankSums[item.g] += ranks[idx];
  });
  let h = 0;
  valid.forEach((g, gi) => {
    h += rankSums[gi] ** 2 / g.length;
  });
  h = (12 / (N * (N + 1))) * h - 3 * (N + 1);
  const c = 1 - tieSum / (N ** 3 - N);
  if (c <= 0) return null;
  h /= c;
  const df = k - 1;
  return { h: round(h, 4), df, p: chiSquareSurvival(h, df), epsilonSquared: round(h / (N - 1), 4) };
}

export function welchT(a: number[], b: number[]): WelchResult | null {
  const n1 = a.length;
  const n2 = b.length;
  if (n1 < 2 || n2 < 2) return null;
  const m1 = mean(a);
  const m2 = mean(b);
  const v1 = sampleVariance(a);
  const v2 = sampleVariance(b);
  const se2 = v1 / n1 + v2 / n2;
  if (se2 === 0) return null;
  const t = (m1 - m2) / Math.sqrt(se2);
  const df = se2 ** 2 / ((v1 / n1) ** 2 / (n1 - 1) + (v2 / n2) ** 2 / (n2 - 1));
  const pooled = Math.sqrt(((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2));
  return {
    t: round(t, 4),
    df: round(df, 2),
    p: 2 * (1 - tCdf(Math.abs(t), df)),
    cohenD: round(pooled > 0 ? (m1 - m2) / pooled : 0, 3),
    meanDiff: round(m1 - m2, 3),
  };
}

export function chiSquareIndependence(table: number[][]): ChiSquareResult | null {
  const rows = table.filter((r) => sum(r) > 0);
  if (rows.length < 2) return null;
  const nCols = rows[0].length;
  const colTotals = Array.from({ length: nCols }, (_, j) => sum(rows.map((r) => r[j])));
  const keep = colTotals.map((c, j) => (c > 0 ? j : -1)).filter((j) => j >= 0);
  if (keep.length < 2) return null;
  const t = rows.map((r) => keep.map((j) => r[j]));
  const rowTotals = t.map((r) => sum(r));
  const cols = keep.map((_, j) => sum(t.map((r) => r[j])));
  const N = sum(rowTotals);
  let chi2 = 0;
  let low = 0;
  for (let i = 0; i < t.length; i++) {
    for (let j = 0; j < cols.length; j++) {
      const e = (rowTotals[i] * cols[j]) / N;
      if (e < 5) low++;
      if (e > 0) chi2 += (t[i][j] - e) ** 2 / e;
    }
  }
  const df = (t.length - 1) * (cols.length - 1);
  const minDim = Math.min(t.length - 1, cols.length - 1);
  return {
    chi2: round(chi2, 4),
    df,
    p: chiSquareSurvival(chi2, df),
    cramersV: round(Math.sqrt(chi2 / (N * minDim)), 4),
    lowExpectedPct: round((low / (t.length * cols.length)) * 100, 1),
  };
}
