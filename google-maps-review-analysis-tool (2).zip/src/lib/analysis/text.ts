const DIACRITICS = /[\u0300-\u036f]/g;

/** Minúsculas, sin acentos ni signos de puntuación. "Atención!!" -> "atencion" */
export function normalize(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(DIACRITICS, "")
    .replace(/['’`´]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function tokenize(text: string): string[] {
  const n = normalize(text);
  return n ? n.split(" ") : [];
}

export const STOPWORDS = new Set(
  (
    // Español
    "a acá aca ahi ahí al algo algun alguna algunas alguno algunos alla alli aqui aquel aquella aquellas aquello aquellos asi aun aunque bajo cada casi como con contra cual cuales cualquier cuando cuanto de del desde donde dos el ella ellas ellos en entre era eran eres es esa esas ese eso esos esta estaba estaban estamos estan estar estas este esto estos estoy estuvo estuvimos fue fueron fui fuimos ha habia habian han has hasta hay he hemos hizo hubo la las le les lo los mas me mi mis mucha muchas mucho muchos muy nada ni no nos nosotros nuestra nuestras nuestro nuestros o os otra otras otro otros para pero poca pocas poco pocos por porque pues que quien quienes se sea ser si sido siempre sin sobre solo son soy su sus tal tambien tan tanto te tenia tenian tener tengo tiene tienen todo toda todas todos tu tus tuvimos tuve un una unas uno unos usted ustedes va vamos van ver vez veces y ya yo ademas entonces igual menos cosa cosas hace hacer hacen hecho puede pueden ir dia dias hoy ayer luego despues antes ahora aun asi mientras cual cuales donde nadie etc q xq pq tb tmb ok vez hora horas dio dar estado sera seria serian haber hacia hacer otro misma mismo mismos mismas parte vale tipo".split(
      " ",
    ) +
    " " +
    // Inglés
    "the a an and or but is are was were be been being it its this that these those to of in on for with at by from as i we you they he she my our your their me us them so very really just not no there here have has had do did does will would can could all also if what which who when where how than then too more most about out up get got one am im ive its dont didnt".split(
      " ",
    )
  )
    .split(/[ ,]+/)
    .filter(Boolean),
);

/** Palabras muy genéricas que no aportan a la identificación de temas. */
export const GENERIC = new Set(
  "lugar lugares sitio sitios gente persona personas algo cosa cosas vez veces dia dias hora horas fue ser estar bien buen buena bueno buenos buenas muy excelente mal mala malo place time good great nice best really recomiendo recomendable recomendado".split(
    " ",
  ),
);

/** Singularización ligera (heurística) para agrupar variantes. */
export function stem(token: string): string {
  if (token.length <= 4) return token;
  if (token.endsWith("iones")) return token.slice(0, -5) + "ion";
  if (/(ares|eres|ores|ales|eles)$/.test(token)) return token.slice(0, -2);
  if (token.endsWith("s") && !token.endsWith("ss") && !token.endsWith("us") && !token.endsWith("is")) {
    return token.slice(0, -1);
  }
  return token;
}

/** Tokens útiles para frecuencias y agrupamiento (sin stopwords ni genéricos). */
export function contentTokens(tokens: string[]): string[] {
  const out: string[] = [];
  for (const t of tokens) {
    if (t.length < 3) continue;
    if (/^\d+$/.test(t)) continue;
    if (STOPWORDS.has(t)) continue;
    const s = stem(t);
    if (GENERIC.has(t) || GENERIC.has(s)) continue;
    out.push(s);
  }
  return out;
}

export interface Clause {
  sentence: number;
  text: string; // normalizado
  tokens: string[];
}

const CONTRAST = /\b(?:pero|aunque|sin embargo|mientras que|but|however|although|though|whereas)\b/g;

/** Divide el texto en oraciones y cláusulas (por comas y conectores de contraste). */
export function splitClauses(raw: string): Clause[] {
  const clauses: Clause[] = [];
  const sentences = raw.split(/[.!?¡¿;\n\r]+/);
  sentences.forEach((sentence, si) => {
    for (const piece of sentence.split(/,/)) {
      const norm = normalize(piece);
      if (!norm) continue;
      for (const part of norm.split(CONTRAST)) {
        const text = part.trim();
        if (!text) continue;
        clauses.push({ sentence: si, text, tokens: text.split(" ") });
      }
    }
  });
  return clauses;
}

export function truncate(text: string, max = 240): string {
  const t = text.replace(/\s+/g, " ").trim();
  return t.length > max ? t.slice(0, max - 1).trimEnd() + "…" : t;
}
