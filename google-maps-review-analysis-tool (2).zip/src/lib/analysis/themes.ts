/**
 * Diccionario de temas frecuentes en reseñas de negocios y lugares turísticos.
 * Palabras normalizadas (sin acentos). "*" = prefijo. Frases con espacios = coincidencia literal.
 */
export interface ThemeDef {
  id: string;
  name: string;
  short: string;
  color: string;
  description: string;
  keywords: string[];
}

export const THEMES: ThemeDef[] = [
  {
    id: "servicio",
    name: "Atención y servicio",
    short: "Servicio",
    color: "#0ea5e9",
    description: "Trato del personal, amabilidad, profesionalismo y atención al cliente.",
    keywords: [
      "servicio*", "atencion*", "atendi*", "atend*", "amabl*", "mesero*", "mesera*", "personal", "staff", "trato",
      "cordial*", "groser*", "descortes*", "educad*", "servicial*", "recepcion*", "empleado*", "encargad*",
      "gerente*", "cajer*", "anfitrion*", "guia", "guias", "hospitalidad*", "profesional*", "atent*", "barista*",
      "service", "friendly", "rude", "waiter*", "waitress*", "employee*", "hospitality", "attentive", "helpful",
    ],
  },
  {
    id: "producto",
    name: "Calidad del producto / comida",
    short: "Producto",
    color: "#f97316",
    description: "Sabor, frescura, calidad, porciones y preparación de alimentos, bebidas o productos.",
    keywords: [
      "comida*", "platillo*", "plato", "platos", "sabor*", "sabros*", "delicios*", "rico", "rica", "ricos", "ricas",
      "insipid*", "calidad", "cocina", "chef*", "postre*", "bebida*", "cafe", "cafes", "coctel*", "cerveza*",
      "marisco*", "pescado*", "taco", "tacos", "hamburgues*", "pizza*", "desayuno*", "cena", "cenar", "almuerzo*",
      "porcion*", "producto*", "ceviche*", "aguachile*", "cochinita*", "panucho*", "salbut*", "carne*", "pan",
      "camaron*", "sazon",
      "frappe*", "jugo*", "ingrediente*", "riquisim*", "buenisim*", "food", "taste*", "tasty", "delicious",
      "dish*", "meal*", "drink*", "coffee", "flavor*", "breakfast", "dinner", "lunch",
    ],
  },
  {
    id: "precio",
    name: "Precio y relación calidad-precio",
    short: "Precio",
    color: "#eab308",
    description: "Percepción de costos, valor recibido, cobros y promociones.",
    keywords: [
      "precio", "precios", "caro", "cara", "caros", "caras", "carisim*", "barat*", "costo", "costos", "costoso*",
      "economic*", "cobr*", "la cuenta", "propina*", "pesos", "dolar*", "dinero", "vale la pena", "calidad precio",
      "tarifa*", "promocion*", "descuento*", "accesible", "accesibles", "price*", "expensive", "cheap",
      "overpriced", "worth", "value", "cost", "pricey", "affordable",
    ],
  },
  {
    id: "limpieza",
    name: "Limpieza e higiene",
    short: "Limpieza",
    color: "#14b8a6",
    description: "Limpieza de instalaciones, baños, mesas, higiene y presencia de plagas u olores.",
    keywords: [
      "limpi*", "sucio*", "sucia*", "suciedad", "higien*", "bano", "banos", "sanitario*", "olor*", "apest*",
      "cucaracha*", "mosca*", "insecto*", "pulcr*", "aseo", "asead*", "basura*", "humedad", "clean*", "dirty",
      "hygien*", "bathroom*", "restroom*", "toilet*", "smell*",
    ],
  },
  {
    id: "ambiente",
    name: "Ambiente, instalaciones y entorno",
    short: "Ambiente",
    color: "#8b5cf6",
    description: "Atmósfera, decoración, música, ruido, comodidad, vistas e instalaciones.",
    keywords: [
      "ambiente*", "atmosfera*", "decoracion*", "decorad*", "musica*", "ruido*", "instalacion*", "espacio*",
      "vista", "vistas", "terraza*", "jardin*", "comod*", "incomod*", "acogedor*", "bonit*", "hermos*", "precioso",
      "preciosa", "aire acondicionado", "calor", "iluminacion*", "mesas", "silla*", "laguna*", "playa*", "muelle*",
      "bahia*", "atardecer*", "naturaleza", "tranquil*", "atmosphere", "ambiance", "ambience", "decor*", "music",
      "noisy", "noise", "view*", "cozy", "beautiful", "comfortable",
    ],
  },
  {
    id: "espera",
    name: "Tiempo de espera y rapidez",
    short: "Espera",
    color: "#ef4444",
    description: "Rapidez del servicio, tiempos de espera, demoras y filas.",
    keywords: [
      "espera", "esperar", "esperamos", "esperando", "esperado", "tard*", "demor*", "lent*", "rapid*", "rapidez",
      "minutos", "media hora", "una hora", "fila", "filas", "prontitud", "inmediat*", "agil*", "eficien*", "wait*",
      "slow*", "fast", "quick*", "minutes", "queue",
    ],
  },
  {
    id: "ubicacion",
    name: "Ubicación, acceso y estacionamiento",
    short: "Ubicación",
    color: "#22c55e",
    description: "Facilidad para llegar, estacionamiento, zona, seguridad del entorno y transporte.",
    keywords: [
      "ubicacion*", "ubicad*", "estacionamiento*", "estacionar*", "parking", "acceso*", "llegar", "centro",
      "centric*", "calle", "calles", "zona", "direccion*", "transporte*", "taxi*", "cerca", "lejos", "location*",
      "located", "downtown",
    ],
  },
  {
    id: "variedad",
    name: "Variedad y oferta (menú, opciones)",
    short: "Variedad",
    color: "#ec4899",
    description: "Amplitud del menú o catálogo, opciones especiales y disponibilidad.",
    keywords: [
      "variedad*", "opcion*", "menu*", "carta", "surtid*", "seleccion*", "oferta*", "alternativa*", "vegetarian*",
      "vegan*", "gluten", "especialidad*", "disponib*", "se acabo", "se les acabo", "variety", "options", "selection",
      "choice*",
    ],
  },
  {
    id: "hospedaje",
    name: "Habitaciones y hospedaje",
    short: "Hospedaje",
    color: "#6366f1",
    description: "Habitaciones, camas, albercas, regaderas y estancia en hoteles o alojamientos.",
    keywords: [
      "habitacion*", "cuarto", "cuartos", "cama", "camas", "colchon*", "almohada*", "sabana*", "toalla*", "ducha*",
      "regadera*", "alberca*", "piscina*", "hotel*", "hospedaje*", "hospedamos", "hospedarse", "estancia*",
      "suite*", "cabana*", "room*", "bed", "beds", "pool*", "stay*", "shower*", "towel*",
    ],
  },
  {
    id: "experiencia",
    name: "Experiencia general y recomendación",
    short: "Experiencia",
    color: "#84cc16",
    description: "Valoración global, intención de regresar y recomendación a otras personas.",
    keywords: [
      "recomend*", "recomiend*", "volver*", "volvere*", "volveria*", "vuelvo", "regres*", "repetir*",
      "experiencia*", "imperdible*", "favorit*", "decepcion*", "nunca mas", "recommend*", "experience*",
      "disappoint*", "come back", "will return",
    ],
  },
  {
    id: "extras",
    name: "Pagos, reservas y servicios adicionales",
    short: "Pagos/extras",
    color: "#64748b",
    description: "Formas de pago, Wi-Fi, reservaciones, pedidos y servicio a domicilio.",
    keywords: [
      "wifi", "wi fi", "internet", "tarjeta*", "efectivo", "pago", "pagos", "pagar", "terminal", "reservacion*",
      "reserva", "reservar", "reservamos", "pedido*", "domicilio*", "delivery", "factura*", "whatsapp", "para llevar",
      "card", "cash", "payment*", "reservation*", "booking*", "takeout",
    ],
  },
  {
    id: "familia",
    name: "Familias, mascotas y accesibilidad",
    short: "Familia/acces.",
    color: "#d946ef",
    description: "Experiencia con niños, mascotas, accesibilidad para personas con discapacidad.",
    keywords: [
      "nino*", "nina*", "infantil*", "familia*", "familiar*", "mascota*", "perro*", "perrit*", "pet", "pets",
      "pet friendly", "bebe*", "accesibilidad", "silla de ruedas", "discapacidad*", "rampa*", "kids", "children",
      "family", "dog*", "wheelchair",
    ],
  },
];

export const THEME_BY_ID: Record<string, ThemeDef> = Object.fromEntries(THEMES.map((t) => [t.id, t]));

interface Matcher {
  id: string;
  exact: Set<string>;
  prefixes: string[];
  phrases: string[];
}

const MATCHERS: Matcher[] = THEMES.map((t) => {
  const m: Matcher = { id: t.id, exact: new Set(), prefixes: [], phrases: [] };
  for (const k of t.keywords) {
    if (k.includes(" ")) m.phrases.push(k);
    else if (k.endsWith("*")) m.prefixes.push(k.slice(0, -1));
    else m.exact.add(k);
  }
  return m;
});

/** Detecta temas en una cláusula/texto normalizado. Devuelve themeId -> palabras clave encontradas. */
export function detectThemes(tokens: string[]): Map<string, string[]> {
  const found = new Map<string, string[]>();
  const padded = ` ${tokens.join(" ")} `;
  for (const m of MATCHERS) {
    const hits: string[] = [];
    for (const t of tokens) {
      if (m.exact.has(t)) {
        hits.push(t);
        continue;
      }
      for (const p of m.prefixes) {
        if (t.startsWith(p)) {
          hits.push(t);
          break;
        }
      }
    }
    for (const ph of m.phrases) {
      if (padded.includes(` ${ph} `)) hits.push(ph);
    }
    if (hits.length) found.set(m.id, hits);
  }
  return found;
}
