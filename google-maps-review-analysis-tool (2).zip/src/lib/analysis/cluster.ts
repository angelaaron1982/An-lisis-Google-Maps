/** Generador pseudoaleatorio determinista (mulberry32). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface SparseVec {
  idx: number[];
  val: number[];
}

export interface RawCluster {
  members: number[]; // índices de documento
  sims: number[];
  terms: { term: string; weight: number }[];
}

export interface ClusterOutput {
  assignments: number[]; // -1 si el documento no se agrupó
  clusters: RawCluster[];
}

function dot(v: SparseVec, c: Float64Array): number {
  let s = 0;
  for (let i = 0; i < v.idx.length; i++) s += v.val[i] * c[v.idx[i]];
  return s;
}

/**
 * Agrupamiento de opiniones: TF-IDF + k-means esférico (similitud coseno)
 * con inicialización k-means++ determinista y varios reinicios.
 */
export function clusterDocuments(
  docs: string[][],
  opts: { k?: number; seed?: number; restarts?: number } = {},
): ClusterOutput | null {
  const n = docs.length;
  if (n < 12) return null;
  const df = new Map<string, number>();
  for (const d of docs) for (const t of new Set(d)) df.set(t, (df.get(t) ?? 0) + 1);
  const maxDf = n >= 20 ? 0.5 * n : 0.8 * n;
  const vocab: string[] = [];
  const index = new Map<string, number>();
  for (const [t, c] of df) {
    if (c >= 2 && c <= maxDf) {
      index.set(t, vocab.length);
      vocab.push(t);
    }
  }
  if (vocab.length < 8) return null;

  const vecs: (SparseVec | null)[] = docs.map((d) => {
    const tf = new Map<number, number>();
    for (const t of d) {
      const i = index.get(t);
      if (i !== undefined) tf.set(i, (tf.get(i) ?? 0) + 1);
    }
    if (!tf.size) return null;
    const idx: number[] = [];
    const val: number[] = [];
    let norm = 0;
    for (const [i, c] of tf) {
      const w = (1 + Math.log(c)) * (Math.log((1 + n) / (1 + (df.get(vocab[i]) ?? 1))) + 1);
      idx.push(i);
      val.push(w);
      norm += w * w;
    }
    norm = Math.sqrt(norm);
    return { idx, val: val.map((v) => v / norm) };
  });

  const validIdx = vecs.map((v, i) => (v ? i : -1)).filter((i) => i >= 0);
  const nValid = validIdx.length;
  if (nValid < 12) return null;
  const k = Math.max(2, Math.min(opts.k ?? Math.round(Math.sqrt(nValid / 4)), 6, Math.floor(nValid / 4)));
  const V = vocab.length;
  const vec = (di: number) => vecs[di] as SparseVec;

  const toDense = (v: SparseVec) => {
    const c = new Float64Array(V);
    for (let i = 0; i < v.idx.length; i++) c[v.idx[i]] = v.val[i];
    return c;
  };

  const runOnce = (rand: () => number) => {
    // Inicialización k-means++
    const centroids: Float64Array[] = [toDense(vec(validIdx[Math.floor(rand() * nValid)]))];
    while (centroids.length < k) {
      const dists = validIdx.map((di) => {
        let best = -Infinity;
        for (const c of centroids) best = Math.max(best, dot(vec(di), c));
        return Math.max(0, 1 - best) ** 2;
      });
      const total = dists.reduce((a, b) => a + b, 0);
      let r = rand() * total;
      let chosen = validIdx[validIdx.length - 1];
      for (let i = 0; i < dists.length; i++) {
        r -= dists[i];
        if (r <= 0) {
          chosen = validIdx[i];
          break;
        }
      }
      centroids.push(toDense(vec(chosen)));
    }

    const assign = new Array<number>(n).fill(-1);
    for (let iter = 0; iter < 40; iter++) {
      let changed = false;
      for (const di of validIdx) {
        let best = 0;
        let bestSim = -Infinity;
        for (let c = 0; c < k; c++) {
          const s = dot(vec(di), centroids[c]);
          if (s > bestSim) {
            bestSim = s;
            best = c;
          }
        }
        if (assign[di] !== best) {
          assign[di] = best;
          changed = true;
        }
      }
      for (let c = 0; c < k; c++) {
        const acc = new Float64Array(V);
        let count = 0;
        for (const di of validIdx) {
          if (assign[di] !== c) continue;
          const v = vec(di);
          for (let i = 0; i < v.idx.length; i++) acc[v.idx[i]] += v.val[i];
          count++;
        }
        if (!count) acc.set(toDense(vec(validIdx[Math.floor(rand() * nValid)])));
        let norm = 0;
        for (let i = 0; i < V; i++) norm += acc[i] * acc[i];
        norm = Math.sqrt(norm) || 1;
        for (let i = 0; i < V; i++) acc[i] /= norm;
        centroids[c] = acc;
      }
      if (!changed && iter > 0) break;
    }
    let objective = 0;
    for (const di of validIdx) objective += dot(vec(di), centroids[assign[di]]);
    return { assign, centroids, objective };
  };

  const baseSeed = opts.seed ?? 42;
  let best = runOnce(mulberry32(baseSeed));
  for (let r = 1; r < (opts.restarts ?? 6); r++) {
    const run = runOnce(mulberry32(baseSeed + r * 1013));
    if (run.objective > best.objective) best = run;
  }
  const { assign, centroids } = best;

  const clusters: RawCluster[] = [];
  const remap = new Map<number, number>();
  for (let c = 0; c < k; c++) {
    const members = validIdx.filter((di) => assign[di] === c);
    if (!members.length) continue;
    const sims = members.map((di) => dot(vec(di), centroids[c]));
    const terms = Array.from(centroids[c])
      .map((w, i) => ({ term: vocab[i], weight: w }))
      .filter((t) => t.weight > 0)
      .sort((a, b) => b.weight - a.weight)
      .slice(0, 6);
    remap.set(c, clusters.length);
    clusters.push({ members, sims, terms });
  }
  const assignments = assign.map((a) => (a >= 0 ? (remap.get(a) ?? -1) : -1));
  return { assignments, clusters };
}
