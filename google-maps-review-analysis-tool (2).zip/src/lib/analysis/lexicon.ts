/**
 * Léxico de sentimiento (español e inglés) en forma normalizada (sin acentos).
 * Un asterisco final indica coincidencia por prefijo.
 */
type Entry = [string, number];

const POSITIVE: Entry[] = [
  // +3
  ...[
    "excelente*", "exelente*", "espectacular*", "increibl*", "maravill*", "perfect*", "buenisim*", "riquisim*",
    "deliciosisim*", "fantastic*", "extraordinari*", "impecabl*", "insuperabl*", "fenomenal*", "magnific*",
    "fabulos*", "inmejorabl*", "outstanding", "amazing", "excellent", "awesome", "wonderful", "incredible",
    "superb", "exceptional", "spectacular", "gorgeous", "flawless",
  ].map((t): Entry => [t, 3]),
  // +2
  ...[
    "delicios*", "bueno", "buena", "buenos", "buenas", "buen", "rico", "rica", "ricos", "ricas", "sabros*",
    "amabl*", "encant*", "recomendabl*", "recomendad*", "recomiendo", "recomendamos", "genial*", "hermos*",
    "bonit*", "precioso", "preciosa", "preciosos", "preciosas", "agradabl*", "atent*", "limpio", "limpia",
    "limpios", "limpias", "comod*", "cordial*", "acogedor*", "calido", "calida", "divertid*", "disfrut*", "feliz",
    "felices", "satisfech*", "servicial*", "favorit*", "lindo", "linda", "lindos", "lindas", "estupend*", "chido",
    "chida", "rapidisim*", "agradecid*", "good", "great", "nice", "friendly", "delicious", "tasty", "clean",
    "lovely", "beautiful", "cozy", "comfortable", "helpful", "best", "love", "loved", "enjoyed", "enjoy", "happy",
    "recommend", "recommended", "pleasant", "attentive", "polite", "kind", "fun",
  ].map((t): Entry => [t, 2]),
  // +1.5
  ...[
    "gust*", "mejor", "mejores", "top", "eficient*", "profesional*", "puntual*", "rapid*", "tranquil*", "fast",
    "quick", "worth", "bienvenid*",
  ].map((t): Entry => [t, 1.5]),
  // +1
  ...["bien", "fresc*", "economic*", "barat*", "accesibl*", "amplio", "amplia", "amplios", "amplias", "agil*", "fresh", "cheap", "affordable"].map(
    (t): Entry => [t, 1],
  ),
  // +0.5
  ...["justo", "aceptabl*", "correct*", "decente*", "pront*", "ok", "okay", "fine", "gracias"].map((t): Entry => [t, 0.5]),
];

const NEGATIVE: Entry[] = [
  // -3
  ...[
    "pesim*", "horribl*", "terribl*", "asquer*", "fatal*", "nefast*", "desastr*", "estafa*", "estafador*",
    "fraude*", "inaceptabl*", "verguenza", "vergonzos*", "nauseabund*", "intoxic*", "cucaracha*", "rata", "ratas",
    "apest*", "repugnant*", "incomibl*", "deplorabl*", "worst", "awful", "horrible", "terrible", "disgusting", "scam",
    "nasty", "inedible",
  ].map((t): Entry => [t, -3]),
  // -2.5
  ...["peor", "peores", "carisim*", "lamentabl*", "maltrat*", "stink*"].map((t): Entry => [t, -2.5]),
  // -2
  ...[
    "mal", "malo", "mala", "malos", "malas", "malisim*", "sucio", "sucia", "sucios", "sucias", "suciedad",
    "groser*", "descortes*", "prepotent*", "decepcion*", "insipid*", "desagradabl*", "lento", "lenta", "lentos",
    "lentas", "lentitud", "tardad*", "tardaron", "tardo", "tardan", "tardanza", "tardisim*", "demor*", "abusiv*",
    "deficient*", "mediocr*", "quemad*", "incomod*", "enoj*", "frustr*", "feo", "fea", "feos", "feas",
    "desorganiz*", "bad", "rude", "dirty", "overpriced", "disappoint*", "unfriendly", "mediocre", "worse",
    "unprofessional",
  ].map((t): Entry => [t, -2]),
  // -1.5
  ...[
    "caro", "cara", "caros", "caras", "excesiv*", "olvidaron", "equivocad*", "error*", "problema*", "queja*",
    "molest*", "triste*", "ignor*", "descuid*", "poor", "slow", "expensive", "bland", "problem*", "wrong",
    "careless",
  ].map((t): Entry => [t, -1.5]),
  // -1
  ...[
    "ruido", "ruidos*", "falta", "falto", "faltaron", "crudo", "cruda", "salado", "salada", "grasos*", "aceitos*",
    "regular", "escas*", "olvido", "noisy", "waited",
  ].map((t): Entry => [t, -1]),
  // -0.5
  ...["duro", "dura", "elevad*", "cold", "waiting"].map((t): Entry => [t, -0.5]),
];

/** Frases (se evalúan antes que las palabras; las más largas primero). */
const PHRASE_LIST: Entry[] = [
  ["no vale la pena", -2.5],
  ["no valio la pena", -2.5],
  ["deja mucho que desear", -2.5],
  ["dejo mucho que desear", -2.5],
  ["deja que desear", -2],
  ["nunca mas", -2.5],
  ["no vuelvo", -2.5],
  ["no volvere", -2.5],
  ["no volveria", -2.5],
  ["no volveremos", -2.5],
  ["no regreso", -2.5],
  ["no regresare", -2.5],
  ["no regresaria", -2.5],
  ["no regresaremos", -2.5],
  ["no lo recomiendo", -2.5],
  ["no recomiendo", -2.5],
  ["no se lo recomiendo", -2.5],
  ["no recomendable", -2.5],
  ["poco recomendable", -2],
  ["cobran de mas", -2.5],
  ["cobraron de mas", -2.5],
  ["lo peor", -3],
  ["mas de una hora", -1.5],
  ["media hora", -1],
  ["mucho tiempo", -1],
  ["fuera de servicio", -1.5],
  ["no funciona", -1.5],
  ["no funcionaba", -1.5],
  ["no sirve", -1.5],
  ["no servia", -1.5],
  ["never again", -3],
  ["not worth", -2.5],
  ["waste of", -2.5],
  ["would not recommend", -3],
  ["do not recommend", -3],
  ["dont recommend", -3],
  ["sin duda", 1],
  ["nada mal", 1.5],
  ["no hay queja", 2],
  ["no hay quejas", 2],
  ["ninguna queja", 2],
  ["sin queja", 2],
  ["sin quejas", 2],
  ["sin problema", 1],
  ["sin problemas", 1],
  ["no se arrepentiran", 2.5],
  ["no te arrepentiras", 2.5],
  ["no me arrepiento", 2],
  ["vale la pena", 2],
  ["valio la pena", 2],
  ["lo maximo", 3],
  ["10 de 10", 3],
  ["10 10", 3],
  ["de 10", 2],
  ["5 estrellas", 2],
  ["cinco estrellas", 2],
  ["al 100", 1.5],
  ["precio justo", 1.5],
  ["worth it", 2],
  ["highly recommend", 3],
  ["must visit", 2],
  ["will return", 2],
  ["come back", 1.5],
  ["no complaints", 2],
  ["not bad", 1],
  ["no tuvimos que esperar", 1.5],
  ["sin esperar", 1],
  ["pocos minutos", 1],
  ["demasiado tiempo", -1.5],
  ["no hay estacionamiento", -1.5],
  ["poca variedad", -1.5],
  ["pocas opciones", -1.5],
  ["solo aceptan efectivo", -1.5],
  ["solo efectivo", -1.5],
  ["pet friendly", 1.5],
];
const EXTRA_WORDS: Entry[] = [
  ["aguad*", -1.5],
  ["insoportabl*", -2.5],
  ["facil*", 1],
  ["dificil*", -1],
  ["seguro", 1],
  ["segura", 1],
  ["seguros", 1],
  ["seguras", 1],
  ["gran", 1.5],
  ["manchad*", -1.5],
  ["ideal", 1.5],
  ["consient*", 1.5],
  ["respet*", 1],
  ["permit*", 0.5],
];
const PHRASES: Entry[] = [...PHRASE_LIST].sort((a, b) => b[0].length - a[0].length);

const NEGATORS = new Set([
  "no", "nunca", "jamas", "ni", "tampoco", "nada", "sin", "ningun", "ninguna", "ninguno", "not", "never", "dont",
  "didnt", "doesnt", "isnt", "wasnt", "werent", "arent", "wont", "cant", "couldnt", "wouldnt", "nothing", "without",
  "nor", "hardly",
]);

const INTENSIFIERS: Record<string, number> = {
  muy: 1.3, super: 1.35, bastante: 1.2, demasiado: 1.3, tan: 1.15, sumamente: 1.4, realmente: 1.2, totalmente: 1.2,
  extremadamente: 1.4, increiblemente: 1.4, mega: 1.3, mas: 1.1, ampliamente: 1.2, altamente: 1.3, very: 1.3,
  really: 1.2, so: 1.15, extremely: 1.4, absolutely: 1.3, too: 1.2, highly: 1.3, incredibly: 1.4, totally: 1.2,
  quite: 1.1,
};

const DIMINISHERS: Record<string, number> = {
  algo: 0.7, ligeramente: 0.7, medio: 0.75, relativamente: 0.8, slightly: 0.7, somewhat: 0.7, bit: 0.7, little: 0.8,
  kinda: 0.8,
};

const exact = new Map<string, number>();
const prefixes: Entry[] = [];
for (const [term, w] of [...POSITIVE, ...NEGATIVE, ...EXTRA_WORDS]) {
  if (term.endsWith("*")) prefixes.push([term.slice(0, -1), w]);
  else exact.set(term, w);
}
prefixes.sort((a, b) => b[0].length - a[0].length);

export function lookupWord(token: string): number | null {
  const e = exact.get(token);
  if (e !== undefined) return e;
  for (const [p, w] of prefixes) {
    if (token.length >= p.length && token.startsWith(p)) return w;
  }
  return null;
}

export interface SentimentRaw {
  sum: number;
  hits: number;
}

/** Puntaje de sentimiento para tokens normalizados (frases + palabras + modificadores). */
export function scoreTokens(tokens: string[]): SentimentRaw {
  let text = ` ${tokens.join(" ")} `;
  let sum = 0;
  let hits = 0;
  for (const [phrase, w] of PHRASES) {
    const needle = ` ${phrase} `;
    let idx = text.indexOf(needle);
    while (idx !== -1) {
      sum += w;
      hits++;
      text = `${text.slice(0, idx)} | ${text.slice(idx + needle.length)}`;
      idx = text.indexOf(needle);
    }
  }
  const toks = text.trim().split(/\s+/).filter(Boolean);
  for (let i = 0; i < toks.length; i++) {
    const t = toks[i];
    if (t === "|") continue;
    const base = lookupWord(t);
    if (base === null) continue;
    let mult = 1;
    let negated = false;
    for (let j = i - 1; j >= Math.max(0, i - 3); j--) {
      const p = toks[j];
      if (p === "|") break;
      if (NEGATORS.has(p)) negated = true;
      else if (INTENSIFIERS[p]) mult *= INTENSIFIERS[p];
      else if (DIMINISHERS[p]) mult *= DIMINISHERS[p];
      else if (p === "poco" || p === "poca" || p === "pocos" || p === "pocas") {
        const prev = toks[j - 1];
        if (prev === "un" || prev === "una") mult *= 0.6;
        else {
          negated = true;
          mult *= 0.6;
        }
      }
    }
    let w = base * mult;
    if (negated) w *= -0.75;
    sum += w;
    hits++;
  }
  return { sum, hits };
}

const POS_EMOJI = /(😍|🥰|😊|😀|😁|😃|😄|👍|👌|💯|❤|💕|💖|🤩|😋|🙌|👏|⭐|🌟)/gu;
const NEG_EMOJI = /(👎|😡|😠|🤮|🤢|😤|😞|😒|💩|😭|😢)/gu;

export function emojiScore(raw: string): SentimentRaw {
  const pos = (raw.match(POS_EMOJI) ?? []).length;
  const neg = (raw.match(NEG_EMOJI) ?? []).length;
  const sum = Math.min(pos, 2) * 1.5 - Math.min(neg, 2) * 1.5;
  return { sum, hits: pos + neg };
}

/** Normaliza una suma de pesos a [-1, 1]. */
export function normalizeScore(sum: number): number {
  return sum / Math.sqrt(sum * sum + 6);
}
