export type Sentiment = "positivo" | "neutral" | "negativo";

export interface ReviewInput {
  id: number;
  author: string | null;
  rating: number;
  text: string;
  publishedAt: string | null;
  relativeTime: string | null;
  likes: number | null;
  ownerResponse: string | null;
  language: string | null;
}

export interface PlaceInfo {
  id: number;
  source: string;
  externalId: string;
  name: string;
  address: string | null;
  category: string | null;
  googleRating: number | null;
  googleRatingCount: number | null;
  mapsUrl: string | null;
  website: string | null;
  phone: string | null;
  topics: { keyword: string; mentions: number }[] | null;
  createdAt: string;
  updatedAt: string;
}

export interface PlaceSummary extends PlaceInfo {
  reviewCount: number;
  avgRating: number | null;
}

export interface DescriptiveStats {
  n: number;
  mean: number;
  median: number;
  mode: number[];
  stdDev: number;
  variance: number;
  min: number;
  max: number;
  range: number;
  q1: number;
  q3: number;
  iqr: number;
  cv: number;
  skewness: number;
  kurtosis: number;
  standardError: number;
  ci95: [number, number];
}

export interface RatingBucket {
  stars: number;
  count: number;
  percent: number;
  cumulativePercent: number;
}

export interface SentimentSummary {
  positive: number;
  neutral: number;
  negative: number;
  positivePct: number;
  neutralPct: number;
  negativePct: number;
  avgScore: number;
  netSentiment: number;
}

export interface ThemeExample {
  reviewId: number;
  rating: number;
  sentiment: Sentiment;
  text: string;
}

export interface ThemeResult {
  id: string;
  name: string;
  color: string;
  description: string;
  mentions: number;
  percentOfReviews: number;
  avgRating: number | null;
  positive: number;
  neutral: number;
  negative: number;
  netSentiment: number;
  avgSentimentScore: number;
  topKeywords: { term: string; count: number }[];
  examples: ThemeExample[];
}

export interface ClusterResult {
  id: number;
  label: string;
  terms: string[];
  size: number;
  percent: number;
  avgRating: number;
  positivePct: number;
  negativePct: number;
  dominantTheme: string | null;
  examples: { reviewId: number; rating: number; text: string }[];
}

export interface TermFreq {
  term: string;
  count: number;
}

export interface TrendPoint {
  period: string;
  count: number;
  avgRating: number;
  positivePct: number;
}

export interface AnalyzedReview extends ReviewInput {
  sentimentScore: number;
  textSentiment: number | null;
  sentiment: Sentiment;
  themes: string[];
  themeSentiments: Record<string, Sentiment>;
  wordCount: number;
  clusterId: number | null;
}

export interface PlaceAnalysis {
  place: PlaceInfo;
  generatedAt: string;
  totals: {
    reviews: number;
    withText: number;
    withOwnerResponse: number;
    avgWords: number;
    dateFrom: string | null;
    dateTo: string | null;
  };
  stats: DescriptiveStats | null;
  distribution: RatingBucket[];
  sentiment: SentimentSummary;
  satisfactionIndex: number;
  themes: ThemeResult[];
  clusters: ClusterResult[];
  topWords: TermFreq[];
  topBigrams: TermFreq[];
  trend: TrendPoint[];
  trendGranularity: "mes" | "trimestre" | "año";
  insights: string[];
  reviews: AnalyzedReview[];
}

export interface AnovaResult {
  f: number;
  dfBetween: number;
  dfWithin: number;
  p: number;
  etaSquared: number;
}

export interface KruskalResult {
  h: number;
  df: number;
  p: number;
  epsilonSquared: number;
}

export interface WelchResult {
  t: number;
  df: number;
  p: number;
  cohenD: number;
  meanDiff: number;
}

export interface ChiSquareResult {
  chi2: number;
  df: number;
  p: number;
  cramersV: number;
  lowExpectedPct: number;
}

export interface CompareSummaryRow {
  placeId: number;
  name: string;
  source: string;
  color: string;
  googleRating: number | null;
  googleRatingCount: number | null;
  n: number;
  withText: number;
  mean: number | null;
  median: number | null;
  stdDev: number | null;
  positivePct: number;
  neutralPct: number;
  negativePct: number;
  satisfactionIndex: number;
  topTheme: string | null;
  strength: string | null;
  weakness: string | null;
}

export interface ThemeMatrixRow {
  themeId: string;
  themeName: string;
  color: string;
  values: {
    placeId: number;
    mentions: number;
    percent: number;
    avgRating: number | null;
    netSentiment: number | null;
  }[];
}

export interface ComparisonResult {
  generatedAt: string;
  places: PlaceAnalysis[];
  summary: CompareSummaryRow[];
  themeMatrix: ThemeMatrixRow[];
  anova: AnovaResult | null;
  kruskal: KruskalResult | null;
  welch: WelchResult | null;
  chiSquare: ChiSquareResult | null;
  insights: string[];
}
