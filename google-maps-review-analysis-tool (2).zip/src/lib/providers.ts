export class ProviderError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export type Provider = "google" | "serpapi";

export interface PlaceCandidate {
  provider: Provider;
  externalId: string;
  name: string;
  address: string | null;
  rating: number | null;
  ratingCount: number | null;
  category: string | null;
  mapsUrl: string | null;
  lat: number | null;
  lng: number | null;
  thumbnail: string | null;
}

export interface FetchedReview {
  externalId: string;
  author: string | null;
  authorUrl: string | null;
  rating: number;
  text: string;
  language: string | null;
  publishedAt: Date | null;
  relativeTime: string | null;
  likes: number | null;
  ownerResponse: string | null;
}

export interface FetchedPlace {
  source: "google" | "serpapi" | "demo" | "import";
  externalId: string;
  name: string;
  address: string | null;
  category: string | null;
  googleRating: number | null;
  googleRatingCount: number | null;
  mapsUrl: string | null;
  website: string | null;
  phone: string | null;
  lat: number | null;
  lng: number | null;
  topics: { keyword: string; mentions: number }[] | null;
  reviews: FetchedReview[];
  notes: string[];
}

export type KeySource = "browser" | "server" | null;

export interface ResolvedKeys {
  google: string;
  serpapi: string;
  googleSource: KeySource;
  serpapiSource: KeySource;
}

/** Limpia espacios, saltos de línea y comillas que suelen colarse al copiar y pegar. */
export function cleanKey(v: string | null | undefined): string {
  return (v ?? "").replace(/\s+/g, "").replace(/^["'`]+|["'`]+$/g, "");
}

function serverGoogleKey(): string {
  return cleanKey(process.env.GOOGLE_MAPS_API_KEY || process.env.GOOGLE_PLACES_API_KEY);
}

function serverSerpKey(): string {
  return cleanKey(process.env.SERPAPI_API_KEY || process.env.SERPAPI_KEY);
}

/** Claves: primero la proporcionada por el usuario (cabecera), después las variables de entorno. */
export function resolveKeys(req: Request): ResolvedKeys {
  const gHeader = cleanKey(req.headers.get("x-google-maps-key"));
  const sHeader = cleanKey(req.headers.get("x-serpapi-key"));
  const gServer = serverGoogleKey();
  const sServer = serverSerpKey();
  return {
    google: gHeader || gServer,
    serpapi: sHeader || sServer,
    googleSource: gHeader ? "browser" : gServer ? "server" : null,
    serpapiSource: sHeader ? "browser" : sServer ? "server" : null,
  };
}

export function serverKeysStatus() {
  return { google: Boolean(serverGoogleKey()), serpapi: Boolean(serverSerpKey()) };
}

function clampRating(x: unknown): number | null {
  const n = Number(x);
  if (!Number.isFinite(n) || n <= 0) return null;
  return Math.min(5, Math.max(1, Math.round(n)));
}

function toDate(x: string | number | null | undefined): Date | null {
  if (x === null || x === undefined || x === "") return null;
  const d = typeof x === "number" ? new Date(x) : new Date(x);
  return Number.isNaN(d.getTime()) ? null : d;
}

// ---------------------------------------------------------------------------
// Enlaces de Google Maps
// ---------------------------------------------------------------------------
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

export interface ParsedMapsInput {
  isUrl: boolean;
  query: string;
  name: string | null;
  lat: number | null;
  lng: number | null;
  dataId: string | null;
  placeId: string | null;
  resolvedUrl: string | null;
}

export async function parseMapsInput(input: string): Promise<ParsedMapsInput> {
  const raw = input.trim();
  const res: ParsedMapsInput = {
    isUrl: false,
    query: raw,
    name: null,
    lat: null,
    lng: null,
    dataId: null,
    placeId: null,
    resolvedUrl: null,
  };
  if (!/^https?:\/\//i.test(raw)) return res;
  res.isUrl = true;
  let url = raw;
  try {
    const host = new URL(raw).hostname;
    if (/(^|\.)goo\.gl$|(^|\.)g\.co$|(^|\.)maps\.app\.goo\.gl$/.test(host)) {
      const r = await fetch(raw, { redirect: "follow", headers: { "User-Agent": UA }, signal: AbortSignal.timeout(12000) });
      url = r.url || raw;
    }
  } catch {
    // se intenta con la URL original
  }
  res.resolvedUrl = url;
  let decoded = url;
  try {
    decoded = decodeURIComponent(decodeURIComponent(url));
  } catch {
    try {
      decoded = decodeURIComponent(url);
    } catch {
      decoded = url;
    }
  }
  const nameM = decoded.match(/\/maps\/place\/([^/@?]+)/);
  if (nameM) res.name = nameM[1].replace(/\+/g, " ").trim();
  const precise = decoded.match(/!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)/);
  const at = decoded.match(/@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/);
  const coord = precise ?? at;
  if (coord) {
    res.lat = Number(coord[1]);
    res.lng = Number(coord[2]);
  }
  const dataM = decoded.match(/(0x[0-9a-fA-F]+:0x[0-9a-fA-F]+)/);
  if (dataM) res.dataId = dataM[1];
  const pidM = decoded.match(/(?:place_id[:=]|query_place_id=)([A-Za-z0-9_-]{16,})/);
  if (pidM) res.placeId = pidM[1];
  try {
    const u = new URL(url);
    const q = u.searchParams.get("q") ?? u.searchParams.get("query");
    if (q && !res.name && !q.startsWith("place_id:")) res.name = q;
  } catch {
    // ignorar
  }
  res.query = res.name ?? raw;
  return res;
}

// ---------------------------------------------------------------------------
// Google Places API (New)
// ---------------------------------------------------------------------------
interface GLocalized {
  text?: string;
  languageCode?: string;
}
interface GReview {
  name?: string;
  relativePublishTimeDescription?: string;
  rating?: number;
  text?: GLocalized;
  originalText?: GLocalized;
  authorAttribution?: { displayName?: string; uri?: string };
  publishTime?: string;
}
interface GPlace {
  id?: string;
  displayName?: GLocalized;
  formattedAddress?: string;
  rating?: number;
  userRatingCount?: number;
  googleMapsUri?: string;
  primaryTypeDisplayName?: GLocalized;
  location?: { latitude?: number; longitude?: number };
  websiteUri?: string;
  nationalPhoneNumber?: string;
  reviews?: GReview[];
}
interface LegacyReview {
  author_name?: string;
  author_url?: string;
  language?: string;
  rating?: number;
  relative_time_description?: string;
  text?: string;
  time?: number;
}

const SEARCH_MASK =
  "places.id,places.displayName,places.formattedAddress,places.rating,places.userRatingCount,places.googleMapsUri,places.primaryTypeDisplayName,places.location";
const BASIC_MASK = "id,displayName,formattedAddress,rating,userRatingCount,googleMapsUri,primaryTypeDisplayName,location";
const DETAILS_MASK = `${BASIC_MASK},websiteUri,nationalPhoneNumber,reviews`;

async function googleRequest<T>(url: string, key: string, fieldMask: string, body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method: body ? "POST" : "GET",
    headers: { "Content-Type": "application/json", "X-Goog-Api-Key": key, "X-Goog-FieldMask": fieldMask },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(20000),
    cache: "no-store",
  });
  const json = (await res.json().catch(() => ({}))) as T & { error?: { message?: string; status?: string } };
  if (!res.ok) {
    const msg = json.error?.message ?? res.statusText;
    throw new ProviderError(
      `Google Places API respondió: ${msg}${json.error?.status ? ` (${json.error.status})` : ""}. Verifica que la clave sea válida y que «Places API (New)» esté habilitada en Google Cloud.`,
      res.status === 401 || res.status === 403 ? 401 : 502,
    );
  }
  return json;
}

function mapGoogleCandidate(p: GPlace): PlaceCandidate {
  return {
    provider: "google",
    externalId: p.id ?? "",
    name: p.displayName?.text ?? "Sin nombre",
    address: p.formattedAddress ?? null,
    rating: p.rating ?? null,
    ratingCount: p.userRatingCount ?? null,
    category: p.primaryTypeDisplayName?.text ?? null,
    mapsUrl: p.googleMapsUri ?? null,
    lat: p.location?.latitude ?? null,
    lng: p.location?.longitude ?? null,
    thumbnail: null,
  };
}

export async function googleSearch(parsed: ParsedMapsInput, key: string): Promise<PlaceCandidate[]> {
  if (parsed.placeId) {
    const d = await googleRequest<GPlace>(
      `https://places.googleapis.com/v1/places/${encodeURIComponent(parsed.placeId)}?languageCode=es`,
      key,
      BASIC_MASK,
    );
    return [mapGoogleCandidate(d)];
  }
  const body: Record<string, unknown> = { textQuery: parsed.query, languageCode: "es", pageSize: 10 };
  if (parsed.lat !== null && parsed.lng !== null) {
    body.locationBias = { circle: { center: { latitude: parsed.lat, longitude: parsed.lng }, radius: 3000 } };
  }
  const data = await googleRequest<{ places?: GPlace[] }>(
    "https://places.googleapis.com/v1/places:searchText",
    key,
    SEARCH_MASK,
    body,
  );
  return (data.places ?? []).filter((p) => p.id).map(mapGoogleCandidate);
}

function googleReviewId(author: string | null, date: Date | null, text: string): string {
  const secs = date ? Math.floor(date.getTime() / 1000) : 0;
  return `g:${(author ?? "anon").slice(0, 60)}:${secs || text.slice(0, 40)}`;
}

export async function googleFetchPlace(placeId: string, key: string): Promise<FetchedPlace> {
  const d = await googleRequest<GPlace>(
    `https://places.googleapis.com/v1/places/${encodeURIComponent(placeId)}?languageCode=es`,
    key,
    DETAILS_MASK,
  );
  const reviews: FetchedReview[] = [];
  const seen = new Set<string>();
  for (const r of d.reviews ?? []) {
    const rating = clampRating(r.rating);
    if (!rating) continue;
    const author = r.authorAttribution?.displayName ?? null;
    const text = r.text?.text ?? r.originalText?.text ?? "";
    const date = toDate(r.publishTime);
    const id = googleReviewId(author, date, text);
    if (seen.has(id)) continue;
    seen.add(id);
    reviews.push({
      externalId: id,
      author,
      authorUrl: r.authorAttribution?.uri ?? null,
      rating,
      text,
      language: r.originalText?.languageCode ?? r.text?.languageCode ?? null,
      publishedAt: date,
      relativeTime: r.relativePublishTimeDescription ?? null,
      likes: null,
      ownerResponse: null,
    });
  }
  // Intento adicional con la API legada (orden "más recientes") para complementar la muestra.
  try {
    const legacy = await fetch(
      `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(placeId)}&fields=reviews&reviews_sort=newest&language=es&key=${encodeURIComponent(key)}`,
      { signal: AbortSignal.timeout(15000), cache: "no-store" },
    );
    const lj = (await legacy.json()) as { status?: string; result?: { reviews?: LegacyReview[] } };
    if (lj.status === "OK") {
      for (const r of lj.result?.reviews ?? []) {
        const rating = clampRating(r.rating);
        if (!rating) continue;
        const author = r.author_name ?? null;
        const date = r.time ? new Date(r.time * 1000) : null;
        const text = r.text ?? "";
        const id = googleReviewId(author, date, text);
        if (seen.has(id)) continue;
        seen.add(id);
        reviews.push({
          externalId: id,
          author,
          authorUrl: r.author_url ?? null,
          rating,
          text,
          language: r.language ?? null,
          publishedAt: date,
          relativeTime: r.relative_time_description ?? null,
          likes: null,
          ownerResponse: null,
        });
      }
    }
  } catch {
    // La API legada puede no estar habilitada; se ignora.
  }
  return {
    source: "google",
    externalId: placeId,
    name: d.displayName?.text ?? "Sin nombre",
    address: d.formattedAddress ?? null,
    category: d.primaryTypeDisplayName?.text ?? null,
    googleRating: d.rating ?? null,
    googleRatingCount: d.userRatingCount ?? null,
    mapsUrl: d.googleMapsUri ?? null,
    website: d.websiteUri ?? null,
    phone: d.nationalPhoneNumber ?? null,
    lat: d.location?.latitude ?? null,
    lng: d.location?.longitude ?? null,
    topics: null,
    reviews,
    notes: [
      `La API oficial de Google Places entrega como máximo 5 reseñas por consulta (se obtuvieron ${reviews.length}). Puedes actualizar periódicamente para acumular reseñas nuevas, usar SerpAPI para muestras grandes o importar un archivo.`,
    ],
  };
}

// ---------------------------------------------------------------------------
// SerpAPI (Google Maps + Google Maps Reviews)
// ---------------------------------------------------------------------------
interface SerpLocal {
  title?: string;
  place_id?: string;
  data_id?: string;
  address?: string;
  rating?: number;
  reviews?: number;
  type?: string;
  gps_coordinates?: { latitude?: number; longitude?: number };
  thumbnail?: string;
  website?: string;
  phone?: string;
}
interface SerpReview {
  review_id?: string;
  link?: string;
  rating?: number;
  date?: string;
  iso_date?: string;
  snippet?: string;
  extracted_snippet?: { original?: string; translated?: string };
  likes?: number;
  user?: { name?: string; link?: string };
  response?: { snippet?: string };
}
interface SerpReviewsResponse {
  error?: string;
  place_info?: { title?: string; address?: string; rating?: number; reviews?: number; type?: string };
  topics?: { keyword?: string; mentions?: number }[];
  reviews?: SerpReview[];
  serpapi_pagination?: { next_page_token?: string };
}

/** Traduce los errores más comunes de SerpAPI a mensajes claros en español. */
export function serpErrorMessage(raw: string): string {
  if (/invalid api key/i.test(raw)) {
    return "La clave de SerpAPI no es válida. Cópiala completa desde serpapi.com/manage-api-key (son 64 caracteres) y pégala de nuevo.";
  }
  if (/run out of searches|searches.*(exhausted|limit)|no searches left|plan.*limit/i.test(raw)) {
    return "Se agotaron las búsquedas disponibles de tu plan de SerpAPI. Revisa tu cuenta en serpapi.com o espera a la renovación mensual.";
  }
  if (/hourly/i.test(raw)) return "Se alcanzó el límite de búsquedas por hora de SerpAPI. Intenta de nuevo en unos minutos.";
  if (/verify|verification/i.test(raw)) return `SerpAPI indica que la cuenta requiere verificación: ${raw}`;
  return `SerpAPI respondió: ${raw}`;
}

async function serpRequest<T extends { error?: string }>(params: Record<string, string>, key: string): Promise<T> {
  const url = new URL("https://serpapi.com/search.json");
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  url.searchParams.set("api_key", key);
  let res: Response;
  try {
    res = await fetch(url, { signal: AbortSignal.timeout(60000), cache: "no-store" });
  } catch {
    throw new ProviderError("No se pudo conectar con SerpAPI (tiempo de espera agotado o falla de red). Intenta de nuevo.", 504);
  }
  const json = (await res.json().catch(() => ({}))) as T;
  if (!res.ok || json.error) {
    const raw = json.error ?? res.statusText;
    throw new ProviderError(serpErrorMessage(raw), res.status === 401 || /invalid api key/i.test(raw) ? 401 : 502);
  }
  return json;
}

export interface SerpAccountInfo {
  plan: string | null;
  searchesPerMonth: number | null;
  searchesLeft: number | null;
  thisMonthUsage: number | null;
}

function numOrNull(x: unknown): number | null {
  const n = Number(x);
  return x === null || x === undefined || !Number.isFinite(n) ? null : n;
}

/** Consulta la cuenta de SerpAPI (no consume búsquedas). Sirve para validar la clave y ver créditos. */
export async function serpAccount(key: string): Promise<SerpAccountInfo> {
  const url = new URL("https://serpapi.com/account.json");
  url.searchParams.set("api_key", key);
  let res: Response;
  try {
    res = await fetch(url, { signal: AbortSignal.timeout(20000), cache: "no-store" });
  } catch {
    throw new ProviderError("No se pudo conectar con SerpAPI para verificar la clave. Intenta de nuevo.", 504);
  }
  const j = (await res.json().catch(() => ({}))) as {
    error?: string;
    plan_name?: string;
    searches_per_month?: number;
    plan_searches_left?: number;
    total_searches_left?: number;
    this_month_usage?: number;
  };
  if (!res.ok || j.error) {
    const raw = j.error ?? res.statusText;
    throw new ProviderError(serpErrorMessage(raw), res.status === 401 || /invalid api key/i.test(raw) ? 401 : 502);
  }
  return {
    plan: j.plan_name ?? null,
    searchesPerMonth: numOrNull(j.searches_per_month),
    searchesLeft: numOrNull(j.total_searches_left ?? j.plan_searches_left),
    thisMonthUsage: numOrNull(j.this_month_usage),
  };
}

/** Valida una clave de Google con Place Details solo-ID (SKU «IDs Only», sin costo). */
export async function googleVerify(key: string): Promise<void> {
  let res: Response;
  try {
    res = await fetch("https://places.googleapis.com/v1/places/ChIJj61dQgK6j4AR4GeTYWZsKWw", {
      headers: { "X-Goog-Api-Key": key, "X-Goog-FieldMask": "id" },
      signal: AbortSignal.timeout(15000),
      cache: "no-store",
    });
  } catch {
    throw new ProviderError("No se pudo conectar con Google para verificar la clave. Intenta de nuevo.", 504);
  }
  if (res.ok || res.status === 404) return;
  const j = (await res.json().catch(() => ({}))) as { error?: { message?: string; status?: string } };
  throw new ProviderError(
    `Google respondió: ${j.error?.message ?? res.statusText}. Verifica que la clave sea correcta y que «Places API (New)» esté habilitada (con facturación activa) en Google Cloud.`,
    401,
  );
}

function cidUrl(dataId: string): string | null {
  try {
    const hex = dataId.split(":")[1];
    return `https://www.google.com/maps?cid=${BigInt(hex).toString()}`;
  } catch {
    return null;
  }
}

export async function serpSearch(parsed: ParsedMapsInput, key: string): Promise<PlaceCandidate[]> {
  if (parsed.dataId || parsed.placeId) {
    const id = (parsed.dataId ?? parsed.placeId) as string;
    return [
      {
        provider: "serpapi",
        externalId: id,
        name: parsed.name ?? "Lugar de Google Maps (desde enlace)",
        address: null,
        rating: null,
        ratingCount: null,
        category: null,
        mapsUrl: parsed.resolvedUrl,
        lat: parsed.lat,
        lng: parsed.lng,
        thumbnail: null,
      },
    ];
  }
  const params: Record<string, string> = { engine: "google_maps", type: "search", q: parsed.query, hl: "es", gl: "mx" };
  if (parsed.lat !== null && parsed.lng !== null) params.ll = `@${parsed.lat},${parsed.lng},15z`;
  let data: { error?: string; local_results?: SerpLocal[]; place_results?: SerpLocal };
  try {
    data = await serpRequest(params, key);
  } catch (e) {
    if (e instanceof ProviderError && /any results/i.test(e.message)) return [];
    throw e;
  }
  const items = data.local_results ?? (data.place_results ? [data.place_results] : []);
  return items
    .filter((i) => i.data_id || i.place_id)
    .map((i) => ({
      provider: "serpapi" as const,
      externalId: (i.data_id ?? i.place_id) as string,
      name: i.title ?? "Sin nombre",
      address: i.address ?? null,
      rating: i.rating ?? null,
      ratingCount: i.reviews ?? null,
      category: i.type ?? null,
      mapsUrl: i.place_id
        ? `https://www.google.com/maps/place/?q=place_id:${i.place_id}`
        : i.data_id
          ? cidUrl(i.data_id)
          : null,
      lat: i.gps_coordinates?.latitude ?? null,
      lng: i.gps_coordinates?.longitude ?? null,
      thumbnail: i.thumbnail ?? null,
    }));
}

export interface SerpChunk {
  meta: Omit<FetchedPlace, "reviews" | "notes">;
  hasPlaceInfo: boolean;
  reviews: FetchedReview[];
  nextPageToken: string | null;
  pages: number;
}

/**
 * Extrae reseñas de SerpAPI por bloques: como máximo `maxPages` páginas (≈1 crédito c/u) o
 * `timeBudgetMs` milisegundos por llamada. Devuelve `nextPageToken` para continuar desde el cliente.
 */
export async function serpFetchChunk(
  externalId: string,
  key: string,
  opts: { sort: string; maxReviews: number; pageToken?: string | null; maxPages?: number; timeBudgetMs?: number },
): Promise<SerpChunk> {
  const sortMap: Record<string, string> = {
    relevant: "qualityScore",
    newest: "newestFirst",
    highest: "ratingHigh",
    lowest: "ratingLow",
  };
  const base: Record<string, string> = { engine: "google_maps_reviews", hl: "es", sort_by: sortMap[opts.sort] ?? "qualityScore" };
  const isDataId = externalId.startsWith("0x");
  if (isDataId) base.data_id = externalId;
  else base.place_id = externalId;
  const max = Math.max(1, Math.min(opts.maxReviews, 1000));
  const maxPages = Math.max(1, Math.min(opts.maxPages ?? 3, 10));
  const budget = opts.timeBudgetMs ?? 20000;
  const started = Date.now();
  const reviews: FetchedReview[] = [];
  const seen = new Set<string>();
  let info: SerpReviewsResponse["place_info"];
  let topics: { keyword: string; mentions: number }[] | null = null;
  let token: string | undefined = opts.pageToken || undefined;
  let pages = 0;
  for (;;) {
    const params = { ...base };
    if (token) {
      params.next_page_token = token;
      params.num = "20";
    }
    let data: SerpReviewsResponse;
    try {
      data = await serpRequest<SerpReviewsResponse>(params, key);
    } catch (e) {
      const noResults = e instanceof ProviderError && /any results/i.test(e.message);
      if (noResults && token) {
        // Ya no hay más páginas de reseñas.
        token = undefined;
        break;
      }
      if (noResults) {
        throw new ProviderError("Google Maps no devolvió reseñas para este lugar (es posible que no tenga reseñas públicas).", 404);
      }
      throw e;
    }
    pages++;
    if (!info && data.place_info) info = data.place_info;
    if (!topics && data.topics?.length) {
      topics = data.topics
        .filter((t) => t.keyword)
        .map((t) => ({ keyword: t.keyword as string, mentions: Number(t.mentions ?? 0) }));
    }
    for (const r of data.reviews ?? []) {
      const rating = clampRating(r.rating);
      if (!rating) continue;
      const id = r.review_id ?? r.link ?? `${r.user?.name ?? "anon"}|${r.iso_date ?? ""}|${(r.snippet ?? "").slice(0, 30)}`;
      if (seen.has(id)) continue;
      seen.add(id);
      reviews.push({
        externalId: id,
        author: r.user?.name ?? null,
        authorUrl: r.user?.link ?? null,
        rating,
        text: r.extracted_snippet?.translated ?? r.snippet ?? r.extracted_snippet?.original ?? "",
        language: null,
        publishedAt: toDate(r.iso_date),
        relativeTime: r.date ?? null,
        likes: typeof r.likes === "number" ? r.likes : null,
        ownerResponse: r.response?.snippet ?? null,
      });
      if (reviews.length >= max) break;
    }
    token = data.serpapi_pagination?.next_page_token;
    if (!token || reviews.length >= max) break;
    if (pages >= maxPages || Date.now() - started > budget) break;
  }

  const done = !token || reviews.length >= max;
  return {
    meta: {
      source: "serpapi",
      externalId,
      name: info?.title ?? "Lugar de Google Maps",
      address: info?.address ?? null,
      category: info?.type ?? null,
      googleRating: info?.rating ?? null,
      googleRatingCount: info?.reviews ?? null,
      mapsUrl: isDataId ? cidUrl(externalId) : `https://www.google.com/maps/place/?q=place_id:${externalId}`,
      website: null,
      phone: null,
      lat: null,
      lng: null,
      topics,
    },
    hasPlaceInfo: Boolean(info?.title),
    reviews,
    nextPageToken: done ? null : (token ?? null),
    pages,
  };
}
