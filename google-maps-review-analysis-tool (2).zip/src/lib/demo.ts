import { mulberry32 } from "./analysis/cluster";
import type { FetchedPlace, FetchedReview } from "./providers";

type Bank = { pos: string[]; neg: string[] };
type Kind = "restaurante" | "mariscos" | "cafe" | "hotel";

const COMMON: Record<string, Bank> = {
  servicio: {
    pos: [
      "el personal fue muy amable y atento",
      "la atención del mesero fue excelente",
      "nos atendieron con mucha cordialidad",
      "el servicio es de primera",
      "el staff siempre está al pendiente de todo",
      "excelente trato por parte de todo el personal",
      "la recepcionista fue muy servicial",
      "el gerente nos atendió de manera muy profesional",
    ],
    neg: [
      "el servicio fue pésimo",
      "el mesero fue grosero y poco atento",
      "la atención deja mucho que desear",
      "el personal se veía molesto y desganado",
      "nadie nos atendía y tuvimos que llamar varias veces al mesero",
      "la recepcionista fue descortés",
      "mal servicio por parte de los meseros",
    ],
  },
  precio: {
    pos: [
      "los precios son muy accesibles",
      "excelente relación calidad-precio",
      "vale la pena por lo que pagas",
      "precio justo para la calidad que ofrecen",
      "muy económico para la zona",
    ],
    neg: [
      "los precios son demasiado caros",
      "está carísimo para lo que ofrecen",
      "nos cobraron de más en la cuenta",
      "la relación calidad-precio no es buena",
      "subieron mucho los precios, no vale la pena",
    ],
  },
  limpieza: {
    pos: [
      "el lugar está muy limpio",
      "los baños impecables",
      "todo muy limpio y ordenado",
      "se nota la higiene en la cocina",
      "las instalaciones siempre limpias",
    ],
    neg: [
      "los baños estaban sucios",
      "había muchas moscas, muy desagradable",
      "falta limpieza en el lugar",
      "las mesas estaban sucias y pegajosas",
      "olía mal cerca de los baños",
    ],
  },
  ambiente: {
    pos: [
      "el ambiente es muy agradable",
      "la vista a la laguna es espectacular",
      "la decoración es hermosa y acogedora",
      "la música en vivo está muy bien",
      "un ambiente tranquilo y cómodo",
      "la terraza es preciosa al atardecer",
    ],
    neg: [
      "había demasiado ruido",
      "hacía un calor insoportable y no hay aire acondicionado",
      "las sillas son muy incómodas",
      "la música estaba tan fuerte que era molesto platicar",
      "las instalaciones se ven descuidadas y viejas",
    ],
  },
  espera: {
    pos: [
      "nos sirvieron rapidísimo",
      "el servicio es rápido y eficiente",
      "no tuvimos que esperar nada",
      "la comida llegó en pocos minutos",
    ],
    neg: [
      "tardaron más de una hora en traer la comida",
      "esperamos demasiado tiempo para ordenar",
      "el servicio es muy lento",
      "la espera fue de 40 minutos",
      "tardaron mucho en traer la cuenta",
    ],
  },
  ubicacion: {
    pos: [
      "excelente ubicación en el centro",
      "fácil de llegar y con estacionamiento",
      "está muy bien ubicado frente a la bahía",
      "tiene estacionamiento amplio",
    ],
    neg: [
      "no hay estacionamiento",
      "es difícil de llegar",
      "la zona no se siente segura de noche",
      "las calles para llegar están en malas condiciones",
    ],
  },
  variedad: {
    pos: [
      "el menú tiene muy buena variedad",
      "tienen buenas opciones vegetarianas",
      "gran variedad de platillos y bebidas",
      "buena selección de cafés y postres",
    ],
    neg: [
      "el menú tiene muy poca variedad",
      "no tenían varios platillos del menú",
      "pocas opciones para vegetarianos",
      "se les acabó la mitad de la carta",
    ],
  },
  hospedaje: {
    pos: [
      "la habitación muy amplia y cómoda",
      "las camas son súper cómodas",
      "la alberca está increíble",
      "la habitación tenía una vista hermosa",
      "excelente hotel para descansar",
    ],
    neg: [
      "la habitación olía a humedad",
      "el aire acondicionado de la habitación no funcionaba",
      "las toallas estaban viejas y manchadas",
      "la cama era muy incómoda",
      "la regadera no tenía agua caliente",
    ],
  },
  experiencia: {
    pos: [
      "lo recomiendo ampliamente",
      "sin duda volveremos",
      "una experiencia increíble",
      "de mis lugares favoritos en Quintana Roo",
      "100% recomendable",
    ],
    neg: ["no lo recomiendo", "no regreso", "fue una experiencia decepcionante", "nunca más vuelvo"],
  },
  extras: {
    pos: [
      "aceptan tarjeta y el wifi funciona muy bien",
      "puedes reservar por WhatsApp fácilmente",
      "el wifi es rápido, ideal para trabajar",
      "tienen servicio a domicilio",
    ],
    neg: [
      "solo aceptan efectivo",
      "el wifi no funciona",
      "no respetaron nuestra reservación",
      "la terminal para pagar con tarjeta no servía",
    ],
  },
  familia: {
    pos: [
      "ideal para ir con niños",
      "es pet friendly y consienten a las mascotas",
      "tiene área de juegos para niños",
      "tiene rampa y es accesible para silla de ruedas",
    ],
    neg: ["no es un lugar para niños", "no permiten mascotas", "no tiene acceso para silla de ruedas"],
  },
};

const PRODUCT: Record<Kind, Bank> = {
  restaurante: {
    pos: [
      "la comida estaba deliciosa",
      "los platillos tienen un sabor increíble",
      "la cochinita pibil es la mejor que he probado",
      "los ingredientes son muy frescos y bien preparados",
      "las porciones son generosas y muy ricas",
      "los panuchos y salbutes estaban buenísimos",
      "excelente calidad en los ingredientes",
      "los postres son riquísimos",
    ],
    neg: [
      "la comida llegó fría e insípida",
      "los platillos estaban insípidos",
      "la calidad de la comida es mala últimamente",
      "las porciones son escasas para lo que cuestan",
      "la carne estaba dura y quemada",
      "la comida estaba demasiado salada",
    ],
  },
  mariscos: {
    pos: [
      "el ceviche estaba buenísimo",
      "los mariscos son muy frescos",
      "el aguachile es delicioso",
      "el pescado frito está riquísimo",
      "excelente sazón en los cocteles de camarón",
    ],
    neg: [
      "el pescado no estaba fresco",
      "el ceviche tenía un olor desagradable",
      "los camarones estaban crudos",
      "la comida estaba insípida",
      "los cocteles eran pura cebolla y poco camarón",
    ],
  },
  cafe: {
    pos: [
      "el café es delicioso",
      "los frappés son riquísimos",
      "el pan recién horneado está buenísimo",
      "el café de olla es el mejor de Bacalar",
      "los postres son caseros y muy ricos",
    ],
    neg: [
      "el café estaba frío y aguado",
      "los postres estaban secos, nada ricos",
      "el frappé sabía mal",
      "la comida es muy básica y cara",
    ],
  },
  hotel: {
    pos: [
      "el desayuno incluido es muy rico",
      "el desayuno buffet tiene buena calidad",
      "la comida del restaurante es deliciosa",
      "excelente desayuno con frutas frescas",
    ],
    neg: [
      "el desayuno fue muy básico y nada rico",
      "la comida del restaurante es mediocre",
      "el desayuno era malo y repetitivo",
    ],
  },
};

const OPENERS: Record<number, string[]> = {
  5: ["¡Excelente!", "Me encantó.", "Increíble lugar.", "Muy buena experiencia.", "Todo perfecto."],
  4: ["Muy bien en general.", "Buena experiencia.", "Me gustó.", "Bastante bien."],
  3: ["Regular.", "Está bien, sin más.", "Experiencia normal.", "Ni bueno ni malo."],
  2: ["No me gustó mucho.", "Mala experiencia.", "Esperaba más.", "Decepcionante."],
  1: ["Pésimo.", "Terrible experiencia.", "Muy decepcionante.", "Lo peor."],
};

const FIRST = [
  "María", "José", "Guadalupe", "Juan", "Fernanda", "Luis", "Ana", "Carlos", "Sofía", "Miguel", "Valeria", "Jorge",
  "Daniela", "Ricardo", "Ximena", "Alejandro", "Paola", "Roberto", "Mariana", "Eduardo", "Andrea", "Raúl", "Itzel",
  "Gabriel", "Camila", "Héctor", "Lucía", "Francisco", "Karla", "Manuel", "Diana", "Óscar", "Regina", "Emilio",
];
const LAST = [
  "Pech", "Canché", "Chan", "May", "Pool", "Hernández", "García", "Martínez", "López", "González", "Rodríguez",
  "Pérez", "Sánchez", "Ramírez", "Cruz", "Flores", "Gómez", "Díaz", "Uc", "Ek", "Tun", "Cauich", "Moreno", "Ruiz",
];

interface Profile {
  slug: string;
  name: string;
  address: string;
  category: string;
  kind: Kind;
  lat: number;
  lng: number;
  count: number;
  googleRatingCount: number;
  ratingWeights: number[];
  themeWeights: Record<string, number>;
  bias: Record<string, number>;
  responseRate: number;
  topics: { keyword: string; mentions: number }[];
}

const PROFILES: Profile[] = [
  {
    slug: "ceiba-maya",
    name: "Restaurante La Ceiba Maya (demo)",
    address: "Av. Héroes 120, Centro, 77000 Chetumal, Q. Roo",
    category: "Restaurante de comida yucateca",
    kind: "restaurante",
    lat: 18.5001,
    lng: -88.2961,
    count: 140,
    googleRatingCount: 1268,
    ratingWeights: [6, 6, 12, 30, 86],
    themeWeights: { producto: 1, servicio: 0.8, precio: 0.45, ambiente: 0.45, espera: 0.35, limpieza: 0.2, variedad: 0.3, ubicacion: 0.2, experiencia: 0.5, familia: 0.15, extras: 0.12 },
    bias: { producto: 0.6, servicio: 0.3, espera: -0.6, precio: -0.1 },
    responseRate: 0.35,
    topics: [
      { keyword: "cochinita pibil", mentions: 64 },
      { keyword: "servicio", mentions: 51 },
      { keyword: "panuchos", mentions: 23 },
      { keyword: "espera", mentions: 19 },
    ],
  },
  {
    slug: "mariscos-manati",
    name: "Mariscos El Manatí (demo)",
    address: "Blvd. Bahía 45, 77000 Chetumal, Q. Roo",
    category: "Restaurante de mariscos",
    kind: "mariscos",
    lat: 18.4953,
    lng: -88.2899,
    count: 120,
    googleRatingCount: 845,
    ratingWeights: [10, 9, 16, 32, 53],
    themeWeights: { producto: 1, precio: 0.6, servicio: 0.7, ambiente: 0.55, limpieza: 0.35, espera: 0.4, ubicacion: 0.35, variedad: 0.25, experiencia: 0.45, extras: 0.2, familia: 0.1 },
    bias: { ambiente: 0.6, producto: 0.3, limpieza: -0.5, precio: 0.3, servicio: -0.2, extras: -0.7 },
    responseRate: 0.1,
    topics: [
      { keyword: "ceviche", mentions: 41 },
      { keyword: "vista a la bahía", mentions: 33 },
      { keyword: "baños", mentions: 17 },
      { keyword: "efectivo", mentions: 12 },
    ],
  },
  {
    slug: "hotel-siete-colores",
    name: "Hotel Laguna Siete Colores (demo)",
    address: "Av. Costera 8, 77930 Bacalar, Q. Roo",
    category: "Hotel",
    kind: "hotel",
    lat: 18.6766,
    lng: -88.3923,
    count: 110,
    googleRatingCount: 932,
    ratingWeights: [5, 6, 12, 33, 54],
    themeWeights: { hospedaje: 1, ambiente: 0.8, servicio: 0.75, limpieza: 0.5, precio: 0.45, producto: 0.35, ubicacion: 0.35, experiencia: 0.5, extras: 0.3, familia: 0.2, espera: 0.15 },
    bias: { ambiente: 0.7, hospedaje: 0.1, extras: -0.6, precio: -0.3, limpieza: 0.1 },
    responseRate: 0.6,
    topics: [
      { keyword: "laguna", mentions: 72 },
      { keyword: "habitación", mentions: 55 },
      { keyword: "desayuno", mentions: 28 },
      { keyword: "wifi", mentions: 14 },
    ],
  },
  {
    slug: "cafe-coco",
    name: "Café Coco Bacalar (demo)",
    address: "Calle 22 #15, Centro, 77930 Bacalar, Q. Roo",
    category: "Cafetería",
    kind: "cafe",
    lat: 18.6781,
    lng: -88.3911,
    count: 90,
    googleRatingCount: 512,
    ratingWeights: [3, 4, 9, 26, 48],
    themeWeights: { producto: 1, ambiente: 0.7, servicio: 0.6, precio: 0.4, variedad: 0.4, espera: 0.3, extras: 0.35, limpieza: 0.2, experiencia: 0.4, familia: 0.15, ubicacion: 0.2 },
    bias: { ambiente: 0.5, extras: 0.5, familia: 0.6, espera: -0.3, precio: -0.2 },
    responseRate: 0.25,
    topics: [
      { keyword: "café de olla", mentions: 30 },
      { keyword: "frappé", mentions: 22 },
      { keyword: "wifi", mentions: 15 },
      { keyword: "pet friendly", mentions: 9 },
    ],
  },
];

function pickWeighted<T>(rand: () => number, items: T[], weights: number[]): T {
  const total = weights.reduce((a, b) => a + b, 0);
  let r = rand() * total;
  for (let i = 0; i < items.length; i++) {
    r -= weights[i];
    if (r <= 0) return items[i];
  }
  return items[items.length - 1];
}

function pick<T>(rand: () => number, items: T[]): T {
  return items[Math.floor(rand() * items.length)];
}

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function sampleThemes(rand: () => number, weights: Record<string, number>, k: number): string[] {
  const pool = Object.entries(weights);
  const chosen: string[] = [];
  while (chosen.length < k && pool.length) {
    const idx = pool.indexOf(pickWeighted(rand, pool, pool.map(([, w]) => w)));
    chosen.push(pool[idx][0]);
    pool.splice(idx, 1);
  }
  return chosen;
}

const POS_PROB = [0, 0.06, 0.18, 0.45, 0.78, 0.92];

function generate(p: Profile, pi: number, anchor: number): FetchedPlace {
  const rand = mulberry32(1000 + pi * 97);
  const reviews: FetchedReview[] = [];
  for (let i = 0; i < p.count; i++) {
    const rating = pickWeighted(rand, [1, 2, 3, 4, 5], p.ratingWeights);
    let text = "";
    if (rand() >= 0.08) {
      const themes = sampleThemes(rand, p.themeWeights, pickWeighted(rand, [1, 2, 3], [0.35, 0.45, 0.2]));
      const parts = themes.map((th) => {
        const prob = Math.min(0.98, Math.max(0.02, POS_PROB[rating] + (p.bias[th] ?? 0) * 0.25));
        const pos = rand() < prob;
        const bank = th === "producto" ? PRODUCT[p.kind] : COMMON[th];
        return { s: pick(rand, pos ? bank.pos : bank.neg), pos };
      });
      let body = "";
      parts.forEach((part, idx) => {
        if (idx === 0) {
          body = capitalize(part.s);
          return;
        }
        const contrast = parts[idx - 1].pos !== part.pos;
        const conn = contrast ? pick(rand, [", pero ", ". Sin embargo, ", ", aunque "]) : pick(rand, [" y ", ". Además, ", ", "]);
        body += conn + (conn === ". Además, " ? part.s : part.s);
      });
      const opener = rand() < 0.55 ? pick(rand, OPENERS[rating]) : "";
      text = [opener, `${body}.`].filter(Boolean).join(" ");
    }
    const daysAgo = Math.floor(Math.pow(rand(), 1.6) * 900);
    const date = new Date(anchor - daysAgo * 86400000 - Math.floor(rand() * 86400000));
    const first = pick(rand, FIRST);
    const author = `${first} ${pick(rand, LAST)}`;
    const respond = rand() < p.responseRate;
    reviews.push({
      externalId: `demo-${p.slug}-${i}`,
      author,
      authorUrl: null,
      rating,
      text,
      language: "es",
      publishedAt: date,
      relativeTime: null,
      likes: rand() < 0.3 ? 1 + Math.floor(rand() * 6) : 0,
      ownerResponse: respond
        ? rating >= 4
          ? `¡Muchas gracias por tu visita, ${first}! Te esperamos pronto.`
          : `Lamentamos tu experiencia, ${first}. Tomaremos en cuenta tus comentarios para mejorar.`
        : null,
    });
  }
  const avg = reviews.reduce((s, r) => s + r.rating, 0) / reviews.length;
  return {
    source: "demo",
    externalId: `demo-${p.slug}`,
    name: p.name,
    address: p.address,
    category: p.category,
    googleRating: Math.round((avg + 0.05) * 10) / 10,
    googleRatingCount: p.googleRatingCount,
    mapsUrl: null,
    website: null,
    phone: null,
    lat: p.lat,
    lng: p.lng,
    topics: p.topics,
    reviews,
    notes: [],
  };
}

export function buildDemoPlaces(): FetchedPlace[] {
  const anchor = Date.now();
  return PROFILES.map((p, i) => generate(p, i, anchor));
}
