import ExcelJS from "exceljs";
import { themeName } from "../analysis/analyze";
import { THEMES } from "../analysis/themes";
import type { AnalyzedReview, ComparisonResult, PlaceAnalysis } from "../analysis/types";
import { SOURCE_LABELS } from "../format";
import type { ChartImage } from "./word";

const GREEN = "FF0B6E4F";
const COURSE_NOTE =
  "La herramienta forma parte de la asignatura Investigación de mercado impartida por el Dr. Ángel Aarón Rosado Varela.";

interface Col {
  header: string;
  key: string;
  width?: number;
  numFmt?: string;
}

function styleHeader(ws: ExcelJS.Worksheet, rowNumber = 1) {
  const row = ws.getRow(rowNumber);
  row.height = 30;
  row.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: GREEN } };
    cell.alignment = { vertical: "middle", wrapText: true };
  });
}

function addTable(wb: ExcelJS.Workbook, name: string, cols: Col[], rows: Record<string, unknown>[]): ExcelJS.Worksheet {
  const ws = wb.addWorksheet(name.slice(0, 31), { views: [{ state: "frozen", ySplit: 1 }] });
  ws.columns = cols.map((c) => ({ header: c.header, key: c.key, width: c.width ?? 16, style: c.numFmt ? { numFmt: c.numFmt } : {} }));
  for (const r of rows) ws.addRow(r);
  styleHeader(ws);
  if (rows.length) ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: cols.length } };
  return ws;
}

function addKeyValue(wb: ExcelJS.Workbook, name: string, title: string, pairs: [string, unknown][]): ExcelJS.Worksheet {
  const ws = wb.addWorksheet(name.slice(0, 31));
  ws.columns = [
    { key: "k", width: 44 },
    { key: "v", width: 60 },
  ];
  const t = ws.addRow([title]);
  t.font = { bold: true, size: 14, color: { argb: GREEN } };
  ws.addRow([COURSE_NOTE]).font = { italic: true, color: { argb: "FF555555" } };
  ws.addRow([]);
  const h = ws.addRow(["Indicador", "Valor"]);
  h.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: GREEN } };
  });
  for (const [k, v] of pairs) ws.addRow([k, v ?? "—"]);
  return ws;
}

function addCharts(wb: ExcelJS.Workbook, charts: ChartImage[]) {
  if (!charts.length) return;
  const ws = wb.addWorksheet("Gráficas");
  ws.getColumn(1).width = 4;
  let row = 1;
  for (const c of charts) {
    const m = c.image.match(/^data:image\/png;base64,(.+)$/);
    if (!m) continue;
    const buf = Buffer.from(m[1], "base64");
    const w0 = buf.length > 24 ? buf.readUInt32BE(16) : 1200;
    const h0 = buf.length > 24 ? buf.readUInt32BE(20) : 600;
    const width = 720;
    const height = Math.round((width * h0) / w0);
    const title = ws.getCell(row, 2);
    title.value = c.title;
    title.font = { bold: true, size: 13, color: { argb: GREEN } };
    const id = wb.addImage({ base64: m[1], extension: "png" });
    ws.addImage(id, { tl: { col: 1, row }, ext: { width, height } });
    row += Math.ceil(height / 20) + 3;
  }
}

function themeDummies(r: AnalyzedReview): Record<string, number> {
  const o: Record<string, number> = {};
  for (const t of THEMES) o[`t_${t.id}`] = r.themes.includes(t.id) ? 1 : 0;
  return o;
}

const REVIEW_COLS: Col[] = [
  { header: "ID", key: "id", width: 8 },
  { header: "Fecha", key: "fecha", width: 12, numFmt: "yyyy-mm-dd" },
  { header: "Autor", key: "autor", width: 22 },
  { header: "Calificación", key: "rating", width: 12 },
  { header: "Sentimiento", key: "sentimiento", width: 12 },
  { header: "Puntaje sentimiento (-1 a 1)", key: "score", width: 14, numFmt: "0.000" },
  { header: "Puntaje léxico del texto", key: "textScore", width: 14, numFmt: "0.000" },
  { header: "Temas", key: "temas", width: 40 },
  { header: "Tema emergente (grupo)", key: "cluster", width: 12 },
  { header: "Palabras", key: "palabras", width: 10 },
  { header: "Me gusta", key: "likes", width: 10 },
  { header: "Respuesta del propietario", key: "respuesta", width: 40 },
  { header: "Texto de la reseña", key: "texto", width: 90 },
  ...THEMES.map((t) => ({ header: `Tema: ${t.short} (1/0)`, key: `t_${t.id}`, width: 12 })),
];

function reviewRow(r: AnalyzedReview, extra: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    ...extra,
    id: r.id,
    fecha: r.publishedAt ? new Date(r.publishedAt) : null,
    autor: r.author ?? "",
    rating: r.rating,
    sentimiento: r.sentiment,
    score: r.sentimentScore,
    textScore: r.textSentiment,
    temas: r.themes.map((t) => themeName(t)).join("; "),
    cluster: r.clusterId ?? "",
    palabras: r.wordCount,
    likes: r.likes ?? "",
    respuesta: r.ownerResponse ?? "",
    texto: r.text,
    ...themeDummies(r),
  };
}

function wrapTextColumn(ws: ExcelJS.Worksheet, key: string) {
  ws.getColumn(key).alignment = { wrapText: true, vertical: "top" };
}

function methodologySheet(wb: ExcelJS.Workbook) {
  const ws = wb.addWorksheet("Metodología");
  ws.getColumn(1).width = 130;
  const lines = [
    "Nota metodológica",
    COURSE_NOTE,
    "",
    "• Sentimiento por reseña = 0.6 × calificación normalizada ((calif − 3) / 2) + 0.4 × puntaje léxico del texto (−1 a 1). Positivo > 0.2; negativo < −0.2.",
    "• Temas: diccionario de 12 dimensiones de la experiencia del cliente; una reseña puede pertenecer a varios temas (columnas dicotómicas 1/0).",
    "• Sentimiento neto por tema = (menciones positivas − negativas) / menciones × 100.",
    "• Índice de satisfacción neta = % reseñas 4–5★ − % reseñas 1–2★.",
    "• Temas emergentes: TF-IDF + k-means esférico (similitud coseno).",
    "• Estadística descriptiva con fórmulas equivalentes a Excel (DESVEST.M, CUARTIL.INC, COEFICIENTE.ASIMETRIA, CURTOSIS).",
    "• Las columnas dicotómicas de la hoja «Reseñas» permiten construir tablas dinámicas, tablas cruzadas o importarlas a SPSS/R/JASP.",
  ];
  lines.forEach((l, i) => {
    const r = ws.addRow([l]);
    if (i === 0) r.font = { bold: true, size: 14, color: { argb: GREEN } };
    r.alignment = { wrapText: true };
  });
}

function toArrayBuffer(data: ArrayBuffer | Uint8Array): ArrayBuffer {
  const u8 = data instanceof Uint8Array ? data : new Uint8Array(data);
  const ab = new ArrayBuffer(u8.byteLength);
  new Uint8Array(ab).set(u8);
  return ab;
}

function placeSheets(wb: ExcelJS.Workbook, a: PlaceAnalysis) {
  const s = a.stats;
  const p = a.place;
  addKeyValue(wb, "Resumen", `Análisis de opiniones — ${p.name}`, [
    ["Establecimiento", p.name],
    ["Dirección", p.address],
    ["Categoría", p.category],
    ["Fuente", SOURCE_LABELS[p.source] ?? p.source],
    ["Calificación global en Google", p.googleRating],
    ["Total de opiniones en Google", p.googleRatingCount],
    ["Enlace de Google Maps", p.mapsUrl],
    ["Fecha del reporte", new Date().toLocaleString("es-MX")],
    ["Reseñas analizadas (n)", a.totals.reviews],
    ["Reseñas con texto", a.totals.withText],
    ["Reseñas con respuesta del propietario", a.totals.withOwnerResponse],
    ["Promedio de palabras por reseña", a.totals.avgWords],
    ["Primera reseña", a.totals.dateFrom],
    ["Última reseña", a.totals.dateTo],
    ["Media", s?.mean],
    ["Mediana", s?.median],
    ["Moda", s?.mode.join(", ")],
    ["Desviación estándar", s?.stdDev],
    ["Varianza", s?.variance],
    ["Mínimo", s?.min],
    ["Máximo", s?.max],
    ["Rango", s?.range],
    ["Q1", s?.q1],
    ["Q3", s?.q3],
    ["Rango intercuartílico", s?.iqr],
    ["Coeficiente de variación (%)", s?.cv],
    ["Asimetría", s?.skewness],
    ["Curtosis (exceso)", s?.kurtosis],
    ["Error estándar", s?.standardError],
    ["IC 95% inferior", s?.ci95[0]],
    ["IC 95% superior", s?.ci95[1]],
    ["% positivas", a.sentiment.positivePct],
    ["% neutrales", a.sentiment.neutralPct],
    ["% negativas", a.sentiment.negativePct],
    ["Sentimiento neto", a.sentiment.netSentiment],
    ["Índice de satisfacción neta", a.satisfactionIndex],
  ]);
  const ins = addTable(wb, "Hallazgos", [{ header: "Hallazgo", key: "h", width: 140 }], a.insights.map((h) => ({ h })));
  wrapTextColumn(ins, "h");
  addTable(
    wb,
    "Distribución",
    [
      { header: "Estrellas", key: "stars", width: 12 },
      { header: "Frecuencia", key: "count", width: 12 },
      { header: "Porcentaje", key: "percent", width: 12 },
      { header: "% acumulado", key: "cum", width: 14 },
    ],
    a.distribution.map((d) => ({ stars: d.stars, count: d.count, percent: d.percent, cum: d.cumulativePercent })),
  );
  addTable(
    wb,
    "Sentimiento",
    [
      { header: "Sentimiento", key: "s", width: 16 },
      { header: "Reseñas", key: "n", width: 12 },
      { header: "Porcentaje", key: "p", width: 12 },
    ],
    [
      { s: "Positivo", n: a.sentiment.positive, p: a.sentiment.positivePct },
      { s: "Neutral", n: a.sentiment.neutral, p: a.sentiment.neutralPct },
      { s: "Negativo", n: a.sentiment.negative, p: a.sentiment.negativePct },
    ],
  );
  addTable(
    wb,
    "Temas",
    [
      { header: "Tema", key: "name", width: 36 },
      { header: "Menciones", key: "mentions", width: 11 },
      { header: "% reseñas con texto", key: "pct", width: 12 },
      { header: "Calificación promedio", key: "avg", width: 12 },
      { header: "Positivas", key: "pos", width: 10 },
      { header: "Neutrales", key: "neu", width: 10 },
      { header: "Negativas", key: "neg", width: 10 },
      { header: "Sentimiento neto", key: "net", width: 12 },
      { header: "Puntaje medio sentimiento", key: "score", width: 12 },
      { header: "Palabras clave", key: "kw", width: 50 },
      { header: "Descripción", key: "desc", width: 70 },
    ],
    a.themes.map((t) => ({
      name: t.name,
      mentions: t.mentions,
      pct: t.percentOfReviews,
      avg: t.avgRating,
      pos: t.positive,
      neu: t.neutral,
      neg: t.negative,
      net: t.netSentiment,
      score: t.avgSentimentScore,
      kw: t.topKeywords.map((k) => `${k.term} (${k.count})`).join(", "),
      desc: t.description,
    })),
  );
  const ex = addTable(
    wb,
    "Ejemplos por tema",
    [
      { header: "Tema", key: "tema", width: 34 },
      { header: "Sentimiento", key: "s", width: 12 },
      { header: "Calificación", key: "r", width: 12 },
      { header: "Fragmento de reseña", key: "t", width: 110 },
    ],
    a.themes.flatMap((t) => t.examples.map((e) => ({ tema: t.name, s: e.sentiment, r: e.rating, t: e.text }))),
  );
  wrapTextColumn(ex, "t");
  const cl = addTable(
    wb,
    "Temas emergentes",
    [
      { header: "Grupo", key: "id", width: 8 },
      { header: "Etiqueta", key: "label", width: 36 },
      { header: "Términos representativos", key: "terms", width: 50 },
      { header: "Reseñas", key: "size", width: 10 },
      { header: "%", key: "pct", width: 9 },
      { header: "Calificación promedio", key: "avg", width: 12 },
      { header: "% positivas", key: "pos", width: 11 },
      { header: "% negativas", key: "neg", width: 11 },
      { header: "Tema predominante", key: "dom", width: 30 },
      { header: "Ejemplo", key: "ex", width: 90 },
    ],
    a.clusters.map((c) => ({
      id: c.id,
      label: c.label,
      terms: c.terms.join(", "),
      size: c.size,
      pct: c.percent,
      avg: c.avgRating,
      pos: c.positivePct,
      neg: c.negativePct,
      dom: themeName(c.dominantTheme),
      ex: c.examples[0]?.text ?? "",
    })),
  );
  wrapTextColumn(cl, "ex");
  addTable(
    wb,
    "Palabras",
    [
      { header: "Palabra", key: "w", width: 22 },
      { header: "Reseñas que la mencionan", key: "wc", width: 14 },
      { header: "Expresión (bigrama)", key: "b", width: 30 },
      { header: "Reseñas", key: "bc", width: 12 },
    ],
    Array.from({ length: Math.max(a.topWords.length, a.topBigrams.length) }, (_, i) => ({
      w: a.topWords[i]?.term ?? "",
      wc: a.topWords[i]?.count ?? "",
      b: a.topBigrams[i]?.term ?? "",
      bc: a.topBigrams[i]?.count ?? "",
    })),
  );
  addTable(
    wb,
    "Tendencia",
    [
      { header: `Periodo (${a.trendGranularity})`, key: "p", width: 14 },
      { header: "Reseñas", key: "n", width: 10 },
      { header: "Calificación promedio", key: "avg", width: 14 },
      { header: "% positivas", key: "pos", width: 12 },
    ],
    a.trend.map((t) => ({ p: t.period, n: t.count, avg: t.avgRating, pos: t.positivePct })),
  );
  if (p.topics?.length) {
    addTable(
      wb,
      "Temas de Google",
      [
        { header: "Palabra clave", key: "k", width: 30 },
        { header: "Menciones", key: "m", width: 12 },
      ],
      p.topics.map((t) => ({ k: t.keyword, m: t.mentions })),
    );
  }
  const rv = addTable(wb, "Reseñas", REVIEW_COLS, a.reviews.map((r) => reviewRow(r)));
  wrapTextColumn(rv, "texto");
}

export async function buildPlaceXlsx(a: PlaceAnalysis, charts: ChartImage[]): Promise<ArrayBuffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "Analizador de opiniones · Investigación de mercado (UQROO)";
  wb.created = new Date();
  placeSheets(wb, a);
  addCharts(wb, charts);
  methodologySheet(wb);
  const out = await wb.xlsx.writeBuffer();
  return toArrayBuffer(out as ArrayBuffer);
}

export async function buildCompareXlsx(c: ComparisonResult, charts: ChartImage[]): Promise<ArrayBuffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "Analizador de opiniones · Investigación de mercado (UQROO)";
  wb.created = new Date();
  addTable(
    wb,
    "Resumen comparativo",
    [
      { header: "Establecimiento", key: "name", width: 36 },
      { header: "Fuente", key: "source", width: 20 },
      { header: "Calificación Google", key: "g", width: 12 },
      { header: "Opiniones Google", key: "gc", width: 12 },
      { header: "n analizada", key: "n", width: 10 },
      { header: "Con texto", key: "wt", width: 10 },
      { header: "Media", key: "mean", width: 10 },
      { header: "Mediana", key: "median", width: 10 },
      { header: "Desv. estándar", key: "sd", width: 10 },
      { header: "% positivas", key: "pos", width: 10 },
      { header: "% neutrales", key: "neu", width: 10 },
      { header: "% negativas", key: "neg", width: 10 },
      { header: "Satisfacción neta", key: "nsi", width: 12 },
      { header: "Tema más mencionado", key: "top", width: 30 },
      { header: "Fortaleza", key: "str", width: 30 },
      { header: "Área de oportunidad", key: "weak", width: 30 },
    ],
    c.summary.map((s) => ({
      name: s.name,
      source: SOURCE_LABELS[s.source] ?? s.source,
      g: s.googleRating,
      gc: s.googleRatingCount,
      n: s.n,
      wt: s.withText,
      mean: s.mean,
      median: s.median,
      sd: s.stdDev,
      pos: s.positivePct,
      neu: s.neutralPct,
      neg: s.negativePct,
      nsi: s.satisfactionIndex,
      top: s.topTheme ?? "",
      str: s.strength ?? "",
      weak: s.weakness ?? "",
    })),
  );
  const tests: Record<string, unknown>[] = [];
  if (c.anova) tests.push({ test: "ANOVA de un factor", stat: c.anova.f, df: `${c.anova.dfBetween}, ${c.anova.dfWithin}`, p: c.anova.p, eff: `η² = ${c.anova.etaSquared}`, sig: c.anova.p < 0.05 ? "Sí" : "No" });
  if (c.kruskal) tests.push({ test: "Kruskal-Wallis", stat: c.kruskal.h, df: String(c.kruskal.df), p: c.kruskal.p, eff: `ε² = ${c.kruskal.epsilonSquared}`, sig: c.kruskal.p < 0.05 ? "Sí" : "No" });
  if (c.welch) tests.push({ test: "t de Welch", stat: c.welch.t, df: String(c.welch.df), p: c.welch.p, eff: `d = ${c.welch.cohenD}`, sig: c.welch.p < 0.05 ? "Sí" : "No" });
  if (c.chiSquare) tests.push({ test: "Chi-cuadrada (sentimiento × establecimiento)", stat: c.chiSquare.chi2, df: String(c.chiSquare.df), p: c.chiSquare.p, eff: `V de Cramér = ${c.chiSquare.cramersV}`, sig: c.chiSquare.p < 0.05 ? "Sí" : "No" });
  addTable(
    wb,
    "Pruebas estadísticas",
    [
      { header: "Prueba", key: "test", width: 40 },
      { header: "Estadístico", key: "stat", width: 14, numFmt: "0.000" },
      { header: "gl", key: "df", width: 12 },
      { header: "Valor p", key: "p", width: 12, numFmt: "0.0000" },
      { header: "Tamaño del efecto", key: "eff", width: 22 },
      { header: "Significativa (α = 0.05)", key: "sig", width: 14 },
    ],
    tests,
  );
  const ins = addTable(wb, "Hallazgos", [{ header: "Hallazgo", key: "h", width: 150 }], c.insights.map((h) => ({ h })));
  wrapTextColumn(ins, "h");
  addTable(
    wb,
    "Distribución",
    [
      { header: "Establecimiento", key: "name", width: 36 },
      ...[1, 2, 3, 4, 5].flatMap((s) => [
        { header: `${s}★ (n)`, key: `n${s}`, width: 9 },
        { header: `${s}★ (%)`, key: `p${s}`, width: 9 },
      ]),
    ],
    c.places.map((p) => {
      const o: Record<string, unknown> = { name: p.place.name };
      p.distribution.forEach((d) => {
        o[`n${d.stars}`] = d.count;
        o[`p${d.stars}`] = d.percent;
      });
      return o;
    }),
  );
  addTable(
    wb,
    "Sentimiento",
    [
      { header: "Establecimiento", key: "name", width: 36 },
      { header: "Positivas (n)", key: "pn", width: 12 },
      { header: "Neutrales (n)", key: "nn", width: 12 },
      { header: "Negativas (n)", key: "gn", width: 12 },
      { header: "% positivas", key: "pp", width: 12 },
      { header: "% neutrales", key: "np", width: 12 },
      { header: "% negativas", key: "gp", width: 12 },
      { header: "Sentimiento neto", key: "net", width: 12 },
    ],
    c.places.map((p) => ({
      name: p.place.name,
      pn: p.sentiment.positive,
      nn: p.sentiment.neutral,
      gn: p.sentiment.negative,
      pp: p.sentiment.positivePct,
      np: p.sentiment.neutralPct,
      gp: p.sentiment.negativePct,
      net: p.sentiment.netSentiment,
    })),
  );
  addTable(
    wb,
    "Temas (formato largo)",
    [
      { header: "Establecimiento", key: "place", width: 36 },
      { header: "Tema", key: "theme", width: 36 },
      { header: "Menciones", key: "m", width: 11 },
      { header: "% reseñas con texto", key: "p", width: 12 },
      { header: "Calificación promedio", key: "a", width: 12 },
      { header: "Sentimiento neto", key: "n", width: 12 },
    ],
    c.themeMatrix.flatMap((row) =>
      row.values.map((v, i) => ({ place: c.summary[i].name, theme: row.themeName, m: v.mentions, p: v.percent, a: v.avgRating, n: v.netSentiment })),
    ),
  );
  const matrixCols: Col[] = [{ header: "Tema", key: "theme", width: 36 }, ...c.summary.map((s, i) => ({ header: s.name, key: `p${i}`, width: 20 }))];
  addTable(
    wb,
    "Matriz % menciones",
    matrixCols,
    c.themeMatrix.map((r) => Object.fromEntries([["theme", r.themeName], ...r.values.map((v, i) => [`p${i}`, v.percent])])),
  );
  addTable(
    wb,
    "Matriz sentimiento neto",
    matrixCols,
    c.themeMatrix.map((r) => Object.fromEntries([["theme", r.themeName], ...r.values.map((v, i) => [`p${i}`, v.netSentiment])])),
  );
  const all = addTable(
    wb,
    "Reseñas (todas)",
    [{ header: "Establecimiento", key: "place", width: 30 }, ...REVIEW_COLS],
    c.places.flatMap((p) => p.reviews.map((r) => reviewRow(r, { place: p.place.name }))),
  );
  wrapTextColumn(all, "texto");
  addCharts(wb, charts);
  methodologySheet(wb);
  const out = await wb.xlsx.writeBuffer();
  return toArrayBuffer(out as ArrayBuffer);
}
