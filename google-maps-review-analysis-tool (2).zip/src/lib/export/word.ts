import fs from "node:fs/promises";
import path from "node:path";
import {
  AlignmentType,
  BorderStyle,
  Document,
  Footer,
  Header,
  HeadingLevel,
  ImageRun,
  Packer,
  PageBreak,
  PageNumber,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  WidthType,
} from "docx";
import { themeName } from "../analysis/analyze";
import { THEME_BY_ID } from "../analysis/themes";
import type { ComparisonResult, PlaceAnalysis } from "../analysis/types";
import { fmt, fmtDate, fmtInt, fmtP, pct, signed, SOURCE_LABELS } from "../format";

export interface ChartImage {
  key: string;
  title: string;
  image: string;
}

const GREEN = "0B6E4F";
const COURSE_NOTE =
  "La herramienta forma parte de la asignatura Investigación de mercado impartida por el Dr. Ángel Aarón Rosado Varela.";
const NONE = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };

/**
 * Carga un logotipo de public/logos. Primero desde el disco; si la función se ejecuta en un
 * hosting serverless donde la carpeta public/ no está disponible, lo descarga del propio sitio.
 */
async function loadLogo(file: string, origin?: string): Promise<Buffer | null> {
  try {
    return await fs.readFile(path.join(process.cwd(), "public", "logos", file));
  } catch {
    // se intenta por HTTP
  }
  if (!origin) return null;
  try {
    const res = await fetch(`${origin}/logos/${file}`, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    return Buffer.from(await res.arrayBuffer());
  } catch {
    return null;
  }
}

function imgSize(buf: Buffer): { width: number; height: number } {
  if (buf.length > 24 && buf.readUInt32BE(0) === 0x89504e47) {
    return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
  }
  return { width: 800, height: 400 };
}

function dataUrlToBuffer(dataUrl: string): Buffer | null {
  const m = dataUrl.match(/^data:image\/png;base64,(.+)$/);
  return m ? Buffer.from(m[1], "base64") : null;
}

function logoRun(buf: Buffer | null, height: number): ImageRun[] {
  if (!buf) return [];
  const { width, height: h } = imgSize(buf);
  return [new ImageRun({ type: "png", data: buf, transformation: { width: Math.round((width / h) * height), height } })];
}

function heading(text: string, level: 1 | 2 | 3 = 1): Paragraph {
  const lv = level === 1 ? HeadingLevel.HEADING_1 : level === 2 ? HeadingLevel.HEADING_2 : HeadingLevel.HEADING_3;
  return new Paragraph({ text, heading: lv, spacing: { before: level === 1 ? 320 : 220, after: 120 } });
}

function para(
  text: string,
  o: { bold?: boolean; italics?: boolean; size?: number; color?: string; center?: boolean; after?: number } = {},
): Paragraph {
  return new Paragraph({
    alignment: o.center ? AlignmentType.CENTER : AlignmentType.JUSTIFIED,
    spacing: { after: o.after ?? 120 },
    children: [new TextRun({ text, bold: o.bold, italics: o.italics, size: o.size, color: o.color })],
  });
}

function bullet(text: string): Paragraph {
  return new Paragraph({ text, bullet: { level: 0 }, spacing: { after: 80 }, alignment: AlignmentType.JUSTIFIED });
}

function cellPara(text: string, o: { bold?: boolean; color?: string; size?: number } = {}): Paragraph {
  return new Paragraph({ children: [new TextRun({ text, bold: o.bold, color: o.color, size: o.size ?? 17 })] });
}

function table(headers: string[], rows: (string | number)[][], widths?: number[]): Table {
  const w = (i: number) => (widths ? { size: widths[i], type: WidthType.PERCENTAGE } : undefined);
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({
        tableHeader: true,
        children: headers.map(
          (h, i) =>
            new TableCell({
              width: w(i),
              verticalAlign: VerticalAlign.CENTER,
              shading: { type: ShadingType.CLEAR, color: "auto", fill: GREEN },
              children: [cellPara(h, { bold: true, color: "FFFFFF" })],
            }),
        ),
      }),
      ...rows.map(
        (r, ri) =>
          new TableRow({
            children: r.map(
              (c, i) =>
                new TableCell({
                  width: w(i),
                  shading: ri % 2 ? { type: ShadingType.CLEAR, color: "auto", fill: "F1F7F4" } : undefined,
                  children: [cellPara(String(c))],
                }),
            ),
          }),
      ),
    ],
  });
}

class FigureCounter {
  n = 0;
  block(c: ChartImage | undefined, maxWidth = 600): Paragraph[] {
    if (!c) return [];
    const buf = dataUrlToBuffer(c.image);
    if (!buf) return [];
    const { width, height } = imgSize(buf);
    const w = Math.min(maxWidth, width);
    const h = Math.round((w * height) / width);
    this.n++;
    return [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 160 },
        children: [new ImageRun({ type: "png", data: buf, transformation: { width: w, height: h } })],
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 240 },
        children: [new TextRun({ text: `Figura ${this.n}. ${c.title}`, italics: true, size: 18, color: "555555" })],
      }),
    ];
  }
}

async function buildHeaderFooter(origin?: string) {
  const [uqroo, coco] = await Promise.all([loadLogo("uqroo-verde.png", origin), loadLogo("coco-cientifico.png", origin)]);
  const header = new Header({
    children: [
      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        borders: { top: NONE, bottom: NONE, left: NONE, right: NONE, insideHorizontal: NONE, insideVertical: NONE },
        rows: [
          new TableRow({
            children: [
              new TableCell({ width: { size: 15, type: WidthType.PERCENTAGE }, children: [new Paragraph({ children: logoRun(uqroo, 34) })] }),
              new TableCell({
                width: { size: 70, type: WidthType.PERCENTAGE },
                verticalAlign: VerticalAlign.CENTER,
                children: [
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [new TextRun({ text: "Investigación de mercado · Análisis de opiniones en Google Maps", size: 16, color: "555555" })],
                  }),
                ],
              }),
              new TableCell({
                width: { size: 15, type: WidthType.PERCENTAGE },
                children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: logoRun(coco, 34) })],
              }),
            ],
          }),
        ],
      }),
    ],
  });
  const footer = new Footer({
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({ text: "UQROO · Coco Científico · Dr. Ángel Aarón Rosado Varela — Página ", size: 16, color: "777777" }),
          new TextRun({ children: [PageNumber.CURRENT], size: 16, color: "777777" }),
          new TextRun({ text: " de ", size: 16, color: "777777" }),
          new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, color: "777777" }),
        ],
      }),
    ],
  });
  return { header, footer, uqroo, coco };
}

function cover(title: string, subtitle: string[], uqroo: Buffer | null, coco: Buffer | null, source: string): Paragraph[] {
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 400, after: 300 },
      children: [...logoRun(uqroo, 110), new TextRun({ text: "          " }), ...logoRun(coco, 110)],
    }),
    para("Universidad Autónoma del Estado de Quintana Roo", { center: true, bold: true, size: 24, color: GREEN }),
    para("Asignatura: Investigación de mercado", { center: true, size: 22 }),
    para("Docente: Dr. Ángel Aarón Rosado Varela", { center: true, size: 22, after: 400 }),
    para(title, { center: true, bold: true, size: 40, color: GREEN, after: 200 }),
    ...subtitle.map((s, i) => para(s, { center: true, size: i === 0 ? 28 : 22, bold: i === 0, after: 80 })),
    para(" ", { after: 300 }),
    para(`Fecha de generación: ${new Date().toLocaleString("es-MX", { dateStyle: "long", timeStyle: "short" })}`, { center: true, size: 20 }),
    para(`Fuente de datos: ${source}`, { center: true, size: 20, after: 400 }),
    para(COURSE_NOTE, { center: true, italics: true, size: 20, color: "444444" }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function methodology(): Paragraph[] {
  return [
    heading("Nota metodológica"),
    bullet("Fuente: reseñas públicas de Google Maps obtenidas mediante la API oficial de Google Places (máx. 5 reseñas por consulta), SerpAPI (paginación de reseñas), archivos importados o datos de demostración, según se indique."),
    bullet("Estadística descriptiva: media, mediana, moda, desviación estándar muestral (n − 1), cuartiles (interpolación lineal), coeficiente de variación, asimetría y curtosis (fórmulas equivalentes a Excel) e intervalo de confianza al 95% basado en la distribución t."),
    bullet("Sentimiento por reseña: combinación ponderada de la calificación (60%) y un análisis léxico del texto (40%) con diccionario español/inglés, manejo de negaciones («no», «nunca»), intensificadores («muy», «súper») y expresiones («vale la pena», «deja mucho que desear»)."),
    bullet("Temas: clasificación por diccionario de 12 dimensiones de la experiencia del cliente. Cada reseña puede pertenecer a varios temas; el sentimiento de cada tema se calcula sobre las cláusulas que lo mencionan (análisis por aspecto)."),
    bullet("Temas emergentes: agrupamiento no supervisado (TF-IDF + k-means con similitud coseno) que descubre grupos de opiniones con vocabulario similar."),
    bullet("Índice de satisfacción neta = % de reseñas con 4–5 estrellas − % con 1–2 estrellas. Sentimiento neto por tema = (positivas − negativas) / menciones × 100."),
    bullet("Comparación: ANOVA de un factor, prueba de Kruskal-Wallis (datos ordinales), t de Welch (dos grupos) y chi-cuadrada de independencia para el sentimiento. Nivel de significancia α = 0.05."),
    bullet("Limitaciones: las reseñas en línea no constituyen una muestra probabilística; existe sesgo de autoselección. El análisis léxico es automático y puede fallar con ironía o sarcasmo; se recomienda validar con lectura cualitativa."),
  ];
}

function descriptiveRows(a: PlaceAnalysis): (string | number)[][] {
  const s = a.stats;
  if (!s) return [["Sin datos", "—"]];
  return [
    ["Número de reseñas (n)", fmtInt(s.n)],
    ["Media", fmt(s.mean, 3)],
    ["Mediana", fmt(s.median, 2)],
    ["Moda", s.mode.join(", ")],
    ["Desviación estándar", fmt(s.stdDev, 3)],
    ["Varianza", fmt(s.variance, 3)],
    ["Mínimo", fmt(s.min, 0)],
    ["Máximo", fmt(s.max, 0)],
    ["Rango", fmt(s.range, 0)],
    ["Primer cuartil (Q1)", fmt(s.q1, 2)],
    ["Tercer cuartil (Q3)", fmt(s.q3, 2)],
    ["Rango intercuartílico", fmt(s.iqr, 2)],
    ["Coeficiente de variación", pct(s.cv, 2)],
    ["Asimetría", fmt(s.skewness, 3)],
    ["Curtosis (exceso)", fmt(s.kurtosis, 3)],
    ["Error estándar de la media", fmt(s.standardError, 3)],
    ["IC 95% de la media", `${fmt(s.ci95[0], 3)} – ${fmt(s.ci95[1], 3)}`],
    ["Índice de satisfacción neta", signed(a.satisfactionIndex)],
  ];
}

function placeSections(a: PlaceAnalysis, charts: Map<string, ChartImage>, fig: FigureCounter): (Paragraph | Table)[] {
  const out: (Paragraph | Table)[] = [];
  const p = a.place;
  out.push(heading("1. Ficha del establecimiento"));
  out.push(
    table(
      ["Campo", "Valor"],
      [
        ["Nombre", p.name],
        ["Dirección", p.address ?? "—"],
        ["Categoría", p.category ?? "—"],
        ["Fuente", SOURCE_LABELS[p.source] ?? p.source],
        ["Calificación global en Google", p.googleRating !== null ? `${fmt(p.googleRating, 1)} ★` : "—"],
        ["Total de opiniones en Google", fmtInt(p.googleRatingCount)],
        ["Reseñas analizadas", fmtInt(a.totals.reviews)],
        ["Reseñas con texto", fmtInt(a.totals.withText)],
        ["Promedio de palabras por reseña", fmt(a.totals.avgWords, 1)],
        ["Periodo de las reseñas", `${fmtDate(a.totals.dateFrom)} – ${fmtDate(a.totals.dateTo)}`],
        ["Enlace de Google Maps", p.mapsUrl ?? "—"],
      ],
      [35, 65],
    ),
  );
  out.push(heading("2. Hallazgos principales"));
  a.insights.forEach((t) => out.push(bullet(t)));

  out.push(heading("3. Estadística descriptiva de las calificaciones"));
  out.push(table(["Estadístico", "Valor"], descriptiveRows(a), [60, 40]));

  out.push(heading("4. Distribución de calificaciones"));
  out.push(
    table(
      ["Estrellas", "Frecuencia", "Porcentaje", "% acumulado"],
      a.distribution.map((d) => [`${d.stars} ★`, d.count, pct(d.percent), pct(d.cumulativePercent)]),
    ),
  );
  out.push(...fig.block(charts.get("distribucion")));

  out.push(heading("5. Análisis de sentimiento"));
  out.push(
    table(
      ["Sentimiento", "Reseñas", "Porcentaje"],
      [
        ["Positivo", a.sentiment.positive, pct(a.sentiment.positivePct)],
        ["Neutral", a.sentiment.neutral, pct(a.sentiment.neutralPct)],
        ["Negativo", a.sentiment.negative, pct(a.sentiment.negativePct)],
        ["Sentimiento neto (% pos − % neg)", "", signed(a.sentiment.netSentiment)],
      ],
    ),
  );
  out.push(...fig.block(charts.get("sentimiento")));

  const mentioned = a.themes.filter((t) => t.mentions > 0);
  out.push(heading("6. Temas identificados en las opiniones"));
  out.push(
    para(
      "Cada reseña se clasificó en uno o varios temas a partir de un diccionario de palabras clave. El porcentaje se calcula sobre las reseñas con texto.",
    ),
  );
  out.push(
    table(
      ["Tema", "Menciones", "% reseñas", "Calif. prom.", "Pos.", "Neu.", "Neg.", "Sent. neto"],
      mentioned.map((t) => [t.name, t.mentions, pct(t.percentOfReviews), fmt(t.avgRating), t.positive, t.neutral, t.negative, signed(t.netSentiment)]),
      [30, 10, 10, 10, 8, 8, 8, 16],
    ),
  );
  out.push(...fig.block(charts.get("temas-menciones")));
  out.push(...fig.block(charts.get("temas-sentimiento")));
  out.push(...fig.block(charts.get("temas-calificacion")));
  for (const t of mentioned.slice(0, 8)) {
    out.push(heading(`${t.name}`, 3));
    out.push(
      para(
        `${t.description} Menciones: ${t.mentions} (${pct(t.percentOfReviews)}); calificación promedio: ${fmt(t.avgRating)}; sentimiento neto: ${signed(t.netSentiment)}. Palabras clave: ${t.topKeywords.map((k) => k.term).join(", ") || "—"}.`,
      ),
    );
    for (const ex of t.examples) {
      out.push(
        new Paragraph({
          indent: { left: 400 },
          spacing: { after: 80 },
          children: [
            new TextRun({ text: `[${ex.rating}★ · ${ex.sentiment}] `, bold: true, size: 18, color: ex.sentiment === "negativo" ? "B91C1C" : ex.sentiment === "positivo" ? "15803D" : "555555" }),
            new TextRun({ text: `“${ex.text}”`, italics: true, size: 18 }),
          ],
        }),
      );
    }
  }

  out.push(heading("7. Temas emergentes (agrupamiento automático)"));
  if (a.clusters.length) {
    out.push(
      table(
        ["#", "Etiqueta", "Reseñas", "%", "Calif. prom.", "% pos.", "% neg.", "Tema predominante"],
        a.clusters.map((c) => [c.id, c.terms.slice(0, 5).join(", "), c.size, pct(c.percent), fmt(c.avgRating), pct(c.positivePct), pct(c.negativePct), themeName(c.dominantTheme)]),
        [5, 30, 9, 9, 10, 9, 9, 19],
      ),
    );
    out.push(...fig.block(charts.get("clusters")));
    for (const c of a.clusters) {
      out.push(para(`Grupo ${c.id} — ${c.label}`, { bold: true, after: 60 }));
      c.examples.slice(0, 2).forEach((ex) =>
        out.push(new Paragraph({ indent: { left: 400 }, spacing: { after: 60 }, children: [new TextRun({ text: `[${ex.rating}★] “${ex.text}”`, italics: true, size: 18 })] })),
      );
    }
  } else {
    out.push(para("No hay suficientes reseñas con texto (mínimo 12) para realizar el agrupamiento automático."));
  }

  out.push(heading("8. Palabras y expresiones más frecuentes"));
  out.push(
    table(
      ["Palabra", "Reseñas", "Expresión (bigrama)", "Reseñas"],
      Array.from({ length: Math.max(Math.min(a.topWords.length, 20), Math.min(a.topBigrams.length, 20)) }, (_, i) => [
        a.topWords[i]?.term ?? "",
        a.topWords[i]?.count ?? "",
        a.topBigrams[i]?.term ?? "",
        a.topBigrams[i]?.count ?? "",
      ]),
    ),
  );
  out.push(...fig.block(charts.get("palabras")));

  if (a.trend.length) {
    out.push(heading(`9. Evolución temporal (por ${a.trendGranularity})`));
    out.push(table(["Periodo", "Reseñas", "Calif. promedio", "% positivas"], a.trend.map((t) => [t.period, t.count, fmt(t.avgRating), pct(t.positivePct)])));
    out.push(...fig.block(charts.get("tendencia")));
  }
  if (p.topics?.length) {
    out.push(heading("10. Temas destacados por Google"));
    out.push(table(["Palabra clave", "Menciones"], p.topics.map((t) => [t.keyword, t.mentions])));
  }
  return out;
}

function reviewsAnnex(a: PlaceAnalysis, limit = 400): (Paragraph | Table)[] {
  const rows = a.reviews.slice(0, limit).map((r, i) => [
    i + 1,
    fmtDate(r.publishedAt),
    `${r.rating}★`,
    r.sentiment,
    r.themes.map((t) => THEME_BY_ID[t]?.short ?? t).join(", "),
    r.text || "(sin texto)",
  ]);
  return [
    heading("Anexo. Reseñas analizadas"),
    para(
      a.reviews.length > limit
        ? `Se muestran las primeras ${limit} de ${a.reviews.length} reseñas. Consulta el archivo de Excel para el listado completo.`
        : `Listado de las ${a.reviews.length} reseñas analizadas.`,
    ),
    table(["#", "Fecha", "Calif.", "Sentimiento", "Temas", "Texto"], rows, [5, 12, 7, 11, 17, 48]),
  ];
}

function makeDoc(children: (Paragraph | Table)[], header: Header, footer: Footer, title: string): Document {
  return new Document({
    creator: "Analizador de opiniones · Investigación de mercado (UQROO)",
    title,
    description: COURSE_NOTE,
    styles: {
      default: { document: { run: { font: "Calibri", size: 21 } } },
      paragraphStyles: [
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 30, bold: true, color: GREEN } },
        { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, color: GREEN } },
        { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 22, bold: true, color: "1F2937" } },
      ],
    },
    sections: [
      {
        properties: { page: { margin: { top: 1300, bottom: 1100, left: 1200, right: 1200 } } },
        headers: { default: header },
        footers: { default: footer },
        children,
      },
    ],
  });
}

export async function buildPlaceDocx(a: PlaceAnalysis, chartList: ChartImage[], origin?: string): Promise<Buffer> {
  const { header, footer, uqroo, coco } = await buildHeaderFooter(origin);
  const charts = new Map(chartList.map((c) => [c.key, c]));
  const fig = new FigureCounter();
  const children: (Paragraph | Table)[] = [
    ...cover(
      "Reporte de análisis de opiniones en Google Maps",
      [a.place.name, a.place.address ?? "", a.place.category ?? ""].filter(Boolean),
      uqroo,
      coco,
      SOURCE_LABELS[a.place.source] ?? a.place.source,
    ),
    ...placeSections(a, charts, fig),
    ...methodology(),
    new Paragraph({ children: [new PageBreak()] }),
    ...reviewsAnnex(a),
  ];
  return Packer.toBuffer(makeDoc(children, header, footer, `Análisis de opiniones — ${a.place.name}`));
}

export async function buildCompareDocx(c: ComparisonResult, chartList: ChartImage[], origin?: string): Promise<Buffer> {
  const { header, footer, uqroo, coco } = await buildHeaderFooter(origin);
  const charts = new Map(chartList.map((x) => [x.key, x]));
  const fig = new FigureCounter();
  const names = c.summary.map((s) => s.name);
  const out: (Paragraph | Table)[] = [
    ...cover(
      "Reporte comparativo de opiniones en Google Maps",
      [`Comparación de ${c.summary.length} establecimientos`, ...names],
      uqroo,
      coco,
      [...new Set(c.summary.map((s) => SOURCE_LABELS[s.source] ?? s.source))].join(", "),
    ),
  ];
  out.push(heading("1. Establecimientos comparados"));
  out.push(
    table(
      ["Establecimiento", "Fuente", "Google ★", "Opiniones Google", "n analizada", "Con texto"],
      c.summary.map((s) => [s.name, SOURCE_LABELS[s.source] ?? s.source, fmt(s.googleRating, 1), fmtInt(s.googleRatingCount), s.n, s.withText]),
      [34, 18, 10, 14, 12, 12],
    ),
  );
  out.push(heading("2. Hallazgos principales"));
  c.insights.forEach((t) => out.push(bullet(t)));

  out.push(heading("3. Indicadores comparativos"));
  out.push(
    table(
      ["Establecimiento", "Media", "Mediana", "DE", "% pos.", "% neg.", "Satisf. neta", "Fortaleza", "Área de oportunidad"],
      c.summary.map((s) => [s.name, fmt(s.mean), fmt(s.median, 1), fmt(s.stdDev), pct(s.positivePct), pct(s.negativePct), signed(s.satisfactionIndex), s.strength ?? "—", s.weakness ?? "—"]),
      [20, 8, 8, 7, 8, 8, 9, 16, 16],
    ),
  );
  out.push(...fig.block(charts.get("cmp-promedios")));

  out.push(heading("4. Pruebas estadísticas"));
  const testRows: (string | number)[][] = [];
  if (c.anova)
    testRows.push(["ANOVA de un factor", `F = ${fmt(c.anova.f, 3)}`, `${c.anova.dfBetween}, ${c.anova.dfWithin}`, fmtP(c.anova.p), `η² = ${fmt(c.anova.etaSquared, 3)}`, c.anova.p < 0.05 ? "Diferencia significativa" : "Sin diferencia significativa"]);
  if (c.kruskal)
    testRows.push(["Kruskal-Wallis", `H = ${fmt(c.kruskal.h, 3)}`, String(c.kruskal.df), fmtP(c.kruskal.p), `ε² = ${fmt(c.kruskal.epsilonSquared, 3)}`, c.kruskal.p < 0.05 ? "Diferencia significativa" : "Sin diferencia significativa"]);
  if (c.welch)
    testRows.push(["t de Welch (2 grupos)", `t = ${fmt(c.welch.t, 3)}`, fmt(c.welch.df, 1), fmtP(c.welch.p), `d = ${fmt(c.welch.cohenD, 2)}`, c.welch.p < 0.05 ? "Diferencia significativa" : "Sin diferencia significativa"]);
  if (c.chiSquare)
    testRows.push(["Chi-cuadrada (sentimiento)", `χ² = ${fmt(c.chiSquare.chi2, 3)}`, String(c.chiSquare.df), fmtP(c.chiSquare.p), `V = ${fmt(c.chiSquare.cramersV, 3)}`, c.chiSquare.p < 0.05 ? "Asociación significativa" : "Sin asociación significativa"]);
  out.push(testRows.length ? table(["Prueba", "Estadístico", "gl", "p", "Efecto", "Conclusión (α = 0.05)"], testRows) : para("No hay datos suficientes para las pruebas estadísticas."));

  out.push(heading("5. Distribución de calificaciones (%)"));
  out.push(
    table(
      ["Establecimiento", "1★", "2★", "3★", "4★", "5★"],
      c.places.map((p) => [p.place.name, ...p.distribution.map((d) => pct(d.percent))]),
    ),
  );
  out.push(...fig.block(charts.get("cmp-distribucion")));

  out.push(heading("6. Sentimiento por establecimiento"));
  out.push(
    table(
      ["Establecimiento", "Positivo", "Neutral", "Negativo", "Sentimiento neto"],
      c.places.map((p) => [p.place.name, pct(p.sentiment.positivePct), pct(p.sentiment.neutralPct), pct(p.sentiment.negativePct), signed(p.sentiment.netSentiment)]),
    ),
  );
  out.push(...fig.block(charts.get("cmp-sentimiento")));

  out.push(heading("7. Comparación por temas"));
  out.push(heading("7.1 Porcentaje de reseñas que mencionan cada tema", 2));
  out.push(table(["Tema", ...names], c.themeMatrix.map((r) => [r.themeName, ...r.values.map((v) => pct(v.percent))])));
  out.push(...fig.block(charts.get("cmp-radar")));
  out.push(heading("7.2 Sentimiento neto por tema", 2));
  out.push(table(["Tema", ...names], c.themeMatrix.map((r) => [r.themeName, ...r.values.map((v) => (v.netSentiment === null ? "—" : signed(v.netSentiment)))])));
  out.push(...fig.block(charts.get("cmp-neto")));
  out.push(heading("7.3 Calificación promedio de las reseñas que mencionan cada tema", 2));
  out.push(table(["Tema", ...names], c.themeMatrix.map((r) => [r.themeName, ...r.values.map((v) => fmt(v.avgRating))])));

  const used = new Set(["cmp-promedios", "cmp-distribucion", "cmp-sentimiento", "cmp-radar", "cmp-neto"]);
  const extra = chartList.filter((x) => !used.has(x.key));
  if (extra.length) {
    out.push(heading("8. Gráficas adicionales"));
    extra.forEach((x) => out.push(...fig.block(x)));
  }

  out.push(heading("9. Resumen por establecimiento"));
  for (const p of c.places) {
    out.push(heading(p.place.name, 2));
    p.insights.slice(0, 6).forEach((t) => out.push(bullet(t)));
  }
  out.push(...methodology());
  return Packer.toBuffer(makeDoc(out, header, footer, "Reporte comparativo de opiniones"));
}
