import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { places, reviews, type PlaceRow, type ReviewRow } from "@/db/schema";
import { desc, eq, getTableColumns, inArray, sql } from "drizzle-orm";
import { analyzePlace } from "./analysis/analyze";
import type { PlaceAnalysis, PlaceInfo, PlaceSummary, ReviewInput } from "./analysis/types";
import type { FetchedPlace, FetchedReview } from "./providers";

export function toPlaceInfo(p: PlaceRow): PlaceInfo {
  return {
    id: p.id,
    source: p.source,
    externalId: p.externalId,
    name: p.name,
    address: p.address,
    category: p.category,
    googleRating: p.googleRating,
    googleRatingCount: p.googleRatingCount,
    mapsUrl: p.mapsUrl,
    website: p.website,
    phone: p.phone,
    topics: p.topics ?? null,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}

export function toReviewInput(r: ReviewRow): ReviewInput {
  return {
    id: r.id,
    author: r.author,
    rating: r.rating,
    text: r.text,
    publishedAt: r.publishedAt ? r.publishedAt.toISOString() : null,
    relativeTime: r.relativeTime,
    likes: r.likes,
    ownerResponse: r.ownerResponse,
    language: r.language,
  };
}

export async function savePlace(f: FetchedPlace): Promise<{ id: number; inserted: number; total: number }> {
  await ensureSchema();
  const now = new Date();
  const [row] = await db
    .insert(places)
    .values({
      source: f.source,
      externalId: f.externalId,
      name: f.name,
      address: f.address,
      category: f.category,
      googleRating: f.googleRating,
      googleRatingCount: f.googleRatingCount,
      mapsUrl: f.mapsUrl,
      website: f.website,
      phone: f.phone,
      lat: f.lat,
      lng: f.lng,
      topics: f.topics,
      updatedAt: now,
    })
    .onConflictDoUpdate({
      target: [places.source, places.externalId],
      set: {
        name: f.name,
        address: f.address ?? undefined,
        category: f.category ?? undefined,
        googleRating: f.googleRating ?? undefined,
        googleRatingCount: f.googleRatingCount ?? undefined,
        mapsUrl: f.mapsUrl ?? undefined,
        website: f.website ?? undefined,
        phone: f.phone ?? undefined,
        lat: f.lat ?? undefined,
        lng: f.lng ?? undefined,
        topics: f.topics ?? undefined,
        updatedAt: now,
      },
    })
    .returning({ id: places.id });

  const inserted = await insertReviews(row.id, f.reviews);
  return { id: row.id, inserted, total: await countReviews(row.id) };
}

/** Inserta reseñas omitiendo duplicados (mismo lugar + mismo identificador externo). */
async function insertReviews(placeId: number, list: FetchedReview[]): Promise<number> {
  const unique = new Map<string, FetchedReview>();
  for (const r of list) if (!unique.has(r.externalId)) unique.set(r.externalId, r);
  const rows = [...unique.values()].map((r) => ({
    placeId,
    externalId: r.externalId,
    author: r.author,
    authorUrl: r.authorUrl,
    rating: r.rating,
    text: r.text ?? "",
    language: r.language ? r.language.slice(0, 16) : null,
    publishedAt: r.publishedAt,
    relativeTime: r.relativeTime,
    likes: r.likes,
    ownerResponse: r.ownerResponse,
  }));
  let inserted = 0;
  for (let i = 0; i < rows.length; i += 400) {
    const chunk = rows.slice(i, i + 400);
    const res = await db
      .insert(reviews)
      .values(chunk)
      .onConflictDoNothing({ target: [reviews.placeId, reviews.externalId] })
      .returning({ id: reviews.id });
    inserted += res.length;
  }
  return inserted;
}

async function countReviews(placeId: number): Promise<number> {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(reviews)
    .where(eq(reviews.placeId, placeId));
  return Number(count);
}

/** Agrega reseñas a un lugar existente sin modificar sus datos generales (para extracción por bloques). */
export async function appendReviews(placeId: number, list: FetchedReview[]): Promise<{ id: number; inserted: number; total: number }> {
  await ensureSchema();
  const inserted = await insertReviews(placeId, list);
  await db.update(places).set({ updatedAt: new Date() }).where(eq(places.id, placeId));
  return { id: placeId, inserted, total: await countReviews(placeId) };
}

export async function listPlaces(): Promise<PlaceSummary[]> {
  await ensureSchema();
  const rows = await db
    .select({
      ...getTableColumns(places),
      reviewCount: sql<number>`count(${reviews.id})::int`,
      avgRating: sql<number | null>`avg(${reviews.rating})::float8`,
    })
    .from(places)
    .leftJoin(reviews, eq(reviews.placeId, places.id))
    .groupBy(places.id)
    .orderBy(desc(places.updatedAt));
  return rows.map((r) => ({
    ...toPlaceInfo(r),
    reviewCount: Number(r.reviewCount),
    avgRating: r.avgRating === null ? null : Math.round(Number(r.avgRating) * 100) / 100,
  }));
}

export async function analyzeMany(ids: number[]): Promise<PlaceAnalysis[]> {
  if (!ids.length) return [];
  await ensureSchema();
  const placeRows = await db.select().from(places).where(inArray(places.id, ids));
  const reviewRows = await db.select().from(reviews).where(inArray(reviews.placeId, ids));
  const byPlace = new Map<number, ReviewInput[]>();
  for (const r of reviewRows) {
    if (!byPlace.has(r.placeId)) byPlace.set(r.placeId, []);
    byPlace.get(r.placeId)?.push(toReviewInput(r));
  }
  const out: PlaceAnalysis[] = [];
  for (const id of ids) {
    const p = placeRows.find((x) => x.id === id);
    if (!p) continue;
    out.push(analyzePlace(toPlaceInfo(p), byPlace.get(id) ?? []));
  }
  return out;
}

export async function analyzeById(id: number): Promise<PlaceAnalysis | null> {
  const [a] = await analyzeMany([id]);
  return a ?? null;
}

export async function getPlaceRow(id: number): Promise<PlaceRow | null> {
  await ensureSchema();
  const [p] = await db.select().from(places).where(eq(places.id, id));
  return p ?? null;
}

export async function deletePlace(id: number): Promise<boolean> {
  await ensureSchema();
  const res = await db.delete(places).where(eq(places.id, id)).returning({ id: places.id });
  return res.length > 0;
}

export async function renamePlace(id: number, name: string): Promise<void> {
  await ensureSchema();
  await db.update(places).set({ name, updatedAt: new Date() }).where(eq(places.id, id));
}
