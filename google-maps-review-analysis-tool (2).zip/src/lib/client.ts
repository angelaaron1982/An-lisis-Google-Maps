export interface ApiKeys {
  google: string;
  serpapi: string;
}

const KEY_STORAGE = "analizador-resenas-claves";

export function loadKeys(): ApiKeys {
  if (typeof window === "undefined") return { google: "", serpapi: "" };
  if (memoryKeys) return memoryKeys;
  try {
    const raw = window.localStorage.getItem(KEY_STORAGE);
    if (raw) {
      const k = JSON.parse(raw) as Partial<ApiKeys>;
      return { google: k.google ?? "", serpapi: k.serpapi ?? "" };
    }
  } catch {
    // ignorar
  }
  return { google: "", serpapi: "" };
}

export function saveKeys(k: ApiKeys) {
  try {
    window.localStorage.setItem(KEY_STORAGE, JSON.stringify(k));
  } catch {
    // Almacenamiento no disponible (modo privado estricto); las claves vivirán solo en memoria.
  }
  memoryKeys = k;
}

/** Copia en memoria por si el navegador bloquea localStorage. */
let memoryKeys: ApiKeys | null = null;

/** Formatos típicos: Google empieza con «AIza»; SerpAPI son 64 caracteres hexadecimales. */
export const GOOGLE_KEY_RE = /^AIza[0-9A-Za-z_-]{30,}$/;
export const SERPAPI_KEY_RE = /^[a-f0-9]{64}$/i;

/** Quita espacios, saltos de línea y comillas que se cuelan al copiar y pegar. */
export function cleanKey(v: string): string {
  return v.replace(/\s+/g, "").replace(/^["'`]+|["'`]+$/g, "");
}

export interface ExtractProgress {
  collected: number;
  target: number;
  pages: number;
}

export interface ExtractParams {
  provider?: "google" | "serpapi";
  externalId?: string;
  placeId?: number;
  maxReviews: number;
  sort: string;
  fallback?: Record<string, unknown>;
}

export interface ExtractResult {
  id: number;
  name: string;
  inserted: number;
  total: number;
  collected: number;
  pages: number;
  notes: string[];
  error: string | null;
}

interface ExtractResponse {
  id: number;
  name: string;
  inserted: number;
  total: number;
  collected: number;
  pages: number;
  nextPageToken: string | null;
  notes?: string[];
}

/**
 * Extrae reseñas por bloques (cada llamada al servidor trae unas pocas páginas) y
 * reporta el avance. Si un bloque intermedio falla, conserva lo ya guardado.
 */
export async function extractReviews(params: ExtractParams, onProgress?: (p: ExtractProgress) => void): Promise<ExtractResult> {
  const result: ExtractResult = { id: params.placeId ?? 0, name: "", inserted: 0, total: 0, collected: 0, pages: 0, notes: [], error: null };
  let pageToken: string | null = null;
  for (let step = 0; step < 120; step++) {
    let r: ExtractResponse;
    try {
      r = await api<ExtractResponse>("/api/places", {
        json:
          step === 0
            ? {
                provider: params.provider,
                externalId: params.externalId,
                placeId: params.placeId,
                maxReviews: params.maxReviews,
                sort: params.sort,
                fallback: params.fallback,
              }
            : { placeId: result.id, pageToken, collected: result.collected, maxReviews: params.maxReviews, sort: params.sort },
      });
    } catch (e) {
      if (step === 0) throw e;
      result.error = e instanceof Error ? e.message : "Error al continuar la extracción.";
      break;
    }
    result.id = r.id;
    result.name = r.name;
    result.inserted += r.inserted;
    result.total = r.total;
    result.collected = r.collected;
    result.pages += r.pages;
    if (r.notes?.length) result.notes.push(...r.notes);
    onProgress?.({ collected: r.collected, target: params.maxReviews, pages: result.pages });
    if (!r.nextPageToken) break;
    pageToken = r.nextPageToken;
  }
  return result;
}

/** Estimación de créditos de SerpAPI: la 1.ª página trae ~8 reseñas y las siguientes 20. */
export function estimateSerpCredits(n: number): number {
  return 1 + Math.ceil(Math.max(0, n - 8) / 20);
}

function keyHeaders(): Record<string, string> {
  const k = loadKeys();
  const h: Record<string, string> = {};
  if (k.google) h["x-google-maps-key"] = k.google;
  if (k.serpapi) h["x-serpapi-key"] = k.serpapi;
  return h;
}

export async function api<T>(url: string, opts: { method?: string; json?: unknown; form?: FormData } = {}): Promise<T> {
  const headers: Record<string, string> = keyHeaders();
  let body: BodyInit | undefined;
  if (opts.json !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.json);
  } else if (opts.form) {
    body = opts.form;
  }
  const res = await fetch(url, { method: opts.method ?? (body ? "POST" : "GET"), headers, body, cache: "no-store" });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error ?? `Error ${res.status}`);
  return data;
}

export interface CapturedChart {
  key: string;
  title: string;
  image: string;
}

/** Convierte cada gráfica marcada con data-export-key en una imagen PNG. */
export async function captureCharts(root: HTMLElement | null): Promise<CapturedChart[]> {
  if (!root) return [];
  const { toPng } = await import("html-to-image");
  const nodes = Array.from(root.querySelectorAll<HTMLElement>("[data-export-key]"));
  const out: CapturedChart[] = [];
  for (const node of nodes) {
    if (!node.offsetWidth || !node.offsetHeight) continue;
    try {
      const image = await toPng(node, { backgroundColor: "#ffffff", pixelRatio: 2, cacheBust: true, skipFonts: true });
      out.push({ key: node.dataset.exportKey ?? "", title: node.dataset.exportTitle ?? "Gráfica", image });
    } catch (e) {
      console.warn("No se pudo capturar la gráfica", e);
    }
  }
  return out;
}

export async function downloadReport(payload: {
  format: "docx" | "xlsx";
  scope: "place" | "compare";
  ids: number[];
  charts: CapturedChart[];
}): Promise<void> {
  const res = await fetch("/api/export", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const d = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(d.error ?? "No se pudo generar el archivo.");
  }
  const blob = await res.blob();
  const cd = res.headers.get("Content-Disposition") ?? "";
  const m = cd.match(/filename\*=UTF-8''([^;]+)/);
  const m2 = cd.match(/filename="([^"]+)"/);
  const filename = m ? decodeURIComponent(m[1]) : m2 ? m2[1] : `reporte.${payload.format}`;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

export type Notify = (message: string, kind?: "success" | "error" | "info") => void;
