import { ProviderError } from "./providers";

export function errorResponse(e: unknown, fallback = "Ocurrió un error inesperado."): Response {
  if (e instanceof ProviderError) return Response.json({ error: e.message }, { status: e.status });
  console.error(e);
  const msg = e instanceof Error && e.message ? e.message : fallback;
  return Response.json({ error: msg }, { status: 500 });
}

export function parseId(s: string | undefined): number | null {
  const n = Number(s);
  return Number.isInteger(n) && n > 0 ? n : null;
}

export function toArrayBuffer(u8: Uint8Array): ArrayBuffer {
  const ab = new ArrayBuffer(u8.byteLength);
  new Uint8Array(ab).set(u8);
  return ab;
}

export function fileResponse(data: ArrayBuffer, filename: string, mime: string): Response {
  const ascii = filename
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\w.-]+/g, "_");
  return new Response(data, {
    headers: {
      "Content-Type": mime,
      "Content-Disposition": `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(filename)}`,
      "Cache-Control": "no-store",
    },
  });
}
