export function fmt(x: number | null | undefined, d = 2): string {
  if (x === null || x === undefined || !Number.isFinite(x)) return "—";
  return x.toLocaleString("es-MX", { minimumFractionDigits: d, maximumFractionDigits: d });
}

export function fmtInt(x: number | null | undefined): string {
  if (x === null || x === undefined || !Number.isFinite(x)) return "—";
  return Math.round(x).toLocaleString("es-MX");
}

export function pct(x: number | null | undefined, d = 1): string {
  if (x === null || x === undefined || !Number.isFinite(x)) return "—";
  return `${fmt(x, d)}%`;
}

export function signed(x: number | null | undefined, d = 1): string {
  if (x === null || x === undefined || !Number.isFinite(x)) return "—";
  return `${x > 0 ? "+" : ""}${fmt(x, d)}`;
}

export function fmtP(p: number | null | undefined): string {
  if (p === null || p === undefined || !Number.isFinite(p)) return "—";
  if (p < 0.001) return "< 0.001";
  return p.toFixed(3);
}

export function fmtDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("es-MX", { year: "numeric", month: "short", day: "numeric" });
}

export const SOURCE_LABELS: Record<string, string> = {
  google: "Google Places API",
  serpapi: "SerpAPI (Google Maps)",
  demo: "Demostración",
  import: "Archivo importado",
};

export const SENTIMENT_COLORS = { positivo: "#16a34a", neutral: "#94a3b8", negativo: "#dc2626" } as const;
export const STAR_COLORS = ["#ef4444", "#f97316", "#eab308", "#84cc16", "#16a34a"];
export const PLACE_COLORS = ["#0b6e4f", "#f59e0b", "#3b82f6", "#ec4899", "#8b5cf6", "#14b8a6", "#ef4444", "#64748b"];
