import ExcelJS from "exceljs";
import { normalize } from "./analysis/text";
import type { FetchedReview } from "./providers";

const ALIASES: Record<"rating" | "text" | "author" | "date" | "response", string[]> = {
  rating: ["calificacion", "rating", "estrellas", "stars", "puntuacion", "puntaje", "score", "valoracion", "calif", "nota", "review_rating", "estrella", "rate"],
  text: ["texto", "text", "resena", "review", "opinion", "comentario", "comentarios", "comment", "comments", "review_text", "snippet", "contenido", "descripcion", "opiniones", "resenas"],
  author: ["autor", "author", "nombre", "name", "usuario", "user", "reviewer", "author_name", "cliente"],
  date: ["fecha", "date", "publicado", "published", "time", "iso_date", "review_datetime_utc", "fecha_publicacion", "publishedattime", "datetime"],
  response: ["respuesta", "response", "owner_response", "respuesta_del_propietario", "owner_answer", "respuesta_propietario"],
};

function countOutsideQuotes(line: string, d: string): number {
  let inQ = false;
  let c = 0;
  for (const ch of line) {
    if (ch === '"') inQ = !inQ;
    else if (!inQ && ch === d) c++;
  }
  return c;
}

export function detectDelimiter(text: string): string {
  const first = text.split(/\r?\n/).find((l) => l.trim()) ?? "";
  let best = ",";
  let bestCount = 0;
  for (const d of ["\t", "|", ";", ","]) {
    const c = countOutsideQuotes(first, d);
    if (c > bestCount) {
      best = d;
      bestCount = c;
    }
  }
  return best;
}

export function parseDelimited(text: string, delimiter = detectDelimiter(text)): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQ = false;
  const src = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inQ) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          field += '"';
          i++;
        } else inQ = false;
      } else field += ch;
      continue;
    }
    if (ch === '"' && field.trim() === "") {
      inQ = true;
      field = "";
    } else if (ch === delimiter) {
      row.push(field);
      field = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && src[i + 1] === "\n") i++;
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  if (field !== "" || row.length) {
    row.push(field);
    rows.push(row);
  }
  return rows.map((r) => r.map((c) => c.trim())).filter((r) => r.some((c) => c !== ""));
}

function cellToString(v: ExcelJS.CellValue): string {
  if (v === null || v === undefined) return "";
  if (v instanceof Date) return v.toISOString();
  if (typeof v === "object") {
    if ("richText" in v && Array.isArray(v.richText)) return v.richText.map((r) => r.text).join("");
    if ("text" in v && typeof v.text === "string") return v.text;
    if ("result" in v) return cellToString(v.result as ExcelJS.CellValue);
    return "";
  }
  return String(v);
}

export async function parseWorkbook(buf: ArrayBuffer): Promise<string[][]> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buf);
  const ws = wb.worksheets[0];
  if (!ws) return [];
  const rows: string[][] = [];
  ws.eachRow({ includeEmpty: false }, (row) => {
    const vals = Array.isArray(row.values) ? row.values.slice(1) : [];
    rows.push(vals.map((v) => cellToString(v as ExcelJS.CellValue).trim()));
  });
  return rows.filter((r) => r.some((c) => c !== ""));
}

export function parseRating(s: string): number | null {
  if (!s) return null;
  const stars = (s.match(/★/g) ?? []).length;
  if (stars) return Math.min(5, stars);
  const m = s.replace(",", ".").match(/\d+(?:\.\d+)?/);
  if (!m) return null;
  let v = parseFloat(m[0]);
  if (/\/\s*10\b/.test(s) || (v > 5 && v <= 10)) v = v / 2;
  if (!Number.isFinite(v) || v <= 0 || v > 5) return null;
  return Math.min(5, Math.max(1, Math.round(v)));
}

export function parseDateCell(s: string): Date | null {
  if (!s) return null;
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
    const d = new Date(s);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const m = s.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})/);
  if (m) {
    let day = Number(m[1]);
    let month = Number(m[2]);
    const year = Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]);
    if (month > 12 && day <= 12) [day, month] = [month, day];
    const d = new Date(Date.UTC(year, month - 1, day, 12));
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const num = Number(s);
  if (Number.isFinite(num) && num > 20000 && num < 80000) return new Date(Math.round((num - 25569) * 86400000));
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
}

export interface ImportResult {
  reviews: FetchedReview[];
  skipped: number;
  headerDetected: boolean;
  mapping: Record<string, string | null>;
}

export function rowsToReviews(rows: string[][], prefix: string): ImportResult {
  if (!rows.length) return { reviews: [], skipped: 0, headerDetected: false, mapping: {} };
  const header = rows[0].map((h) => normalize(h).replace(/\s+/g, "_"));
  const cols: Record<string, number> = {};
  for (const key of Object.keys(ALIASES) as (keyof typeof ALIASES)[]) {
    let idx = header.findIndex((h, i) => ALIASES[key].includes(h) && !Object.values(cols).includes(i));
    if (idx < 0) {
      idx = header.findIndex(
        (h, i) =>
          !/(^|_)(id|link|url|uri)($|_)/.test(h) &&
          ALIASES[key].some((a) => a.length > 3 && h.includes(a)) &&
          !Object.values(cols).includes(i),
      );
    }
    if (idx >= 0) cols[key] = idx;
  }
  let headerDetected = cols.rating !== undefined || cols.text !== undefined;
  let data = headerDetected ? rows.slice(1) : rows;
  if (!headerDetected) {
    // Sin encabezados: [calificación, texto] o [autor, calificación, texto]
    const sample = rows[0];
    if (parseRating(sample[0]) !== null && !/[a-z]{4,}/i.test(sample[0].replace(/estrellas?|stars?/gi, ""))) {
      cols.rating = 0;
      cols.text = 1;
    } else if (sample.length >= 3 && parseRating(sample[1]) !== null) {
      cols.author = 0;
      cols.rating = 1;
      cols.text = 2;
    }
    data = rows;
  }
  if (cols.rating === undefined) {
    throw new Error(
      `No se encontró una columna de calificación. Encabezados detectados: ${rows[0].join(", ") || "(ninguno)"}. Usa columnas como «calificacion», «texto», «autor», «fecha».`,
    );
  }
  if (headerDetected && cols.text === undefined && cols.rating !== undefined) headerDetected = true;

  const reviews: FetchedReview[] = [];
  let skipped = 0;
  data.forEach((r, i) => {
    const rating = parseRating(r[cols.rating] ?? "");
    if (rating === null) {
      skipped++;
      return;
    }
    let text = cols.text !== undefined ? (r[cols.text] ?? "") : "";
    if (!headerDetected && cols.text !== undefined && r.length > cols.text + 1) {
      text = r.slice(cols.text).join(", ");
    }
    reviews.push({
      externalId: `${prefix}-${i}`,
      author: cols.author !== undefined ? r[cols.author] || null : null,
      authorUrl: null,
      rating,
      text,
      language: null,
      publishedAt: cols.date !== undefined ? parseDateCell(r[cols.date] ?? "") : null,
      relativeTime: null,
      likes: null,
      ownerResponse: cols.response !== undefined ? r[cols.response] || null : null,
    });
  });
  const mapping: Record<string, string | null> = {};
  for (const key of Object.keys(ALIASES)) {
    mapping[key] = cols[key] !== undefined ? (headerDetected ? rows[0][cols[key]] : `columna ${cols[key] + 1}`) : null;
  }
  return { reviews, skipped, headerDetected, mapping };
}
