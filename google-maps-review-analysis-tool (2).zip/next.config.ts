import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // ExcelJS se carga como paquete externo del servidor (evita problemas de empaquetado).
  serverExternalPackages: ["exceljs"],
  // Los reportes de Word insertan los logotipos desde public/logos; en hosting serverless
  // (Netlify, Vercel) esta opción garantiza que los archivos viajen junto con la función.
  outputFileTracingIncludes: {
    "/api/export": ["./public/logos/**/*"],
  },
};

export default nextConfig;
