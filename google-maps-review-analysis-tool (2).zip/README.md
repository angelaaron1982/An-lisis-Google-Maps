# Analizador de Opiniones de Google Maps

Herramienta web para extraer reseñas y calificaciones de un lugar o empresa en Google Maps, agrupar las
opiniones en temas en común, obtener estadística descriptiva y gráficas, comparar varios establecimientos y
descargar reportes en Word y Excel.

> La herramienta forma parte de la asignatura **Investigación de mercado** impartida por el
> **Dr. Ángel Aarón Rosado Varela** · Universidad Autónoma del Estado de Quintana Roo (UQROO) · Coco Científico.

---

## 1. Qué necesita para funcionar

Esta aplicación **no es una página estática**: además de la interfaz tiene una parte de servidor
(las rutas `/api/...`) que consulta SerpAPI/Google, genera los archivos de Word y Excel y guarda las reseñas en
una base de datos. Por eso, en cualquier hosting necesita:

| Requisito | Detalle |
| --- | --- |
| **Node.js 20.9 o superior** | Para compilar y ejecutar Next.js 16. |
| **Base de datos PostgreSQL** | Local o en la nube (Neon, Supabase, Netlify DB, Railway, Render…). Las tablas se crean solas la primera vez. |
| **Variable `DATABASE_URL`** | Cadena de conexión de PostgreSQL. También se aceptan `NETLIFY_DATABASE_URL` (Netlify DB) y `POSTGRES_URL` (Vercel). |
| `SERPAPI_API_KEY` *(opcional)* | Clave por defecto de SerpAPI para todos los usuarios. Si no se define, cada persona pega la suya en la página. |
| `GOOGLE_MAPS_API_KEY` *(opcional)* | Clave de Google Places API (New). Igual que la anterior, es opcional. |

El archivo `.env.example` muestra el formato de estas variables.

---

## 2. Ejecutar en tu computadora

```bash
npm install                 # instala las dependencias
cp .env.example .env        # crea el archivo .env y escribe tu DATABASE_URL
npm run dev                 # modo desarrollo → http://localhost:3000
# o bien, para producción:
npm run build && npm start
```

Comprueba que `http://localhost:3000/api/health` responda `{"ok":true}`.

---

## 3. Publicar en Netlify (paso a paso)

Netlify soporta Next.js 16 sin configuración adicional (el archivo `netlify.toml` incluido ya trae lo necesario).
Lo que **no** incluye Netlify es la base de datos, así que el proceso tiene tres partes.

### Paso A. Subir el código a GitHub

1. Crea una cuenta en [github.com](https://github.com) y un repositorio nuevo (puede ser privado).
2. Sube la carpeta del proyecto. La forma más sencilla es con **GitHub Desktop** (*File → Add local repository → Publish*),
   o desde la web con *Add file → Upload files* arrastrando el contenido de la carpeta.
3. **No subas** `node_modules`, `.next` ni el archivo `.env` (contiene tus claves). El `.gitignore` incluido ya los
   excluye si usas GitHub Desktop o `git`.

### Paso B. Crear la base de datos (elige una opción)

- **Opción 1 – Netlify DB (la más fácil):** después de crear el sitio en Netlify, entra a la pestaña
  **Extensions / Database** y añade *Netlify DB* (está basada en Neon). Netlify crea sola la variable
  `NETLIFY_DATABASE_URL` y la aplicación la reconoce sin más pasos.
- **Opción 2 – Neon o Supabase (gratis):** crea un proyecto en [neon.tech](https://neon.tech) o
  [supabase.com](https://supabase.com), copia la *connection string* (algo como
  `postgresql://usuario:contraseña@host/neondb?sslmode=require`) y úsala en el Paso C como `DATABASE_URL`.

### Paso C. Crear el sitio en Netlify

1. En [app.netlify.com](https://app.netlify.com): **Add new project → Import an existing project → GitHub** y elige tu repositorio.
2. Netlify detecta Next.js. Verifica: *Build command* = `npm run build`, *Publish directory* = `.next`.
3. Antes de desplegar, abre **Environment variables** y agrega:
   - `DATABASE_URL` → la cadena de conexión del Paso B (no hace falta si usaste Netlify DB).
   - `SERPAPI_API_KEY` → opcional (si quieres que todos usen tu clave; recuerda que gastarán tus créditos).
   - `GOOGLE_MAPS_API_KEY` → opcional.
4. Pulsa **Deploy**. En 2-4 minutos tendrás una dirección `https://tu-sitio.netlify.app`.
5. Comprueba `https://tu-sitio.netlify.app/api/health` → debe responder `{"ok":true}`. Si responde con un error,
   el mensaje indica qué variable falta.
6. Entra a la página, pulsa **Cargar establecimientos de demostración** y prueba un análisis y una descarga.

Si cambias una variable de entorno después, vuelve a desplegar (*Deploys → Trigger deploy*) para que surta efecto.

### Alternativa sin GitHub: Netlify CLI

```bash
npm install -g netlify-cli
netlify login
netlify init                      # crea el sitio y lo vincula a esta carpeta
netlify env:set DATABASE_URL "postgresql://..."
netlify env:set SERPAPI_API_KEY "tu_clave"   # opcional
netlify deploy --build --prod
```

### Límites que conviene conocer en Netlify

- Las rutas de servidor corren como funciones con **10 segundos** de límite en el plan gratuito (26 s en planes de pago).
  La aplicación ya está ajustada: la extracción de SerpAPI se hace en bloques cortos y los reportes se generan en ~1 s.
- Las claves de API que cada usuario pega se guardan solo en su navegador; las variables de entorno del servidor
  sirven como valor por defecto.
- Los datos (lugares y reseñas) viven en tu base de datos PostgreSQL, no en Netlify.

### ¿Y en Vercel?

Funciona igual con el mismo repositorio: **Add New → Project → importar de GitHub**, agregar `DATABASE_URL`
(o crear una base Neon desde *Storage*, que define `POSTGRES_URL`) y desplegar. Vercel es la plataforma de los
creadores de Next.js y no requiere `netlify.toml`.

---

## 4. Estructura del proyecto

```
src/app/                 Página principal, layout y rutas de API (/api/search, /api/places, /api/export…)
src/components/          Interfaz: búsqueda, establecimientos, análisis, comparación, metodología
src/lib/analysis/        Motor de análisis: temas, sentimiento, estadística, agrupamiento (k-means)
src/lib/export/          Generadores de reportes en Word (docx) y Excel (exceljs)
src/lib/providers.ts     Conexión con Google Places API y SerpAPI
src/db/                  Esquema (Drizzle ORM) y conexión a PostgreSQL; las tablas se crean automáticamente
public/logos/            Logotipos de UQROO y Coco Científico
```

## 5. Fuentes de datos y uso responsable

Las reseñas provienen de Google Maps a través de la API oficial de Google Places (máx. 5 reseñas por consulta) o de
SerpAPI (paginación de reseñas). Respeta los términos de servicio de cada proveedor y cita la fuente en los reportes.
Los establecimientos marcados «(demo)» son datos simulados para practicar.
